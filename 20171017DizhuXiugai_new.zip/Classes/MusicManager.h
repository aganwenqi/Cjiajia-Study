#ifndef _MUSICMANAGER_H_
#define _MUSICMANAGER_H_
#include "SimpleAudioEngine.h"
#include "cocos2d.h"
USING_NS_CC;


class MusicManager
{
public:
	static void PlayBackgroundMusic(const char *str,bool state);
	static void PlayEffectMusic(const char *str);
	static void StopBackgroundMusic();
	static void StopAllEffectMusic();
};
#endif