#ifndef _LAODA_H_
#define _LAODA_H_

#include<iostream>

#include<vector>

#include<string>

//#include<windows.h>

#include<functional>

#include "Define.h"
#include "Enum.h"

//using std::string;
//using std::vector;
class GrandFather
{
public:
	
	virtual bool init()=0;
};
#endif