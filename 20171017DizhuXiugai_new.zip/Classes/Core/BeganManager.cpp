#include"BeganManager.h"
BeganManager::BeganManager()
{
        Playplay=false;	
        RobotOne=false;
        RobotTwo=false;
}
BeganManager::~BeganManager()
{

}
void BeganManager::SwitchLambda()
{

}