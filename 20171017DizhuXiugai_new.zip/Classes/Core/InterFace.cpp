#include "InterFace.h"
#include "RobotOne.h"
#include "RobotTwo.h"
#include "Player.h"
#include "Common.h"
#include "pDataManager.h"
bool InterFace::init()
{
	return true;
}
InterFace::InterFace()
{
	m_Player=Player::getInstance();
	m_RobotOne=RobotOne::getInstance();
	m_RobotTwo=RobotTwo::getInstance();
	m_Who=4;
}
InterFace::~InterFace()
{
}
/*�������̨���ƶԽ�*/
Moves InterFace::PlayCards(int *poker,int a[],int Who)
{
	
	Moves m_Moves=_NULL;

	m_Moves=NetPlayCards(poker,Who);

	/*��������*/
	//if(m_Moves!=_NULL&&a[0]!=0&&Who==1)
	//RobotSetTake(a,m_Moves);

	if(m_Moves==_zhadan||m_Moves==_wangzha||m_Moves==_end)
	pDataManager::getInstance()->Fraction(m_Moves);

	return m_Moves;
}
/*�������̨���ƶԽ�*/
Moves InterFace::PlayCards(int *poker,int Who)
{

	Moves m_Moves=_NULL;

	m_Moves=NetPlayCards(poker,Who);

	if(m_Moves==_zhadan||m_Moves==_wangzha||m_Moves==_end)
    pDataManager::getInstance()->Fraction(m_Moves);

	return m_Moves;
}
Moves InterFace::NetPlayCards(int *poker,int Who)
{
	Common *m_Common;
	Moves m_Moves=_NULL;
	
	if(Who==1||Who==4)
	m_Common=m_Player;
	else if(Who==2)
    m_Common=m_RobotOne;
	else
	m_Common=m_RobotTwo;

	/*�����߳���*/
  //  m_mutex.lock();
	return m_Common->Thecards(poker,Who);
}
void InterFace::NetPlayer(int *poker,int Who,Moves m_Moves)
{
	Common *m_Common;
	if(Who==2)
    m_Common=m_RobotOne;
	else
	m_Common=m_RobotTwo;

	/*�����߳���*/
  //  m_mutex.lock();
    m_Common->NetThecards(poker,Who);
	if(m_Moves==_zhadan||m_Moves==_wangzha||m_Moves==_end)
	pDataManager::getInstance()->Fraction(m_Moves);
}
void InterFace::FuncTionWho()
{
	if(m_Who==1)
	  m_Play();

	if(m_Who==2)
	  m_RotboOne();

	if(m_Who==3)
	  m_RotboTwo();
}
/*���ӷ��Ƶ�����*/
void InterFace::RobotSetTake(int* a,Moves m_Moves)
{
	    m_Take(a,m_Moves);
}