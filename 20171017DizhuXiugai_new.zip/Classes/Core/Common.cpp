#include "Common.h"
#include "Player.h"
#include "List.h"
#include "Poker.h"
#include "Suanfa.h"
#include "Frame.h"
#include <algorithm>
using namespace std;
void Common::CunPai(List *list)
{
	
//	Suanfa::getInstance()->addCupai(this,list); 
}

Common::Common()
{
  frame=Frame::getInstance();
  m_Role=false;
 // head.resize(20);
  srand((unsigned)time(NULL));
  head=NULL;
}
Common::~Common()
{

}
/*��ȡ���ﻹ�ж�������*/
int Common::getPokerNum()
{
	
	int i=0;
	using std::vector;
	vector<Poker*>::const_iterator iter=head->begin();
	Poker* p=NULL;
	while(iter!=head->end())
	 {
	    p=*iter++;
		 if(p->getState())
		 {
			 i+=1;
		 }
	 }
	return i;
	return true;
}
string Common::getPokerData()//��ȡ���ﻹ�е���
 {
	using std::vector;
	vector<Poker*>::iterator iter=head->begin();
	Poker* p=NULL;
	 string one="";
	 while(iter!=head->end())
	 {
		 p=*iter++;
		 if(p!=NULL&&p->getState())
		 {
		 one+=p->getstrData();
		 }
	 }
	return one;
	return "";
 }
void Common::NetThecards(int *poker,int Who)
{
   if(getLTpoker()==Frame::getInstance()->getpoker())
	{
		Frame::getInstance()->setpoker("");
	}
	Suanfa::getInstance()->Chupai(poker,Who);//ֱ�ӳ���
}
template<class T>
bool Compare_p(const T a,const T b)
{
	return a->getNumber()<b->getNumber();
}
void Common::Sort()
{
	sort(head->begin(),head->end(),Compare_p<Poker*>);
}

/*��ȡ���ﻹ�е���*/
/*string Common::getType()
 {
	 string one="";
	 List* p;
	 p=head;
	 while(p)
	 {
		 if(p->m_poker.getState())
		 {
		 one+=p->m_poker.getType();
		 }
		 p=p->next;
	 }
	return one;
 }
*/