#include "List.h"
List::List()
{
next=NULL;
}
List::~List()
{
	if(next!=NULL)
    delete next;
}