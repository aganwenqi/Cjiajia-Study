#include "RobotOne.h"
#include "Poker.h"
#include "Suanfa.h"
#include "List.h"
using std::string;
RobotOne* RobotOne::m_RobotOne=NULL;
RobotOne* RobotOne::getInstance()
{
	if(m_RobotOne==NULL)
	{
		m_RobotOne=new RobotOne();
	}
	return m_RobotOne;
}
Moves RobotOne::Thecards(int *poker,int Who)
{
	string one;

	if(getLTpoker()==Frame::getInstance()->getpoker())
	{
		Frame::getInstance()->setpoker("");
	}

	Paixing=Suanfa::getInstance()->addDuipai(poker,2);
	return Paixing;
}
