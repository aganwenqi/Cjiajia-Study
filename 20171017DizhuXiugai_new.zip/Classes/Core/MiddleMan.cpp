#include"MiddleMan.h"
#include "Poker.h"
#include "RobotOne.h"
#include "RobotTwo.h"
#include "Player.h"
#include "Suanfa.h"
#include "PokerContainer.h"
#include "Alltool.h"
#include "MsgManager.h"
#include "QingBaoA.h"
#include "JsonData.h"
#include "Frame.h"
#include <algorithm>

using namespace std;
void MiddleMan::setHaveDz(bool one)
{
	haveDZ=one;
}
void MiddleMan::Initial()//��ʼ��
{
	
	 frame->initial();
	 m_Player->setLTpoker("");
	 m_Player->Jiepoker[0]=0;
	 if(m_Player->head)
	 delete m_Player->head;

	 m_RobotOne->setLTpoker("");
	 m_RobotOne->Jiepoker[0]=0;
	 if(m_RobotOne->head)
	 delete m_RobotOne->head;

	 m_RobotTwo->setLTpoker("");
	 m_RobotTwo->Jiepoker[0]=0;
	 if(m_RobotTwo->head)
	 delete m_RobotTwo->head;

}
void MiddleMan::dizhu()
{
	float a;
	a=Alltool::getSrand();
		if(!haveDZ)
	{
		
		if(a<0.2f)
		{
			m_Player->setRole(true);
			m_RobotOne->setRole(false);
			m_RobotTwo->setRole(false);
		}
		else if(a>=0.3f&&a<0.6f)
		{
			m_Player->setRole(false);
			m_RobotOne->setRole(true);
			m_RobotTwo->setRole(false);
		}
		else
		{
			m_Player->setRole(false);
			m_RobotOne->setRole(false);
			m_RobotTwo->setRole(true);
		}
    }
		
}
void MiddleMan::Netdizhu()//��������
{
	JsonData* jsonData=MsgManager::getInstance()->getmsgMap(G_TXType::G_Began);
	m_Player->setplayname(jsonData->getCStrData(G_Play::G_playname));
	m_RobotOne->setplayname(jsonData->getShuzuData(G_Ziduan::G_RoomMsg,0,G_Play::G_playname));
	m_RobotTwo->setplayname(jsonData->getShuzuData(G_Ziduan::G_RoomMsg,1,G_Play::G_playname));

	if(jsonData->getBoolData(G_Play::G_playstate))
	{
    WhoHaveDz(1);
	}
	else if(jsonData->getBoolShuzuData(G_Ziduan::G_RoomMsg,0,G_Play::G_playstate))
	WhoHaveDz(2);
	else if(jsonData->getBoolShuzuData(G_Ziduan::G_RoomMsg,1,G_Play::G_playstate))
	WhoHaveDz(3);
}
void MiddleMan::Wash()//ϴ��
{
	random_shuffle(AllPoker.begin(),AllPoker.end());
}


void MiddleMan::fapai()//����
{
	Common *one,*two,*three;
	vector<Poker*> *a=new vector<Poker*>();
	vector<Poker*> *b=new vector<Poker*>();
	vector<Poker*> *c=new vector<Poker*>();
	if(m_Player->getRole())
	{
		three=m_Player;
		one=m_RobotOne;
		two=m_RobotTwo;
	}
	else if(m_RobotOne->getRole())
	{
		three=m_RobotOne;
		one=m_RobotTwo;
		two=m_Player;
	}
	else if(m_RobotTwo->getRole())
	{
		three=m_RobotTwo;
		one=m_RobotOne;
		two=m_Player;
	}
	copy(AllPoker.begin(),AllPoker.begin()+17,back_inserter((*a)));
	copy(AllPoker.begin()+17,AllPoker.begin()+34,back_inserter((*b)));
	copy(AllPoker.begin()+34,AllPoker.end(),back_inserter(*c));
	one->head=a;
	two->head=b;
	three->head=c;

	one->Sort();
	two->Sort();
	three->Sort();
	//print<std::vector<Poker*>::iterator>(m_Player->head.begin(),m_Player->head.end());
	//print<std::vector<Poker*>::iterator>(m_RobotOne->head.begin(),m_RobotOne->head.end());
	//print<std::vector<Poker*>::iterator>(m_RobotTwo->head.begin(),m_RobotTwo->head.end());

}
void MiddleMan::Netfapai()//���緢��
{
	//List* p=head;int i;
	MsgManager *msg=MsgManager::getInstance();

	/*---------------------*/
/*	if(m_RobotOne->getRole())
		i=0;
	else
		i=3;
	for(i=i;i<20;i++)//ģ��
	{
	m_RobotOne->CunPai(p);
	}

	if(m_RobotTwo->getRole())
		i=0;
	else
		i=3;
	for(i=i;i<20;i++)//ģ��
	{
	m_RobotTwo->CunPai(p);
    }*/
	/*---------------------*/
/*	Common *com1,*com2;
		for(i=0;msg->myPoker[i]!=0;i++)
	{
		p=msg->getPoker(msg->myPoker[i]);
        m_Player->CunPai(p);
	}

		if(msg->onename==m_RobotOne->getplayname())
		{com1=m_RobotOne;com2=m_RobotTwo;}
		else{com2=m_RobotOne;com1=m_RobotTwo;}

		for(i=0;msg->onePoker[i]!=0;i++)
	{
		p=msg->getPoker(msg->onePoker[i]);
        com1->CunPai(p);
	}
			for(i=0;msg->twoPoker[i]!=0;i++)
	{
		p=msg->getPoker(msg->twoPoker[i]);
        com2->CunPai(p);
	}*/
}
void MiddleMan::WhoHaveDz(int i)//˭�ǵ���
{
	 if(i==1)
	 {
	    m_Player->setRole(true);m_RobotOne->setRole(false);m_RobotTwo->setRole(false);
	 }
	 else if(i==2)
	 {
		m_Player->setRole(false);m_RobotOne->setRole(true);m_RobotTwo->setRole(false);
	 }
	 else if(i==3)
	 {
		m_Player->setRole(false);m_RobotOne->setRole(false);m_RobotTwo->setRole(true);
	 }
	
}


/*
void MiddleMan::setPokerVe(vector<Poker*> one)
{
    int i=0;
	MsgManager *msg=MsgManager::getInstance();
	//���ƴ浽������headָ��ͷ
	List*Head=NULL;
	if(head!=NULL)
		return;

		Head=head=new List();
        Head->m_poker=*one.at(0);
		msg->setPoker(Head->m_poker.getID(),Head);

	for(auto on:one)
	{ if(i!=0)
	{
		   Head->next=new List();
		   Head=Head->next;
		   Head->m_poker=*on; 
		   msg->setPoker(Head->m_poker.getID(),Head);
	}
	i++;
	}

	
}
*/
MiddleMan* MiddleMan::m_MiddleMan=NULL;
MiddleMan::MiddleMan()
{
	haveDZ=false;
	//head=NULL;
	frame=Frame::getInstance();
	m_Player=Player::getInstance();
	m_RobotOne=RobotOne::getInstance();
	m_RobotTwo=RobotTwo::getInstance();
	m_Sunfa=Suanfa::getInstance();

	/*�����˿��Ʋ��ó���*/
	PokerContainer * pc=PokerContainer::create();
	//setPokerVe(pc->getVe());
	AllPoker = pc->getVe();
	delete pc;
}
MiddleMan::~MiddleMan()
{
	//head=NULL;
}

MiddleMan* MiddleMan::getInstance()
{
	if(m_MiddleMan==NULL)
	{
		m_MiddleMan=new MiddleMan();
	}
	srand((unsigned)time(NULL));
	return m_MiddleMan;
}
