#include "RobotTwo.h"
#include "Poker.h"
#include "Suanfa.h"
using std::string;
RobotTwo* RobotTwo::m_RobotTwo=NULL;
RobotTwo* RobotTwo::getInstance()
{
	if(m_RobotTwo==NULL)
	{
		m_RobotTwo=new RobotTwo();
	}
	return m_RobotTwo;
}
Moves RobotTwo::Thecards(int *poker,int Who)
{
	string one;
    if(getLTpoker()==Frame::getInstance()->getpoker())
    {
	Frame::getInstance()->setpoker("");
    }

	Paixing=Suanfa::getInstance()->addDuipai(poker,3);
 return  Paixing;
}

