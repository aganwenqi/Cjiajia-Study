#ifndef _CHOUX_H_
#define _CHOUX_H_
class Suanfa;
class Poker;
class ChouX
{
public:
	
	virtual std::vector<Poker*> getHead()=0;
	virtual void setHead(std::vector<Poker*>)=0;

	/*����*/
	virtual Moves Thecards(int *poker,int Who)=0;
};
#endif