#ifndef _ROBOTTWO_H_
#define _ROBOTTWO_H_
#include "Common.h"
#include<iostream>
#include<string>
#include "Frame.h"
class Poker;
class List;
class ChouX;
class RobotTwo:public Common
{
public:
	
	static RobotTwo* getInstance();
	/*�˻�����*/
	virtual Moves Thecards(int *poker,int Who);
private:
	static RobotTwo* m_RobotTwo;
};
#endif