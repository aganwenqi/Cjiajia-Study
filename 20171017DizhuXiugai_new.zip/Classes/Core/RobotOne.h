#ifndef _ROBOTONCE_H_
#define _ROBOTONCE_H_
#include "Common.h"
#include<iostream>
#include<string>
#include "Frame.h"
class Poker;
class List;
class ChouX;
class RobotOne:public Common
{
public:

	static RobotOne* getInstance();
	/*�˻�����*/
	virtual Moves Thecards(int *poker,int Who);
		
	
private:
	static RobotOne* m_RobotOne;

};
#endif