#include "Suanfa.h"
#include "List.h"
#include "Poker.h"
#include "Player.h"
#include "RobotOne.h"
#include "RobotTwo.h"
#include "Common.h"

using std::string;
int Suanfa::IntNumber(int *a)//��ȡint��������ĸ���
{
	     int gan=0;
		 for(int j=0;a[j]!=0;j++)
		 {
			 gan+=1;
		 }
		 return gan;
}
void Suanfa::JiePoker(string chupai,int *a)//���˿˴�С����Ϊ���ִ�С
 {
	 int i=0,j;
	 string wuke="34567890JQK12wW";

		 for(j=0;j<20;j++)
		 {
			 if(chupai[0]==wuke[j])
			 {
				 a[i++]=j+1;
				 chupai.erase(0,1);
				 j=-1; 
				 if(chupai==""){break;}
			 }
			 if(j==16){j=0;j=0;}
		 }

		 a[i]=0;
		 j=0;
		 i=0;
		 int gan=0,wen;
		 gan=IntNumber(a);
		
		 j=0;
		for(i=0;i<gan;i++)
		{
			for(int j=0;j<gan-i;j++)
			{
				if(a[j+1]==0){break;}
				if(a[j]>a[j+1])
				{
					wen=a[j];
					a[j]=a[j+1];
					a[j+1]=wen;
				}
			}
		}
	
 }

Suanfa*Suanfa::suanfa=NULL;
Suanfa*Suanfa::getInstance()
{
	if(suanfa==NULL)
	{
		suanfa=new Suanfa();
	
	}
	return suanfa;
}
Suanfa::Suanfa()
{
	srand((unsigned)time(NULL));

	m_RobotOne=RobotOne::getInstance();//������1
    m_RobotTwo=RobotTwo::getInstance();//������2
    m_Player=Player::getInstance();//����
	m_Frame=Frame::getInstance();//���

	JDActions[0]=&Suanfa::JDdan_0;
	JDActions[1]=&Suanfa::JDduizi_1;
	JDActions[2]=&Suanfa::JDsantiao_2;
	JDActions[3]=&Suanfa::JDsandaiyi_3;
	JDActions[4]=&Suanfa::JDsandaidui_4;
	JDActions[5]=&Suanfa::JDshunzi_5;
	JDActions[6]=&Suanfa::JDliandui_6;
	JDActions[7]=&Suanfa::JDfeiji_7;
	JDActions[8]=&Suanfa::JDfeijidai2_8;
	JDActions[9]=&Suanfa::JDzhadan_9;
	JDActions[10]=&Suanfa::JDsidai1_10;
	JDActions[11]=&Suanfa::JDsidai2_11;
	JDActions[12]=&Suanfa::JDwangzha_12;

	TPActions[0]=&Suanfa::TPdan_0;
	TPActions[1]=&Suanfa::TPduizi_1;
	TPActions[2]=&Suanfa::TPsantiao_2;
	TPActions[3]=&Suanfa::TPsandaiyi_3;
	TPActions[4]=&Suanfa::TPsandaidui_4;
	TPActions[5]=&Suanfa::TPshunzi_5;
	TPActions[6]=&Suanfa::TPliandui_6;
	TPActions[7]=&Suanfa::TPfeiji_7;
	TPActions[8]=&Suanfa::TPfeijidai2_8;
	TPActions[9]=&Suanfa::TPzhadan_9;
	TPActions[10]=&Suanfa::TPsidai1_10;
	TPActions[11]=&Suanfa::TPsidai2_11;
	TPActions[12]=&Suanfa::TPwangzha_12;
}
void Suanfa::addXupai(List* head)//ϴ���㷨
{

	srand((unsigned)time(NULL));

	List*p1=NULL,*p2=NULL,*p3=NULL,*p4=NULL,*p5=NULL,*p6=NULL;
	for(int i=0;i<250;i++)
	{
		p1=head;
		while(p1->next->next)
		{
			p2=p1;
			p1=p1->next;
		}
	    p3=p1->next;
		p2->next=p3;
		p3->next=p1;
		p1->next=NULL;

   p1=head;
   p2=p1->next;
   p3=p1->next->next;
   
   head=p2;
   head->next=p1;
   p1->next=p3;
  
      p2=p1->next;
   p5=p1->next->next;
   p3=p1->next->next->next->next;
   p4=p1->next->next->next->next->next;
   p1->next=p5;
   p3->next=p2;
   p2->next=p4;
   // p1=p2;
	 p1=head;
	 
   p2=p1->next;
   p6=p1->next->next->next;
   p5=p1->next->next->next->next;
   p3=p1->next->next->next->next->next->next->next->next->next->next->next->next->next;
   p4=p1->next->next->next->next->next->next->next->next->next->next->next->next->next->next;
   p1->next=p5;
   p3->next=p2;
   p6->next=p4;
   p1=p2;
   while(p1->next)
   {
	
	  
	   if(p1->next->next->next==NULL)
	   {
		  p2=p1->next;
          p3=p1->next->next;
		  p1->next=p2;
		  p2->next=p3;
		  p1=p3;
		   break;
	   }
	  if(p1->next->next->next->next==NULL)
	   {
		  p2=p1->next;
          p3=p1->next->next;
		  p4=p1->next->next->next;
		  p1->next=p3;
		  p3->next=p2;
		  p2->next=p4;
		  p1=p4;
		  break;
	  }
	   if(RAND_0_9()<=0.5f)
	   {
	 if(p1->next->next==NULL)
	   {
		  p2=p1;
		  p1=p1->next;
		  p1->next=p2;
		  p2->next=NULL;
		  p1=p2;
		   break;
	   }
		  
   p2=p1->next;
   p3=p1->next->next;
   p4=p1->next->next->next;
   p1->next=p3;
   p3->next=p2;
   p2->next=p4;
   p1=p2;
	   }
	   else
		   p1=p1->next;
   }
	}
}
void Suanfa::addCupai(ChouX  *Head,List *list)//�����㷨
{
	/*

	 List*p1=NULL,*p2=NULL,*p=NULL,*head=NULL;
	 p=new List();
	 p->m_poker=list->m_poker;
	 head=Head->getHead();

	if(head==NULL)
	{	
	Head->setHead(p);
	return; 
	}

	if(head->m_poker.getNumber()>p->m_poker.getNumber())
		{
			p->next=head;
			Head->setHead(p);
		return;
	    }
	 p1=head;
	 
    while(1)
	{
		if(p1->next==NULL)
		{
			p1->next=p;
			return;
		}
		p2=p1->next;
		if(p2->m_poker.getNumber()>p->m_poker.getNumber())//������ô�ź���
		{
			p1->next=p;
			p->next=p2;
			return;
		}	
		p1=p2;
		
	}*/
}