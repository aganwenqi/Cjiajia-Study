#ifndef _TakeTexiao_H_
#define _TakeTexiao_H_
#include "cocos2d.h"
#include "Enum.h"

class TakeTexiao:public cocos2d::Node
{
public:
	TakeTexiao();
	~TakeTexiao();
	virtual bool init();
	CREATE_FUNC(TakeTexiao);

	/*ִ����Ч*/
	void RunEffect(Moves m_Moves);

	/*ը����Ч*/
	void zhadan();

	/*�ɻ���Ч*/
	void feiji();

	/*������Ч*/
	void liandui();
};
#endif