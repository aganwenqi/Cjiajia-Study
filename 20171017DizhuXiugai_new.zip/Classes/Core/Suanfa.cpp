#include "Suanfa.h"
#include "List.h"
#include "Poker.h"
#include "Player.h"
#include "RobotOne.h"
#include "RobotTwo.h"
#include "Common.h"
#include <vector>
using std::string;

void Suanfa::TPChupai(int *KJpoker,int quit)//���ƣ��������
{
	using std::vector;
	int Number=IntNumber(KJpoker),i=0;
	Common*m_Common;
	string str="";
	//string str1="";

	if(quit==1||quit==4){m_Common=m_Player;}
	if(quit==2){m_Common=m_RobotOne;}
	if(quit==3){m_Common=m_RobotTwo;}
	vector<Poker*> list=m_Common->getHead();
	vector<Poker*>::const_iterator iter=list.begin();
	Poker* poker=NULL;

	while(iter != list.end())
	{
		poker=*iter++;
		if(KJpoker[i]==0){break;}
		if(poker->getState()!=false && poker->getNumber()==KJpoker[i])
		{
			str+=poker->getstrData();
			//str1+=list->m_poker.getType();

			poker->setState(false);
			i+=1;
		}
		if(iter == list.end())iter = list.end();
	}

	m_Common->setLTpoker(str);
	m_Frame->setpoker(str);
}
bool Suanfa::ShibieDY(bool MyRole)//ʶ��Ҫ��һ�γ����Ƶ����ǲ��Ƕ���
{

	string str_Table=m_Frame->getpoker();
	Common*Hcard;

	if(str_Table==m_Player->getLTpoker())//�鿴�Ƿ�����ҵ��ƣ������Hcard������
	{
		Hcard=m_Player;
	}

	if(str_Table==m_RobotOne->getLTpoker())//�鿴�Ƿ����˻�1���ƣ������Hcard������
	{
		Hcard=m_RobotOne;
	}

	if(str_Table==m_RobotTwo->getLTpoker())//�鿴�Ƿ����˻�2���ƣ������Hcard������
	{
		Hcard=m_RobotTwo;
	}

	if(MyRole==Hcard->getRole())
	{
		return true;
	}

	return false;
}
Common *Suanfa::TablePokerPeople()//ʶ��Ҫ��һ�γ����ƵĶ���;
{
	string str_Table=m_Frame->getpoker();
	Common*Hcard;

	if(str_Table==m_Player->getLTpoker())//�鿴�Ƿ�����ҵ��ƣ������Hcard������
	{
		Hcard=m_Player;
	}

	if(str_Table==m_RobotOne->getLTpoker())//�鿴�Ƿ����˻�1���ƣ������Hcard������
	{
		Hcard=m_RobotOne;
	}

	if(str_Table==m_RobotTwo->getLTpoker())//�鿴�Ƿ����˻�2���ƣ������Hcard������
	{
		Hcard=m_RobotTwo;
	}

	return Hcard;
}
bool Suanfa::FuzhuSmartCards(int *a,int *b,int quit)
{
	if(m_Frame->getpoker()!="")
	  {
	if(!SmartCards(a,b,quit))
	{
		return false;
	}
	  }
	return true;
}
//����
bool Suanfa::SmartCards(int*a,int*b,int quit)//��һ��Ϊ�˻����ƣ��ڶ���Ϊ����ģ�������Ϊquit����˭,���ؼٲ���
{
	 if(quit==1){return true;}
	 Common*m_Common;
	 if(quit==2){m_Common=m_RobotOne;}
	 if(quit==3){m_Common=m_RobotTwo;}
	 if(quit==4){m_Common=m_Player;}
	 int s[21];
	 bool m_Friend;//���ʾ������

	 int FriendPokerNum;//���ѻ��ж�����
	 int FriendTableNum;//���ѳ����Ƶ�����
	 int FriendOneSize;//���ѳ����Ƶĵ�һ�Ŵ�С
	 int MyPoker;//�һ��ж�����

	 MyPoker=IntNumber(a);//�һ��ж�����
	 if(MyPoker<=3){return true;}

	 FriendOneSize=b[0];//���ѳ����Ƶĵ�һ�Ŵ�С

	 FriendTableNum=IntNumber(b);//���ѳ����Ƶ�����

     m_Friend=ShibieDY(m_Common->getRole());//���ʾ������

	 if(!m_Friend){return true;}

	 JiePoker(TablePokerPeople()->getPokerData(),s);

	 FriendPokerNum=IntNumber(s);//���ѻ��ж�����
      
	
	  if(MyPoker<21)
	  {
		  if(FriendOneSize>=12)
		  { return false; }

		  if(FriendTableNum>7)
		  { return false; }

		   if(FriendTableNum>7&&FriendOneSize>=10)
		  {return false;}

		  return true;
	  }
	  else if(MyPoker<12)
	  {
		    if(FriendOneSize>=10&&FriendPokerNum<3)
		  { return false; }

		  if(FriendOneSize>=13)
		  { return false; }

		  if(FriendPokerNum<9&&FriendTableNum>6)
		  {return false;}

		  if(FriendTableNum>5&&FriendOneSize>=8)
		    { return false; }

		   return true;
	  }
	  else if(MyPoker<7)
	  {
		    if(FriendOneSize>=13&&FriendPokerNum<3)
		  { return false; }

		  if(RAND_0_9()>0.4f)
		  {
		   if(FriendOneSize>=13&&FriendPokerNum<6)
		  { return false; }

		  }
		  if(FriendPokerNum<9&&FriendTableNum>5)
		  {return false;}

		  if(FriendTableNum>5&&FriendOneSize>=7)
		    { return false; }

		   return true;
	  }
	  else if(MyPoker<5)
	  {
		  
		   if(FriendOneSize>=13&&FriendPokerNum<6)
		  { return false; }
		     if(FriendOneSize>=13&&FriendPokerNum<3)
		  { return false; }

			 if(RAND_0_9()>0.7f)
			 {
			  if(FriendTableNum>2&&FriendOneSize>=13)
		    { return false; }
			 }
	     return true;
	  }

	  return true;
}
	//�ж������жϵ��������ϵ���
Moves Suanfa::TPdan_01(int *KJpoker,int quit)//������û����,�˻�����
{
	
	int i=0;
	int a[23]={0};

	int j=0;
	string str="";
	string str1="";
	Moves move;
	int num=IntNumber(KJpoker);
	int gan=0;
	while(gan++&&gan<10)
	{
     if(RAND_0_9()>0.4f&&num<=0.5f)
		{
			
			
		  if(KJpoker[i+1]==KJpoker[i]&&KJpoker[i+1]==KJpoker[i+2]&&KJpoker[i+1]<10)
			{
			    a[0]=KJpoker[i];a[1]=KJpoker[i+1];a[2]=KJpoker[i+2];a[3]=0;
				Chupai(a,quit);
				move=_santiao;
				return move;
			}
	
		else if(RAND_0_9()<=0.4f)
		{
			if(IntNumber(KJpoker)>14)
			{
				if(KJpoker[i]==KJpoker[i]+2)
				{a[0]=1;a[1]=1;a[2]=1;a[3]=4;a[5]=0;
				move=TPsandaiyi_3(a,KJpoker,quit);

				if(move!=_NULL){return move;}

				}
				if(RAND_0_9()>0.3f)
				{
					a[0]=1;a[1]=2;a[2]=3;a[3]=4;a[4]=5;a[5]=0;
					move=TPshunzi_5(a,KJpoker,quit);
					if(move!=_NULL){return move;}

				}
				if(RAND_0_9()>0.3f)
				{
					a[0]=1;a[1]=1;a[2]=2;a[3]=2;a[4]=3;a[5]=3;a[6]=0;
					move=TPliandui_6(a,KJpoker,quit);
					if(move!=_NULL){return move;}
				}
			}
			else if(IntNumber(KJpoker)>11)
			{
	                a[0]=1;a[1]=1;a[2]=1;a[3]=2;a[4]=5;a[5]=0;
					move=TPsandaidui_4(a,KJpoker,quit);
					if(move!=_NULL){return move;}
			}
			else if(IntNumber(KJpoker)>8)
			{
				if(RAND_0_9()>0.5f)
				{
	                a[0]=1;a[1]=1;a[2]=1;
					move=TPsantiao_2(a,KJpoker,quit);
					if(move!=_NULL){return move;}
				}
			}
		}
	 }
	  
	if(IntNumber(KJpoker)>5&&RAND_0_9()>=0.4f)
			{
					a[0]=0;a[1]=1;a[2]=2;a[3]=3;a[4]=4;a[5]=0;
					move=TPshunzi_5(a,KJpoker,quit);
					if(move!=_NULL){return move;}
			}
	if(IntNumber(KJpoker)<10&&IntNumber(KJpoker)>=2)
			{
				if(KJpoker[i]==KJpoker[i+1])
			{
				a[0]=KJpoker[i];a[1]=KJpoker[i+1];a[2]=0;
				Chupai(a,quit);
			    move=_duizi;
				return move;
			}
			}
	}
      while(1)
	  {
	    for(int j=0;a[j]!=0;j++)
		{
			a[j]=0;
		}
		  
		 if(KJpoker[i+1]==0)
		 {
			     a[0]=KJpoker[0];a[1]=0;
				 Chupai(a,quit);
				 move=_dan;
				 return move;
		 }
		 
		 
		if(RAND_0_9()>0.8f)
		{
			
			if(KJpoker[i]==KJpoker[i+1])
			{
				 a[0]=KJpoker[i];a[1]=KJpoker[i+1];a[2]=0;
				 Chupai(a,quit);
				 move=_duizi;
				 return move;
			}
		}
		else if(RAND_0_9()>0.7f)
		{
			if(KJpoker[i]!=KJpoker[i+1])
			{
				if(IntNumber(KJpoker)>17&&i==0)
				{
				 a[0]=KJpoker[0];a[1]=0;
				 Chupai(a,quit);
				 move=_dan;
				 return move;
			
				}
				if(KJpoker[i]!=KJpoker[i-1])
				{
				 a[0]=KJpoker[i];a[1]=0;
				 Chupai(a,quit);
				 move=_dan;
				 return move;
				
				}
				else if(KJpoker[i]!=KJpoker[i+1])
				{
				 a[0]=KJpoker[i-1];a[1]=KJpoker[i];a[2]=0;
			   	 Chupai(a,quit);
				 move=_duizi;
				 return move;
				}
			}
			    else if(RAND_0_9()>0.7f&&KJpoker[i+1]<10)
				{
				 a[0]=KJpoker[i];a[1]=KJpoker[i+1];a[2]=0;
				 Chupai(a,quit);
				 move=_duizi;
				 return move;
				}
			    else if(KJpoker[i+1]==KJpoker[i]&&KJpoker[i+1]==KJpoker[i+2]&&KJpoker[i+1]<10)
			{
				 a[0]=KJpoker[i];a[1]=KJpoker[i+1];a[2]=KJpoker[i+2];a[3]=0;
				 Chupai(a,quit);
				 move=_santiao;
				 return move;
			}
		}
		else if(RAND_0_9()<=0.6f)
		{
			if(IntNumber(KJpoker)>16)
			{
				if(KJpoker[i]==KJpoker[i]+2)
				{a[0]=1;a[1]=1;a[2]=1;a[3]=4;a[5]=0;
				move=TPsandaiyi_3(a,KJpoker,quit);
				if(move!=_NULL){return move;}
				}
				if(RAND_0_9()>0.3f)
				{
					a[0]=1;a[1]=2;a[2]=3;a[3]=4;a[4]=5;a[5]=0;
					move=TPshunzi_5(a,KJpoker,quit);
					if(move!=_NULL){return move;}

				}
				if(RAND_0_9()>0.3f)
				{
					a[0]=1;a[1]=1;a[2]=2;a[3]=2;a[4]=3;a[5]=3;a[6]=0;
					move=TPliandui_6(a,KJpoker,quit);
					if(move!=_NULL){return move;}
				}
			}
			else if(IntNumber(KJpoker)>10)
			{
	                a[0]=1;a[1]=1;a[2]=1;a[3]=2;a[4]=5;a[5]=0;
					move=TPsandaidui_4(a,KJpoker,quit);
					if(move!=_NULL){return move;}
			}
			else if(IntNumber(KJpoker)>8)
			{
				if(RAND_0_9()>0.3f)
				{
	                a[0]=1;a[1]=1;a[2]=1;
					move=TPsantiao_2(a,KJpoker,quit);
					if(move!=_NULL){return move;}
				}
			}
		}
		
		
		i++;
		if(i==num-2){i=0;}
	  }
	
		return move;
}

//����ֵ����������ö�٣�_NUUL,��ʾ�Ӳ����ƣ�_end��ʾӮ��
Moves Suanfa::addDuipai(int *CP,int quit)//��ɫҪ�����ƻ����˻����ƣ�bool���ʾ��ɫ��false��ʾ�˻�
{
	RAND_0_9();
	RAND_0_9();
	m_Moves=_NULL;
	int *a=CP;
	int b[21]={0};//������
	this->JiePoker(m_Frame->getpoker(),b);//������ת��Ϊ����


	if(!FuzhuSmartCards(a,b,quit))//�ж��Ƿ�Ϊ����
		return _NULL;

	if(m_Frame->getpoker()==""&&quit!=1)
	{
		m_Moves=TPdan_01(a,quit);
	}//����Ϊ���˻�����
	else
    {
		bool tiaojian=false;
	if(m_Frame->getpoker()==""&&quit==1)//����Ϊ�ճ���
	{
		int i;
	  for(i=0;i<13;i++)
	    {
		//����Ϊ����ҳ���
			if(i==9||i==12)
			{
				if(a[0]==a[3]&&IntNumber(a)==4||a[0]==14&&a[1]==15&&IntNumber(a)==2)
			   {
				tiaojian=(this->*JDActions[i])(a);
			    if(tiaojian==true){break;}
				}		
	        }
			else 
			   {
				tiaojian=(this->*JDActions[i])(a);
			    if(tiaojian==true){break;}
				}
	    }

	      if(tiaojian==false){return _NULL;}//��������ô��
	      else{TPChupai(a,quit);m_Moves=PlayFirstPlaying(i);}//����
	}
	else
	{
	for(int i=0;i<13;i++)
		{
	 if((this->*JDActions[i])(b))//���Ӳ�Ϊ�ճ���
	   {m_Moves=(this->*TPActions[i])(b,a,quit);}

	   if(m_Moves!=_NULL){break;}
		}
	}
      }


	if(m_Player->getPokerData()==""||m_RobotOne->getPokerData()==""||m_RobotTwo->getPokerData()==""){m_Moves=_end;}
		return m_Moves;
}
Moves Suanfa::PlayFirstPlaying(int i)
{
	Moves m_Moves;
	switch(i)
	{
	case 0:
		m_Moves=_dan;
		break;
	case 1:
		m_Moves=_duizi;
		break;
	case 2:
		m_Moves=_santiao;
		break;
	case 3:
		m_Moves=_sandaiyi;
		break;
	case 4:
		m_Moves=_sandaidui;
		break;
	case 5:
		m_Moves=_shunzi;
		break;
	case 6:
		m_Moves=_liandui;
		break;
	case 7:
		m_Moves=_feiji;
		break;
	case 8:
		m_Moves=_feijidai1;
		break;
	case 9:
		m_Moves=_zhadan;
		break;
	case 10:
		m_Moves=_sidai1;
		break;
	case 11:
		m_Moves=_sidai2;
	case 12:
		m_Moves=_wangzha;
		break;
	}
	return m_Moves;
}

void Suanfa::Chupai(int *a,int quit)//Ҫ�����ƺͳ�˭����
{
	using std::vector;
	
	Common* m_Common;
	if(quit==1||quit==4){m_Common=m_Player;}
	if(quit==2){m_Common=m_RobotOne;}
	if(quit==3){m_Common=m_RobotTwo;}
	vector<Poker*>::const_iterator iter=m_Common->head->begin();
	Poker* poker=NULL;
	string str="";
	int i=0;

	   while(iter!=m_Common->head->end())
	   {
		   poker=*iter;
		   if(poker->getNumber()==a[i]&&poker->getState()!=false)
		   {
            poker->setState(false);
			str+=poker->getstrData();
			i+=1;
			if(a[i]==0){break;}
		   }
		   if(iter++ == m_Common->head->end())iter=m_Common->head->begin();
	   }
	   if(quit==2){int ah[21];JiePoker(m_Common->getPokerData(),ah);}
	   if(quit==3){int ah[21];JiePoker(m_Common->getPokerData(),ah);}
	   m_Common->setLTpoker(str);

	   m_Frame->setpoker(str);

	   for(i=0;a[i]!=0;i++)
	   {
	   m_Common->Jiepoker[i]=a[i];
	   }
	   m_Common->Jiepoker[i]=0;
}

bool Suanfa::JDdan_0(int *KJpoker)
{
	if(IntNumber(KJpoker)==1){return true;}
	
	return false;
}
//�����жϣ���һ��Ϊ�����ϵ��ƣ��ڶ���Ϊ��Ե���
Moves Suanfa::TPdan_0(int *KJpoker,int TJpoker[],int quit)
{
	int a[2]={0};
	//int j=0;

	if(quit==1)
	{
		if(IntNumber(TJpoker)!=1){return _NULL;}
		if(KJpoker[0]<TJpoker[0])
		{
			a[0]=TJpoker[0];a[1]=0;
			Chupai(a,quit);
			return _dan;
		}
	}
	else
	{
		
	for(int i=0;TJpoker[i]!=0;i++)
	{
		if(TJpoker[i+1]==0)
		{
			if(KJpoker[0]<TJpoker[i])
			{
			a[0]=TJpoker[i];a[1]=0;
			Chupai(a,quit);
			return _dan;
			}
			else
			{return _NULL;}
		}

		if(KJpoker[0]<TJpoker[i]&&TJpoker[i]!=TJpoker[i+1])
		{
			if(i>0)
			{
				if(TJpoker[i]!=TJpoker[i-1])
				{
			a[0]=TJpoker[i];a[1]=0;
			Chupai(a,quit);
			return _dan;
				}
			}
			else
			{
			a[0]=TJpoker[i];a[1]=0;
			Chupai(a,quit);
			return _dan;
			}
		}
	}
	}
	return _NULL;
}
bool Suanfa::JDduizi_1(int *KJpoker)
{	
	
	if(IntNumber(KJpoker)==2)
	{
		if(KJpoker[0]==KJpoker[1])
		{
		return true;
		}
	}
	return false;
}
Moves Suanfa::TPduizi_1(int *KJpoker,int TJpoker[],int quit)
{
	int a[5]={0};
	//int j=0;
	if(quit==1)
	{
       if(IntNumber(TJpoker)==2)
	   {
		if(KJpoker[0]<TJpoker[0]&&TJpoker[0]==TJpoker[1])
		{
			a[0]=TJpoker[0];a[1]=TJpoker[1];a[2]=0;
			Chupai(a,quit);
			return _duizi;
		}
	   }
	}
	else
	{
		if(IntNumber(TJpoker)<2){return _NULL;}
	for(int i=0;TJpoker[i]!=0;i++)
   {
	   if(RAND_0_9()>0.6f)
			{
				if(TJpoker[i]==TJpoker[i+2])
				{
					i++;
				}
			}
		if(KJpoker[0]<TJpoker[i]&&TJpoker[i]==TJpoker[i+1])
		{
			if(IntNumber(TJpoker)>12&&TJpoker[i]==13){return _NULL;}
			if(IntNumber(TJpoker)>15&&TJpoker[i]==12){return _NULL;}
			a[0]=TJpoker[i];a[1]=TJpoker[i+1];a[2]=0;
			if(IntNumber(a)!=2)return _NULL;
			Chupai(a,quit);
			return _duizi;
		
		}
		if(TJpoker[i+2]==0||TJpoker[i+1]==0){return _NULL;}
	}
 }
	return _NULL;
}
bool Suanfa::JDsantiao_2(int *KJpoker)
{
	
		if(IntNumber(KJpoker)==3)
	{
		if(KJpoker[0]==KJpoker[2])
		{
		return true;
		}
	}
	return false;
}
Moves Suanfa::TPsantiao_2(int *KJpoker,int TJpoker[],int quit)
{
		int a[4]={0};
	//int j=0;
	if(quit==1)
	{
       if(IntNumber(TJpoker)==3)
	   {
		if(KJpoker[0]<TJpoker[0]&&TJpoker[0]==TJpoker[1]&&TJpoker[0]==TJpoker[2])
		{
			a[0]=TJpoker[0];a[1]=TJpoker[1];a[2]=TJpoker[2];a[3]=0;
			Chupai(a,quit);
			return _santiao;
		}
	   }
	}
	else
	{
		if(IntNumber(TJpoker)<3){return _NULL;}

	for(int i=0;TJpoker[i]!=0;i++)
   {
	 //  if(TJpoker[i+1]==0){return _NULL;}
		if(KJpoker[0]<TJpoker[i]&&TJpoker[i]==TJpoker[i+1]&&TJpoker[i]==TJpoker[i+2])
		{
			if(TJpoker[i+2]==TJpoker[i+3])
			{
				i++;
			}
			else
			{
			a[0]=TJpoker[i];a[1]=TJpoker[i+1];;a[2]=TJpoker[i+2];a[3]=0;
			if(IntNumber(a)!=3)return _NULL;
			Chupai(a,quit);
			return _santiao;
			}
		}
		if(TJpoker[i+3]==0||TJpoker[i+1]==0||TJpoker[i+2]==0){return _NULL;}
	}
 }
	return _NULL;
}
bool Suanfa::JDsandaiyi_3(int *KJpoker)
{

			if(IntNumber(KJpoker)==4)
	{
		if(KJpoker[0]==KJpoker[2]&&KJpoker[3]!=KJpoker[0]||KJpoker[1]==KJpoker[3]&&KJpoker[3]!=KJpoker[0])
		{
		return true;
		}
	}
	return false;
}
Moves Suanfa::TPsandaiyi_3(int *KJpoker,int TJpoker[],int quit)
{
			int a[5]={0};
	//int j=0;
	if(quit==1)
	{
       if(IntNumber(TJpoker)==4)
	   {
		if(KJpoker[1]<TJpoker[1]&&TJpoker[1]==TJpoker[3]||KJpoker[1]<TJpoker[0]&&TJpoker[0]==TJpoker[2])
		{
			a[0]=TJpoker[0];a[1]=TJpoker[1];a[2]=TJpoker[2];a[3]=TJpoker[3];a[4]=0;
			Chupai(a,quit);
			return _sandaiyi;
		}
		
	   }
	}
	else
	{
		if(IntNumber(TJpoker)<4){return _NULL;}
	for(int i=0;TJpoker[i]!=0;i++)
   {
	 //  if(TJpoker[i+1]==0){return _NULL;}
		if(KJpoker[1]<TJpoker[i]&&TJpoker[i]==TJpoker[i+2])
		{
			if(TJpoker[i]==TJpoker[i+3])
			{
				i++;
			}
			else
			{

			a[0]=TJpoker[i];a[1]=TJpoker[i+1];;a[2]=TJpoker[i+2];a[4]=0;
			for(int j=0;TJpoker[j]!=0;j++)
                   {
					   if(TJpoker[j]==a[0]){j++;}
					   else
					   {
						   a[3]=TJpoker[j];
						   if(IntNumber(a)!=4)return _NULL;
						   Chupai(a,quit);
			               return _sandaiyi;
					   }
		           }
			}
		}
		if(TJpoker[i+3]==0||TJpoker[i+1]==0||TJpoker[i+2]==0){return _NULL;}
	}
 }
	return _NULL;
}
bool Suanfa::JDsandaidui_4(int *KJpoker)
{
	
		if(IntNumber(KJpoker)==5)
	{
		if(KJpoker[2]==KJpoker[4]&&KJpoker[0]==KJpoker[1]||KJpoker[0]==KJpoker[2]&&KJpoker[3]==KJpoker[4])
		{
		return true;
		}
	}
	return false;
}
Moves Suanfa::TPsandaidui_4(int *KJpoker,int TJpoker[],int quit)
{
		int a[6]={0};
	//int j=0;
	if(quit==1)
	{
       if(IntNumber(TJpoker)==5)
	   {
		   
		if(KJpoker[2]<TJpoker[2]&&TJpoker[2]==TJpoker[4]&&TJpoker[0]==TJpoker[1]||TJpoker[0]==TJpoker[3]&&TJpoker[3]==TJpoker[4])
		{
			a[0]=TJpoker[0];a[1]=TJpoker[1];a[2]=TJpoker[2];a[3]=TJpoker[3];a[4]=TJpoker[3];a[4]=TJpoker[4];a[5]=0;
			Chupai(a,quit);
			return _sandaidui;
		}
	   }
	}
	else
	{
		if(IntNumber(TJpoker)<5){return _NULL;}
	for(int i=0;TJpoker[i]!=0;i++)
   {
	 //  if(TJpoker[i+1]==0){return _NULL;}
		if(KJpoker[2]<TJpoker[i]&&TJpoker[i]==TJpoker[i+2])
		{
			if(TJpoker[i]==TJpoker[i+3])
			{
				i++;
			}
			else
			{

			a[0]=TJpoker[i];a[1]=TJpoker[i+1];;a[2]=TJpoker[i+2];a[5]=0;
			for(int j=0;TJpoker[j]!=0;j++)
                   {
					   if(TJpoker[j]!=TJpoker[j+1]||TJpoker[j]==a[0]){j++;}
					   else
					   {
						   a[3]=TJpoker[j];
						   a[4]=TJpoker[j+1];
						   if(IntNumber(a)!=5)return _NULL;
						   Chupai(a,quit);
			               return _sandaidui;
					   }
					   if(TJpoker[j+2]==0){return _NULL;}
		           }
			}
		}
		if(TJpoker[i+3]==0||TJpoker[i+1]==0||TJpoker[i+2]==0){return _NULL;}
	}
 }
	return _NULL;
}
bool Suanfa::JDshunzi_5(int *KJpoker)
{
	
	if(IntNumber(KJpoker)<5){return false;}
	   for(int i=0;KJpoker[i+1]!=0;i++)
	   {
		   if(KJpoker[i]!=KJpoker[i+1]-1||KJpoker[i+1]>=13){return false;}
	   }
	return true;
}
Moves Suanfa::TPshunzi_5(int *KJpoker,int TJpoker[],int quit)
{
    int a[15]={0};
	int j=IntNumber(KJpoker);
	if(quit==1)
	{
       if(IntNumber(TJpoker)==j&&KJpoker[0]<TJpoker[0])
	   {
		  if(JDshunzi_5(TJpoker)==false){return _NULL;}

		   Chupai(TJpoker,quit);
			return _shunzi;
	   }
	}
	else
	{      
		if(IntNumber(TJpoker)<j){return _NULL;}
		int ah[15],sh=1;ah[0]=TJpoker[0];

		for(int i=1;TJpoker[i]!=0;i++)
		{
			
			if(ah[sh-1]==TJpoker[i]){i++;}
			else
			{
				ah[sh]=TJpoker[i];
				sh+=1;
			}
			if(TJpoker[i+1]>=13){break;}
		}
		
           ah[sh]=0;
		   int bh=0,i=0;
		   if(IntNumber(ah)<j){return _NULL;}

		   for(i=0;ah[i]!=0;i++)
		   {
			   if(ah[i]>KJpoker[0]){break;}
		   }

		   if(IntNumber(ah)-i+1<j){return _NULL;}
		  
		   for(i=i;ah[i]!=0;i++)
		   {

			   if(ah[i]+1==ah[i+1])
			   {
				   bh+=1;
				   if(bh==j-1)
				   {
					   j=0;j=0;i=i;
					  for(bh=i-bh+1;bh<=i+1;bh++)
					  {
						  a[j++]=ah[bh];
					  }
					   a[j]=0;
					   Chupai(a,quit);
			         return _shunzi;
				   }
			   }
			   else
			   {
				   bh=0;
			   }
		   }
	}
	return _NULL;

}
bool Suanfa::JDliandui_6(int *KJpoker)
{
	if(m_Moves!=_NULL){return false;}

	int j=IntNumber(KJpoker);
	if(j<6||j%2!=0){return false;}

	//int m_number;
	   for(int i=0;KJpoker[i+2]!=0;i++)
	   {
		   if(KJpoker[i]==KJpoker[i+1]&&KJpoker[i+1]<13)
		   {
			  if(KJpoker[i]==KJpoker[i+3]-1&&KJpoker[i+2]==KJpoker[i+3])
			  {
			   i++;
			  }
			  else{  return false;}
		   }
		   else
		   {
			   return false;
		   }
	   }
		return true;
}
Moves Suanfa::TPliandui_6(int *KJpoker,int TJpoker[],int quit)
{
    int a[19]={0};
	int j=IntNumber(KJpoker);
	if(quit==1)
	{
       if(IntNumber(TJpoker)==j&&KJpoker[0]<TJpoker[0])
	   {
		   if(JDliandui_6(TJpoker)==false){return _NULL;}
		   Chupai(TJpoker,quit);
		   return _liandui;
	   }
	}
	else
	{      
		if(IntNumber(TJpoker)<j){return _NULL;}

		 int ah[19],sh=0;

		for(int i=0;TJpoker[i]!=0;i++)
		{
			if(TJpoker[i+1]>=12||TJpoker[i]>=12)break;
			if(TJpoker[i]==TJpoker[i+1]){ah[sh++]=TJpoker[i];ah[sh++]=TJpoker[i+1];i++;}
			if(TJpoker[i+1]==0||TJpoker[i+1]>=12){break;}
		}
		ah[sh]=0;
		   int bh=0,i=0;
		   if(IntNumber(ah)<j){return _NULL;}
		   for(i=0;ah[i]!=0;i++)
		   {
			   if(ah[i]>KJpoker[0]){break;}
		   }

		   if(IntNumber(ah)-i+1<j){return _NULL;}
		  
		   for(i=i;ah[i]!=0;i++)
		   {
			   if(ah[i]==ah[i+1])
			   {
				   if(bh>1)
				   {
					   if(ah[i-1]+1!=ah[i]){bh=0;}
				   }
				   bh+=2;
				   i++;
				   if(bh==j)
				   {

					   j=0;j=0;i=i;
					  for(bh=i-bh+1;bh<=i;bh++)
					  {
						  if(!(ah[bh]>=12))
						  a[j++]=ah[bh];
					  }
					   a[j]=0;
					   if(IntNumber(a)<6)return _NULL;
					   Chupai(a,quit);
			         return _liandui;
				   }
			   }
			   else
			   {
				   bh=0;
			   }
		   }
	}
	return _NULL;
}

	

	
	
	
	
	

	
	
	