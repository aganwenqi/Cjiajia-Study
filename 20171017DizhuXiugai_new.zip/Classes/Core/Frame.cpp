#include "Frame.h"
using std::string;
Frame::Frame()
{
	initial();
}
/*��ʼ��*/
void Frame::initial()
{
	Number[0]=0;

    setpokers12("","");
	m_FivePoker=false;
}

void Frame::setpokers12(string a,string b)
{
	poker=a;yourpokers=b;
}

Frame* Frame::m_Frame=NULL;
Frame* Frame::getInstance()
{
	if(m_Frame==NULL)
	{
		m_Frame=new Frame();
	}
	return m_Frame;
}
void Frame::setyourpoker(string one1)
{
	yourpokers=one1;
}