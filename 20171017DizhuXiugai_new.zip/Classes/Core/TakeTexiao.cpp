#include "TakeTexiao.h"
#include "SimpleAudioEngine.h"
USING_NS_CC;
TakeTexiao::TakeTexiao()
{
}
TakeTexiao::~TakeTexiao()
{
}
bool TakeTexiao::init()
{
	return true;
}
/*ִ����Ч*/
void TakeTexiao::RunEffect(Moves m_Moves)
{
	if(m_Moves==_zhadan||m_Moves==_wangzha)
		zhadan();
	else if(m_Moves==_feiji||m_Moves==_feijidai1||m_Moves==_feijidai2)
		feiji();
	else if(m_Moves==_liandui)
		liandui();
}
void TakeTexiao::zhadan()
{
	auto size=Director::getInstance()->getVisibleSize();
	auto sprite=Sprite::create("sprite/TexiaoSprite/zhadan1.png");
	sprite->setPosition(this->convertToNodeSpace(Point(550,600)));
	this->addChild(sprite,1);

	auto moveto=MoveTo::create(0.5f,this->convertToNodeSpace(Point(500,250)));
	auto Scaleto=ScaleTo::create(0.5f,1.5);
	auto acc=Spawn::create(moveto,Scaleto,NULL);
	
    CallFunc* call=CallFunc::create([=](){
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/zhadanbaozha.mp3");
	auto sprite1=Sprite::create("sprite/TexiaoSprite/zhadan2.png");
	sprite1->setPosition(sprite->getPosition());
	this->addChild(sprite1,1);
	sprite1->setAnchorPoint(Point(0.5,0));
	sprite1->setScale(0.2f);
    this->removeChild(sprite);

	CallFunc* call=CallFunc::create([=](){
	this->removeChild(sprite1);
	});
	auto scale=ScaleTo::create(0.4f,2);
	auto scale1=ScaleTo::create(0.3f,0);
	auto action1=Sequence::create(scale, scale1,NULL);
	sprite1->runAction(action1);
	});
	auto action=Sequence::create(acc,call,NULL);
	
	sprite->runAction(action);
	 
}
void TakeTexiao::feiji()
{
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/planeTeixiao.mp3");
	auto size=Director::getInstance()->getVisibleSize();
	auto sprite=Sprite::create("sprite/TexiaoSprite/feiji.png");
	sprite->setPosition(this->convertToNodeSpace(Point(950,300)));
	this->addChild(sprite,1);
	auto moveto=MoveTo::create(1.2f,this->convertToNodeSpace(Point(0,300)));

	CallFunc* call=CallFunc::create([=](){
	this->removeChild(sprite);
	});
	auto action=Sequence::create(moveto,call,NULL);
	sprite->runAction(action);
}
void TakeTexiao::liandui()
{
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/lianduiTeXiao.mp3");
	auto size=Director::getInstance()->getVisibleSize();
	auto sprite=Sprite::create("sprite/TexiaoSprite/liandui.png");
	sprite->setPosition(this->convertToNodeSpace(Point(800,400)));
	this->addChild(sprite,1);
	auto moveto=MoveTo::create(0.5f,this->convertToNodeSpace(Point(600,350)));
	auto func1=FadeIn::create(0.5f);

	auto moveto2=MoveTo::create(0.5f,this->convertToNodeSpace(Point(200,300)));
	auto func2=FadeOut::create(0.5f);

	auto acc=Spawn::create(moveto,func1,NULL);
	auto moveto1=MoveTo::create(0.5f,this->convertToNodeSpace(Point(400,250)));
	auto acc2=Spawn::create(moveto2,func2,NULL);

	CallFunc* call=CallFunc::create([=](){
	this->removeChild(sprite);
	});
	auto action=Sequence::create(acc,moveto1,acc2,call,NULL);
	sprite->runAction(action);
}