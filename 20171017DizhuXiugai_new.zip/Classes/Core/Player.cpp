#include "Player.h"
#include "List.h"
#include "Poker.h"
#include "Suanfa.h"

Player*Player::m_Player=NULL;
Player*Player::getInstance()
{
	if(m_Player==NULL)
	{
		m_Player=new Player();
	}
	return m_Player;
}
Moves Player::Thecards(int *poker,int Who)//����
{
	if(getLTpoker()==Frame::getInstance()->getpoker())
	{
		Frame::getInstance()->setpoker("");
		if(poker[0]==100)
	     return _first;
	}
	else if(poker[0]==100)
	     return _buyao;

	/*ִ�ж���*/
	Paixing=Suanfa::getInstance()->addDuipai(poker,Who);
	return Paixing;
}
 Player::Player()
 {
 }
 Player::~Player()
 {

 }

