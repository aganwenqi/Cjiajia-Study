#ifndef _LIST_H_
#define _LIST_H_
#include "Laoda.h"
#include "Poker.h"
#include "cocos2d.h"
class List:public Ref
{
public:
	List();
	~List();
	Poker m_poker;
	List* next;

};
#endif