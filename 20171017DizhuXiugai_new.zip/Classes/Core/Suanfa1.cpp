#include "Suanfa.h"
#include "List.h"
#include "Poker.h"
#include "Player.h"
#include "RobotOne.h"
#include "RobotTwo.h"
bool Suanfa::JDfeiji_7(int *KJpoker)
{
	if(m_Moves!=_NULL)
	{
		return false;
	}
	int j=IntNumber(KJpoker);

	if(j<6||j%3!=0){return false;}
	 j=0;
	   for(int i=0;KJpoker[i+5]!=0;i++)
	   {
		   if(KJpoker[i]==KJpoker[i+2]&&KJpoker[i+2]+1==KJpoker[i+5])
		   {
			 j++;
			 if(KJpoker[i+6]==0||KJpoker[i+7]==0||KJpoker[i+8]==0)
			 {
				 break;
			 }

			 i+=2;
		   }
		   else 
		   {
			   j=0;
		   }
	   }

	   if(j)
	   {
            return true;
	   } 
		return false;
}
Moves Suanfa::TPfeiji_7(int *KJpoker ,int TJpoker[],int quit)
{
	int a[19]={0};
	int j=IntNumber(KJpoker);
	if(quit==1)
	{
       if(IntNumber(TJpoker)==j&&KJpoker[0]<TJpoker[0])
	   {
		   if(JDfeiji_7(TJpoker)==false){return _NULL;}
		   Chupai(TJpoker,quit);
			return _feiji;
	   }
	}
	else
	{      
		if(IntNumber(TJpoker)<j){return _NULL;}

		 int ah[19],sh=0;

		for(int i=0;TJpoker[i]!=0;i++)
		{
			if(TJpoker[i]==TJpoker[i+2]){ah[sh++]=TJpoker[i];ah[sh++]=TJpoker[i+1];ah[sh++]=TJpoker[i+2];i++;i++;}
			if(TJpoker[i+1]==0&&TJpoker[i+2]==0){break;}
		}
		ah[sh]=0;
		   int i=0,c=0;
		   if(IntNumber(ah)<j){return _NULL;}
	
		   for(i=0;ah[i]!=0;i++)
		   {
			   if(ah[i+2]==0){break;}

			   if(ah[i]>KJpoker[c]&&ah[i+2]==ah[i])
			   {
				   if(c!=0)
				   {
					   if(ah[i-1]+1!=ah[i]){c=0;}
				   }
				   i+=2;
				   c+=3;
				   if(c==j){
					       sh=0;
					    for(j=i-c+1;j<=i;j++)
					   {
						    a[sh++]=ah[j];
					   }
						a[sh]=0;
						Chupai(a,quit);
			         return _santiao;
				           }
			   }
			   else
			   {
				   c=0;
			   }
			   if(ah[i+2]==0){break;}
		   }
		}  

	return _NULL;
}
bool Suanfa::JDfeijidai2_8(int *KJpoker)
{
	    if(m_Moves!=_NULL){return false;}

		if(IntNumber(KJpoker)!=8){return false;}
		for(int i=0;i<=2;i++)
		{
			if(KJpoker[i]==KJpoker[i+2]&&KJpoker[i]==KJpoker[5]-1)
			{
				return true;
			}
		}
		return false;
}

Moves Suanfa::TPfeijidai2_8(int *KJpoker,int TJpoker[],int quit)
{
	int a[19]={0};
	int j=IntNumber(KJpoker);

	if(quit==1)
	{
		if(IntNumber(TJpoker)!=8){return _NULL;}
       if(IntNumber(TJpoker)==j&&KJpoker[2]<TJpoker[2])
	   {
		   if(JDsandaidui_4(TJpoker)==false){return _NULL;}
		   Chupai(TJpoker,quit);
			return _feijidai2;
	   }
	}
	else
	{      
		if(IntNumber(TJpoker)<j){return _NULL;}

		 int ah[19]={0},sh=0;

		for(int i=0;TJpoker[i]!=0;i++)
		{
			if(TJpoker[i]==TJpoker[i+2]){ah[sh++]=TJpoker[i];ah[sh++]=TJpoker[i+1];ah[sh++]=TJpoker[i+2];i++;i++;}
			if(TJpoker[i+1]==0&&TJpoker[i+2]==0){break;}
		}
		   ah[sh]=0;
		   int i=0;
		   if(IntNumber(ah)<j){return _NULL;}
	
		   for(i=0;ah[i+5]!=0;i++)
		   {
			   if(ah[i]>KJpoker[2])
			   {
				if(ah[i]==ah[i+2]&&ah[i]==ah[i+5]-1)
				{
							a[0]=ah[i];a[1]=ah[i+1];a[2]=ah[i+2];a[3]=ah[i+3];a[4]=ah[i+4];a[5]=ah[i+5];
							
                   sh=100;
		   for(i=0;TJpoker[i];i++)
		   {
			   if(sh!=100)
			   {
				   if(TJpoker[i]!=a[2]&&TJpoker[i]!=a[3]&&i!=sh)
			   {
				   a[7]=ah[i];a[8]=0;
				   Chupai(a,quit);
				   return _feijidai2;
			   }
			   }
			   else if(TJpoker[i]!=a[2]&&TJpoker[i]!=a[3])
			   {
				   a[6]=ah[i];
				   sh=i;
			   }
		   }

				}
			   }
		   }

		}  
	return _NULL;
}
bool Suanfa::JDzhadan_9(int *KJpoker)
{
	int i=IntNumber(KJpoker);
	if(m_Moves!=_NULL){return false;}
	if(i==2||KJpoker[0]==14||KJpoker[1]==15){return false;}
	//if(i<3){return false;}
	return true;
}
Moves Suanfa::TPzhadan_9(int *KJpoker,int TJpoker[],int quit)
{

	int j=IntNumber(KJpoker);
	if(IntNumber(TJpoker)<4){return _NULL;}
	if(IntNumber(TJpoker)==4){if(TJpoker[0]!=TJpoker[3])return _NULL;}
	if(quit==1)
	{
       if(IntNumber(TJpoker)==j&&KJpoker[0]==KJpoker[3]&&KJpoker[0]<TJpoker[0])
	   {
		   if(TJpoker[0]!=TJpoker[3]){return _NULL;}
		   Chupai(TJpoker,quit);
		   return _zhadan;
	   }
	   else
	   {
		   if(TJpoker[0]!=TJpoker[3]){return _NULL;}
		   Chupai(TJpoker,quit);
		   return _zhadan;
	   }
	}
	else
	{      
		 int ah[5]={0},sh=0;
		 
		for(int i=0;TJpoker[i+3]!=0;i++)
		{
			if(j==4&&KJpoker[0]==KJpoker[3])
			{
			if(TJpoker[i]==TJpoker[i+3]&&TJpoker[i]>KJpoker[1]){ah[sh++]=TJpoker[i];ah[sh++]=TJpoker[i+1];ah[sh++]=TJpoker[i+2];ah[sh++]=TJpoker[i+3];break;}
			}
			else
			{
				if(TJpoker[i]==TJpoker[i+3]){ah[sh++]=TJpoker[i];ah[sh++]=TJpoker[i+1];ah[sh++]=TJpoker[i+2];ah[sh++]=TJpoker[i+3];break;}
			}
		}
		if(ah[0]==0){return _NULL;}
		ah[sh]=0;
		bool m_Duiyou=false;
		if(quit==2){m_Duiyou=this->ShibieDY(m_RobotOne->getRole());}
		if(quit==3){m_Duiyou=this->ShibieDY(m_RobotTwo->getRole());}
		   int i=0;
		   if(IntNumber(TJpoker)<6)
		   {
			   Chupai(ah,quit);
			return _zhadan;
		   }
		   if(j>15)
		   {
			   if(!m_Duiyou)
			   {
				   return _NULL;
			   }
			    Chupai(ah,quit);
				return _zhadan;
		   }
		   else if(j>10)
		   {
                if(!m_Duiyou)
			   {
				   return _NULL;
			   }
				if(RAND_0_9()>0.1f)
				{
			    Chupai(ah,quit);
				return _zhadan;
				}
				return _NULL;
		   }
		   else if(j>5)
		   {
			   if(!m_Duiyou)
			   {
				   return _NULL;
			   }
				if(RAND_0_9()>0.2f)
				{
			    Chupai(ah,quit);
				return _zhadan;
				}
				return _NULL;
		   }
		   else 
		   {
			   if(!m_Duiyou)
			   {
				   return _NULL;
			   }
				if(RAND_0_9()>0.5f)
				{
			    Chupai(ah,quit);
				return _zhadan;
				}
				return _NULL;
		   }
	}
	return _NULL;
}
bool Suanfa::JDsidai1_10(int *KJpoker)
{
	//����
	return false;
}
Moves Suanfa::TPsidai1_10(int *KJpoker,int TJpoker[],int quit)
{//����
	return _wangzha;
}
bool Suanfa::JDsidai2_11(int *KJpoker)
{
	if(m_Moves!=_NULL){return false;}
	if(IntNumber(KJpoker)!=6){return false;}
		for(int i=0;i<=2;i++)
		{
			if(KJpoker[i]==KJpoker[i+3])
			{
				return true;
			}
		}

		return false;
}
Moves Suanfa::TPsidai2_11(int *KJpoker,int TJpoker[],int quit)
{
	return _NULL;
}
bool Suanfa::JDwangzha_12(int *KJpoker)
{
	if(m_Moves!=_NULL){return false;}
	return true;
}

Moves Suanfa::TPwangzha_12(int *KJpoker,int TJpoker[],int quit)
{
	int j=IntNumber(KJpoker);
	if(IntNumber(TJpoker)!=2){return _NULL;}
	if(IntNumber(TJpoker)==2){if(TJpoker[0]!=14||TJpoker[1]!=15)return _NULL;}
	if(quit==1)
	{
		    Chupai(TJpoker,quit);
			return _wangzha;
	}
	else
	{      
		 int ah[3]={0},sh=0;
		for(int i=0;TJpoker[i+1]!=0;i++)
		{
				if(TJpoker[i]==14&&TJpoker[i+1]==15)
				{ah[sh++]=TJpoker[i];ah[sh++]=TJpoker[i+1];break;}
		}
		if(ah[0]==0){return _NULL;}
		bool m_Duiyou=true;
		bool  m_Friend;
		if(quit==2){m_Duiyou=this->ShibieDY(m_RobotOne->getRole()); m_Friend=ShibieDY(m_RobotOne->getRole());}
		if(quit==3){m_Duiyou=this->ShibieDY(m_RobotTwo->getRole()); m_Friend=ShibieDY(m_RobotTwo->getRole());}

		int s[21];
		int FriendPokerNum;//���˻��ж�����

	    JiePoker(TablePokerPeople()->getPokerData(),s);
	    FriendPokerNum=IntNumber(s);//���˻��ж�����

	if(!m_Friend&&FriendPokerNum<=7)
	{
		  Chupai(ah,quit);
			return _zhadan;
	}
		ah[sh]=0;
		   int i=0;
		   if(IntNumber(TJpoker)<4)
		   {
			   Chupai(ah,quit);
			return _zhadan;
		   }
		   if(j>15)
		   {
			   if(!m_Duiyou)
			   {
				   return _NULL;
			   }
			    Chupai(ah,quit);
				return _zhadan;
		   }
		   else if(j>10)
		   {
                if(!m_Duiyou)
			   {
				   return _NULL;
			   }
				if(RAND_0_9()>0.1f)
				{
			    Chupai(ah,quit);
				return _zhadan;
				}
				return _NULL;
		   }
		   else if(j>5)
		   {
			   if(!m_Duiyou)
			   {
				   return _NULL;
			   }
				if(RAND_0_9()>0.3f)
				{
			    Chupai(ah,quit);
				return _zhadan;
				}
				return _NULL;
		   }
		   else if(j<=6&&j>3)
		   {
			   if(!m_Duiyou)
			   {
				   return _NULL;
			   }
				if(RAND_0_9()>0.4f)
				{
			    Chupai(ah,quit);
				return _zhadan;
				}
				return _NULL;
		   }
		   else if(j<=3)
		   {
			   if(!m_Duiyou)
			   {
				   return _NULL;
			   }
				if(RAND_0_9()>0.5f)
				{
			    Chupai(ah,quit);
				return _zhadan;
				}
				return _NULL;
		   }
	}
	return _NULL;
}