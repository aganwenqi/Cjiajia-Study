#ifndef _PLAYER_H_
#define _PLAYER_H_
#include "Common.h"
#include<iostream>
#include<string>
#include "Frame.h"
#include "Enum.h"
class Poker;
class List;
class Player:public Common
{
public:
	 Player();
	 ~Player();
	static Player* getInstance();

	/*����*/
	virtual Moves Thecards(int *poker,int Who);

private: 
	static Player* m_Player;
	
};
#endif