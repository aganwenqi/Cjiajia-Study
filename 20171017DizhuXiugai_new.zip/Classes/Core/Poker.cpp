#include "Poker.h"
Poker::Poker()
{		
	zhongzhi = false;
}
Poker::~Poker()
{
}
	
