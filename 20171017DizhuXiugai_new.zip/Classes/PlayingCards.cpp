#include "PlayingCards.h"
#include "Entity.h"
#include "CsvUtil.h"
#include "Enum.h"
#include "Route.h"
PlayingCards::PlayingCards()
{
	m_State=false;
}
PlayingCards::~PlayingCards()
{
}
	
bool PlayingCards::init()
{

	return true;
}

PlayingCards *PlayingCards::createPoker(int i)
{
	  PlayingCards* playingcard = new PlayingCards();

    if (playingcard && playingcard->initPoker(i)) {
        playingcard->autorelease();
		//playingcard->retain();
    }
    else {
        CC_SAFE_DELETE(playingcard);
    }
    return playingcard;
}
bool PlayingCards::initPoker(int i)
{
	do{
	    CsvUtil* csvUtil = CsvUtil::getInstance();
		std::string sPokerID = StringUtils::format("%d",i);

		/* Ѱ��ID���ڵ��� */
        int iLine = csvUtil->findValueInWithLine(sPokerID.c_str(),
            0,"Poker.csv");
		CC_BREAK_IF(iLine < 0);
		setID(i);
		/*�����˿��ƵĴ�С*/
		setSize(csvUtil->getInt(iLine,PokerType_Size,"Poker.csv"));
		/*�����˿��ƺ�*/
		setNum(csvUtil->get(iLine,PokerType_Num,"Poker.csv")[0]);
	  
	   return true;
	}while(0);
	   return false;
}
/*�����˿���*/
void PlayingCards::CreateSprite()
{
	std::string m_string=StringUtils::format("sprite/PokerSprites/G%d.png",this->getID());
	Sprite* m_sprite=Sprite::create(m_string);
	m_sprite->setAnchorPoint(Point(0,0));
    this->setSprite(m_sprite);


	
}