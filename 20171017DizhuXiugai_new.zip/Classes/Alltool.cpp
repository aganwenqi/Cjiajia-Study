#include "Alltool.h"
#include "Define.h"
float Alltool::getSrand()
{
	srand((unsigned)time(NULL));
	float ah;
	for(int i=0;i<6;i++)
	 ah=RAND_0_9();
	return ah;
}