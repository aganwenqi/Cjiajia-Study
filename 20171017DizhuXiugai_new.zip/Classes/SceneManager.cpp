#include "SceneManager.h"
#include "PokerScene.h"
#include "MainScene.h"
#include "HelloWorldScene.h"
#include "MoxingManager.h"
#include "LianwangScene.h"
#include "DengluScene.h"
#include "NetRoom.h"
#include "NetRoom1.h"
#include "ServerLever.h"

USING_NS_CC;
SceneManager * SceneManager::m_SceneManager = NULL;
SceneManager * SceneManager::getInstance()
{
	if(m_SceneManager == NULL)
	{
		m_SceneManager = new SceneManager();
		if(m_SceneManager && m_SceneManager->init())
		{
			m_SceneManager->autorelease();
			m_SceneManager->retain();
		}
		else
		{
			CC_SAFE_DELETE(m_SceneManager);
		}
	}
	return m_SceneManager;
}
bool SceneManager::init()
{
	return true;
}
void SceneManager::changeScene(EnumSceneType enSceneType)//�л�����
{
	Scene *pScene=NULL;
	switch(enSceneType)
	{
	case en_Began:       /* ��ͷ���� */
		pScene = HelloWorld::createScene();
		break;
	case en_ManScene:       /* ���˵����� */
		pScene = MainScene::createScene();
		break;
	case en_PokerScene: /* �������г��� */
		pScene = PokerScene::createScene();
		break;
	case en_wangluo: /* ���ӳ��� */
		pScene = LianwangScene::createScene();
		break;
	case en_Denglu: /* ��¼���� */
		pScene = DengluScene::createScene();
		break;
	case en_NetRoom: /* �������� */
		pScene = NetRoom::createScene();
		break;
	case en_NetRoom1: /* ��������1 */
		pScene = NetRoom1::createScene();
		break;
	case en_ServerLever: /* ���������߳��� */
		pScene = ServerLever::createScene();
		break;
	}
	Director *pDirector=Director::getInstance();
	Scene *cunScene = pDirector->getRunningScene();//��ȡ�������еĳ���
	if(cunScene == NULL)
	{
		pDirector->runWithScene(pScene);
	}
	else
	{
		pDirector->replaceScene(pScene);
	}
}