#ifndef _RobotTwoD_H_
#define _RobotTwoD_H_
#include "Robot.h"
class RobotTwoD:public Robot
{
public:
	RobotTwoD();
	~RobotTwoD();
	CREATE_FUNC(RobotTwoD);

	virtual void CreateSprite();

	
	/*�����Լ����ݽ�ɫ��ͼƬ*/
	virtual void CreateJiaoseSprite(int i);
	
private:

};
#endif