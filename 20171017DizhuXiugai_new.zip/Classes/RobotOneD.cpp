#include "RobotOneD.h"
RobotOneD::RobotOneD()
{
	WhoRobot=2;
}
RobotOneD::~RobotOneD()
{
}
void RobotOneD::CreateSprite()
{
	if(m_sprite)
	{
	m_Chupai->setVisible(false);
		return;
	}
	/*��*/
	m_sprite=Sprite::create("sprite/MonsterPoker.png");
	m_sprite->setPositionY(100);
	this->addChild(m_sprite);

	/*������*/
	label=Label::create("","Arial",70);
	label->setColor(Color3B::BLUE);
	label->setPosition(Point(m_sprite->getContentSize()/2));
	m_sprite->addChild(label);
	m_sprite->setVisible(false);

	m_Chupai=Sprite::create("sprite/Chupai.png");
	m_Chupai->setPosition(Point(190,m_Chupai->getContentSize().height+50));
	this->addChild(m_Chupai);
	m_Chupai->setVisible(false);

}
/*�����Լ����ݽ�ɫ��ͼƬ*/
void RobotOneD::CreateJiaoseSprite(int i)
{

	if(m_Chuyin)
	{
	removeChild(m_Jiase,true);
	m_Jiase=NULL;
	removeChild(m_Chuyin,true);
	m_Chuyin=NULL;
	}

    std::string m_string=StringUtils::format("sprite/Chuyin%d.png",i);
	m_Chuyin=Sprite::create(m_string);
	m_Chuyin->setPositionX(190);
	this->addChild(m_Chuyin);

	m_string=StringUtils::format("sprite/jiaose%d.png",i);
	m_Jiase=Sprite::create(m_string);
	m_Jiase->setPositionX(m_Chuyin->getPositionX()+75);
	this->addChild(m_Jiase);

	/*�ҵ�����*/
	m_Myname=Label::create("RobotOne","Arial",30);
	m_Myname->enableShadow(Color4B::BLUE, Size(0, 0)); //��Ӱ
	m_Myname->setPosition(Point(m_Chuyin->getBoundingBox().getMaxX()*0.8,m_Chuyin->getPositionY()-m_Chuyin->getBoundingBox().getMaxY()-10));
	m_Myname->setColor(Color3B::RED);
	this->addChild(m_Myname);
	GirlStop();
}