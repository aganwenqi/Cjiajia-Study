#include "HelloWorldScene.h"
#include "AllManager.h"
#include "Route.h"
#include "SceneManager.h"
#include "SimpleAudioEngine.h"
#include "MusicManager.h"
Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{	
   if(!Layer::init())
	return false;

    MusicManager::PlayBackgroundMusic("music/Fade.mp3",true);
	PlayAnimation();
    return true;
}
void HelloWorld::PlayAnimation()
{
	 Size Size=Director::getInstance()->getVisibleSize();
     auto sprite1=Sprite::create("sprite/kaitou/kaitouzhu1.png");
	 sprite1->setPosition(Point(Size.width/2,Size.height/2));
	 this->addChild(sprite1,1);
	 auto sprite2=Sprite::create("sprite/kaitou/kaitouzhu2.png");
	 sprite2->setPosition(Point(355.5,250));
	 this->addChild(sprite2,2);

	 auto sprite3=Sprite::create("sprite/kaitou/kaitouzhu3.png");
	 sprite3->setPosition(Point(Size.width/2,Size.height/2));
	 this->addChild(sprite3,3);

	 auto Xuanzhuan=RotateBy::create(1.0f,360,360);
	 auto chongfu=Repeat::create(Xuanzhuan,4);
     
	 auto func=CallFunc::create([=](){
		 if(UserDefault::getInstance()->getIntegerForKey("Jiancha",520)==0)
		 {
			 menuCloseCallback();
		 }
		 else
		 {
			 UserDefault::getInstance()->setIntegerForKey("Jiancha",0);
			 this->removeChild(sprite1);
			 this->removeChild(sprite2);
			 this->removeChild(sprite3);
			 auto label=Label::create("Welcome","Arial",150);
			 label->setPosition(Point(Size.width/2,Size.height/2));
			 this->addChild(label);
			 label->setScale(0);

			 auto func1=CallFunc::create([=](){
				 menuCloseCallback();
			 });
			 auto func2=CallFunc::create([=](){
			 MusicManager::PlayEffectMusic("music/Button.mp3");
			 });
			 auto Big=ScaleTo::create(0.5f,1);
			 auto move=MoveBy::create(2.0f,Point(0,0));
			 auto Big1=ScaleBy::create(0.5f,0);
			 auto Actions=Sequence::create(Big,func2,move,Big1,func1,NULL);
			 label->runAction(Actions);
		 }
	 });
	 auto Actions=Sequence::create(chongfu,func,NULL);
	 sprite2->runAction(Actions);
}
void HelloWorld::menuCloseCallback()
{
	SceneManager::getInstance()->changeScene(SceneManager::en_ManScene);
}
