#include "Newcards.h"
#include "PlayingCards.h"
#include "Route.h"
#include "SimpleAudioEngine.h"
Newcards::Newcards()
{
	m_Jiase=NULL;
    m_Chuyin=NULL;
	m_Chupai=NULL;
    m_ZhiNeng=NULL;
    m_BuYao=NULL;
	m_ChuPai=NULL;
	m_Myname=NULL;
	m_Tuoguan=false;
}
Newcards::~Newcards()
{
}
bool Newcards::init()
{
	return true;
}
bool Newcards::init(int *a)
{
	Size visibleSize=Director::getInstance()->getVisibleSize();
	bool state=false;
	for(auto i:PlayingCardsVT)
	{
		i->removeFromParent();
	}
	PlayingCardsVT.clear();
	do{
		/*�����˿���*/
	PlayingCards *m_cards;
	for(int i=0;a[i]!=0;i++)
	{
	
	m_cards=PlayingCards::createPoker(a[i]);
	CC_BREAK_IF(m_cards==NULL);

	m_cards->CreateSprite();
	m_cards->setVisible(false);
	m_cards->setContentSize(m_cards->getSprite()->getContentSize());
	 this->addChild(m_cards,PokerLayer);

	/*�������˿��ƴ浽����*/
	PlayingCardsVT.pushBack(m_cards);
	}
	AcitvationTouch();
	RowOfCards();
	addPlayPokersUI();
	state=true;
	}while(0);
	return state;
}
void Newcards::addPlayPokersUI()
{
	Size visibleSize=Director::getInstance()->getVisibleSize();
	do{
    if(m_ZhiNeng)
	{
		break;
	}
	auto UI=cocostudio::GUIReader::getInstance()->widgetFromJsonFile("UI/PlayUI/PlayUI_1.ExportJson");
	this->addChild(UI);
    UI->setPositionX(0-visibleSize.width/2);
	 /*��ȡ���ư�ť*/
    m_ZhiNeng=(Button*)Helper::seekWidgetByName(UI,"ZhiNeng");
	m_BuYao=(Button*)Helper::seekWidgetByName(UI,"BuYao");
	m_ChuPai=(Button*)Helper::seekWidgetByName(UI,"ChuPai");

	/*���Ӱ�ť���Ӽ���*/
    m_ZhiNeng->addTouchEventListener(this,toucheventselector(Newcards::ZhiNeng));
	m_BuYao->addTouchEventListener(this,toucheventselector(Newcards::BuYao));
	m_ChuPai->addTouchEventListener(this,toucheventselector(Newcards::ChuPai));
	}while(0);
    FunctionFalse();
}
void Newcards::CreateSprite()
{
	do{
	if(m_Chupai)
	{
		break;
	}
	m_Chupai=Sprite::create("sprite/Chupai.png");
	m_Chupai->setPosition(Point(-350,m_Chupai->getContentSize().height+235));
	this->addChild(m_Chupai);
	}while(0);
	m_Chupai->setVisible(false);
}
/*�����Լ����ݽ�ɫ��ͼƬ*/
void Newcards::CreateJiaoseSprite(int i)
{
	
	if(m_Chuyin)
	{
	removeChild(m_Jiase,true);
	m_Jiase=NULL;
	removeChild(m_Chuyin,true);
	m_Chuyin=NULL;
	}
	std::string m_string=StringUtils::format("sprite/Chuyin%d.png",i);
	m_Chuyin=Sprite::create(m_string);
	m_Chuyin->setPosition(Point(-350,185));
	this->addChild(m_Chuyin);

	m_string=StringUtils::format("sprite/jiaose%d.png",i);
	m_Jiase=Sprite::create(m_string);
	m_Jiase->setPosition(Point(m_Chuyin->getPositionX()-80,m_Chuyin->getPositionY()));
	this->addChild(m_Jiase);

	/*�ҵ�����*/
	m_Myname=Label::create("Player","Arial",30);
	m_Myname->enableShadow(Color4B::BLUE, Size(0, 0)); //��Ӱ
	m_Myname->setPosition(Point(-350,100));
	m_Myname->setColor(Color3B::RED);
	this->addChild(m_Myname);

	CreateSprite();
	GirlStop();
	FunctionFalse();
}
void Newcards::AcitvationTouch()
{
	/*����һ���¼�����������Ϊ OneByOne �ĵ��㴥��*/
    auto listener1 = EventListenerTouchOneByOne::create();
    // �����Ƿ���û�¼����� onTouchBegan �������� true ʱ��û
    listener1->setSwallowTouches(true);
	
     listener1->onTouchBegan = [](Touch* touch, Event* event){
	auto target = static_cast<Sprite*>(event->getCurrentTarget());
        
        Point locationInNode = target->convertToNodeSpace(touch->getLocation());
        Size s = target->getContentSize();
        Rect rect = Rect(0, 0, s.width, s.height);
       
        if (rect.containsPoint(locationInNode))
        {
            //log("sprite began... x = %f, y = %f", locationInNode.x, locationInNode.y);
          //  target->setOpacity(180);
            return true;
        }
        return false;
    };
    // ʹ�� lambda ʵ�� onTouchBegan �¼��ص�����
    listener1->onTouchEnded =[=](Touch* touch, Event* event){
        // ��ȡ�¼����󶨵� target 
        auto target = static_cast<PlayingCards*>(event->getCurrentTarget());
		 listener1->setSwallowTouches(true);
        // ��ȡ��ǰ�����������԰�ť��λ������
        Point locationInNode = target->convertToNodeSpace(touch->getLocation());
        Size s = target->getContentSize();
        Rect rect = Rect(0, 0, s.width, s.height);

        // �����Χ�жϼ��
        if (rect.containsPoint(locationInNode))
        {
			CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/SpecSelectCard.mp3");
           if(target->getState())
		   {
			   target->setPositionY(target->getPositionY()-20);
			   target->setState(false);
		   }
		   else
		   {
			   target->setState(true);
			   target->setPositionY(target->getPositionY()+20);
		   }
			
        }
        };
	// ���Ӽ�����
    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener1,PlayingCardsVT.front());
	
	for(auto i:PlayingCardsVT)
	{
	if(i==PlayingCardsVT.front())
		continue;
    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener1->clone(),i);
	}
}
