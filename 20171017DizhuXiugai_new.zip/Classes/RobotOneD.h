#ifndef _RobotOneD_H_
#define _RobotOneD_H_
#include "Robot.h"
class RobotOneD:public Robot
{
public:
	RobotOneD();
	~RobotOneD();
	CREATE_FUNC(RobotOneD);
	virtual void CreateSprite();

	/*�����Լ����ݽ�ɫ��ͼƬ*/
	virtual void CreateJiaoseSprite(int i);
	
private:


};
#endif