#include "TakePokers.h"
#include "PlayingCards.h"
#include "Route.h"
#include "TakeTexiao.h"
#include "SimpleAudioEngine.h"
USING_NS_CC;
TakePokers::TakePokers()
{
}
TakePokers::~TakePokers()
{
}
/*�����Զ�������*/
bool SortAllCardsVT(const PlayingCards *v1, const PlayingCards *v2)
{
	return v1->getSize()<=v2->getSize();
}
bool TakePokers::init()
{
	Size visibleSize=Director::getInstance()->getVisibleSize();
	bool state=false;
	do{
		/*�����˿���*/
	PlayingCards *m_cards;
	for(int i=1;i<=54;i++)
	{
	
	m_cards=PlayingCards::createPoker(i);
	CC_BREAK_IF(m_cards==NULL);

	m_cards->CreateSprite();
	m_cards->setVisible(false);
	m_cards->setContentSize(m_cards->getSprite()->getContentSize());

	/*�������˿��ƴ浽����*/
	AllCardsVT.pushBack(m_cards);
	}

   for(int i=1;i<AllCardsVT.size();i++)
	{
		for(int j=0;j<AllCardsVT.size()-i;j++)
		{
	   if(!SortAllCardsVT(AllCardsVT.at(j),AllCardsVT.at(j+1)))
		  AllCardsVT.swap(AllCardsVT.at(j),AllCardsVT.at(j+1));
		}  
	}
  for(auto i:AllCardsVT)
    {
        this->addChild(i,PokerLayer);
    }

    m_TakeTexiao=TakeTexiao::create();
	this->addChild(m_TakeTexiao,PokerTexiao);
	state=true;
	}while(0);
	return state;
}
/*���ӻص�*/
std::function<void(int*,Moves)> TakePokers::Function()
{
	std::function<void(int*,Moves)> p=[this](int *a,Moves m_Moves){CreateTakePokers(a,m_Moves);};
	return p;
}
void TakePokers::Reduction()
{
	for(auto i:AllCardsVT)
	{
		
		if(i->isVisible())
		{
			i->setVisible(false);
			i->setPositionX(0);
		}
	}
}
/*����*/
void TakePokers::RowOfCards()
{
	Vector<PlayingCards*> TrueCardsVT;
	int TotalWidth,size;

	for(auto i:AllCardsVT)
	{
		if(i->isVisible())
        TrueCardsVT.pushBack(i);
	}

	size=TrueCardsVT.size();
	if(size==0)return;
	TotalWidth=0;

	for(int i=1;i<=size-1;i++)
	{
		TotalWidth+=25;
	}
	TotalWidth+=105;
	TotalWidth=0-TotalWidth/2;
	for(auto i:TrueCardsVT)
	{
		i->setPositionX(TotalWidth);
		TotalWidth+=25;
	}
}
void TakePokers::CreateTakePokers(int a[],Moves m_Moves)
{
	std::mutex m_mutex;
	Reduction();
    for(int i=0;a[i]!=0;i++)
	{
		for(auto h:AllCardsVT)
		{
			if(h->getID()==a[i])
		    h->setVisible(true);
		}
	}
	RowOfCards();
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/dapai.mp3");
	/*ִ����Ч*/
	m_TakeTexiao->RunEffect(m_Moves);
}
