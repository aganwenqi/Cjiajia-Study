#ifndef _ENUM_H_
#define _ENUM_H_
enum m_enum{
	_Heitao,
	_Hongtao,
	_Fangkuai,
	_Meihua,
	_w,
	_W
};

enum JiaoSe{
	_Player,
	_RobotOne,
	_RobotTwo
};

//��ս��������
enum Moves
{
	_dan=1,
	_duizi,
	_santiao,
	_sandaiyi,
	_sandaidui,
	_shunzi,
	_liandui,
	_feiji,
	_feijidai1,
	_feijidai2,
	_zhadan,
	_sidai1,
	_sidai2,
	_wangzha,
	_NULL,
	_end,
	_first,
	_buyao
};
enum PokerType 
{
	PokerType_ID,		// �˿�ID
	PokerType_Name,    // �˿�����
	PokerType_Size,		// �˿˴�С
    PokerType_Num,	// �˿˺�
};
enum NetFunc
{
	_denglu,
};
#endif