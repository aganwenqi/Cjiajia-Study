#ifndef _PlayingCards_H_
#define _PlayingCards_H_

#include "Entity.h"
#include "Define.h"
class PlayingCards:public Entity
{
public:
	PlayingCards();
	~PlayingCards();
	CREATE_FUNC(PlayingCards);
	virtual bool init();
	static PlayingCards *createPoker(int i);
	bool initPoker(int i);
    
	void CreateSprite();

	PRIVATES(State,m_State);//�˿�����û���
};
#endif