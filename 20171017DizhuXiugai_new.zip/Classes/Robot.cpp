#include "Robot.h"
#include "PlayingCards.h"
#include "RobotOne.h"
#include "RobotTwo.h"
#include "InterFace.h"
#include "Common.h"
#include "pDataManager.h"
#include "MsgManager.h"
USING_NS_CC;
Robot::Robot()
{
	m_Jiase=NULL;
    m_Chuyin=NULL;
	m_Chupai=NULL;
	label=NULL;
	m_sprite=NULL;
}
Robot::~Robot()
{
}
bool Robot::init()
{
	do
	{
	CreateSprite();

	//this->scheduleUpdate();
	return true;
	}while(0);
	return false;
}
void Robot::WePlaying(Moves m_Moves)
{
	std::mutex m_mutex;
	m_mutex.lock();

	if(m_Moves==_NULL)
	PlayMusic(_buyao);
	else
    PlayMusic(m_Moves);
		if(m_Moves==_end)
		{
			NOTIFY->postNotification("text",(Ref*)WhoRobot);
		}
			else
		{
			if(WhoRobot==2)
	        m_InterFace->setWho(3);
	        else
            m_InterFace->setWho(1);
	        m_InterFace->FuncTionWho();
		}
	CreateTakePokers();
	this->GirlStop();
	m_mutex.unlock();
}
 /*����������*/
void Robot::NetRobotupdate(int* q,Moves m_Moves)
{
	do
	{
	CC_BREAK_IF(q[0]==0);
	/*����*/
	m_InterFace->NetPlayer(q,WhoRobot,m_Moves);
	}while(0);
	Result(m_Moves);
	WePlaying(m_Moves);
}
void Robot::Robotupdate(float dt)
{
	//std::string m_WillPlay("");
	int a[21];
	int j=0;
	Moves m_Moves=_NULL;
	do{
	for(auto i:MonsterCardsVT)
	{
		a[j++]=i->getSize();
	}
	a[j]=0;

	/*����*/
	m_Moves=m_InterFace->PlayCards(a,WhoRobot);
	Result(m_Moves);
	WePlaying(m_Moves);
	}while(0);
}
/*���ƽ��*/
void Robot::Result(Moves m_Moves)
{
	do{
	int a[21]={0},j=0;
	CC_BREAK_IF(m_Moves==_NULL||m_Moves==_first||m_Moves==_buyao);
		/*ת��*/
	if(WhoRobot==2)
	Result(RobotOne::getInstance()->Jiepoker);
	else
    Result(RobotTwo::getInstance()->Jiepoker);

	for(auto i:MonsterCardsVT)
	{
		if(i->getState())
		a[j++]=i->getID();
	}
	m_InterFace->RobotSetTake(a,m_Moves);
	}while(0);
}
/*�˿��Ƶ�ת��*/
void Robot::Result(int* a)
{
	/*for(int i=0;a[i]!=0;i++)
	{
		log("%d",a[i]);
	}*/

	for(int s=0;a[s]!=0;s++)
	{
	for(auto i:MonsterCardsVT)
	{
		if(i->getState()!=true)
		{
		if(a[s]==i->getSize())
		{
			i->setState(true);
			break;
		}
		}
	}
	}
}
void Robot::NewPokers(int a[])
{

	for(auto i:MonsterCardsVT)
	{
		i->removeFromParent();
	}
	MonsterCardsVT.clear();

		/*�����˿���*/
	PlayingCards *m_cards;

	for(int i=0;a[i]!=0;i++)
	{
	m_cards=PlayingCards::createPoker(a[i]);
	CC_BREAK_IF(m_cards==NULL);
	/*�������˿��ƴ浽����*/
	MonsterCardsVT.pushBack(m_cards);
    }
	CreateTakePokers();

}
std::function<void(void)> Robot::Function()
{
	 std::function<void(void)> p=[=]()
	 {
	if(pDataManager::getInstance()->getZuzhi())
			return;
	 GirlRun();
	 if(!MsgManager::getInstance()->getpattern())
	 this->scheduleOnce(schedule_selector(Robot::Robotupdate),2.5f);
	 };
	 return p;
}

	/*ˢ���˻�����*/
void Robot::CreateTakePokers()
{
	Vector<PlayingCards*> MonsterCardsVTWantToDelete;
	for(auto i:MonsterCardsVT)
	{
		/*��Ҫ�����ƴ浽��ɾ�б�*/
		if(i->getState())
         MonsterCardsVTWantToDelete.pushBack(i);
	}

    /* ��ʽ���ƣ�ɾ�ƣ� */
    for (auto i : MonsterCardsVTWantToDelete)
        MonsterCardsVT.eraseObject(i);
   
      int size=MonsterCardsVT.size();
	  std::string m_string=StringUtils::toString(size);
	  label->setString(m_string);
}
void Robot::GirlRun()
{
	RotateBy*rotateBy=RotateBy::create(0.4f,0,30);
	RotateBy*rotateBy1=RotateBy::create(0.4f,0,-30);
	auto* actions=Sequence::create(rotateBy,rotateBy1,NULL);
	/*�������ö���*/
    auto repeat=RepeatForever::create(actions);
	m_Chuyin->runAction(repeat);
	m_Chupai->setVisible(true);
}
void Robot::GirlStop()
{
	m_Chuyin->stopAllActions();
	/*���û�����Ƕ�*/
	m_Chuyin->setRotationY(0);
	m_Chupai->setVisible(false);
}
/*�������п��ü��Ķ���*/
void Robot::YinCang()
{
	if(m_sprite)
	m_sprite->setVisible(false);
	if(m_Chuyin)
	m_Chuyin->setVisible(false);
	if(m_Jiase)
	m_Jiase->setVisible(false);
	if(m_Chupai)
	m_Chupai->setVisible(false);
	if(m_Myname)
	m_Myname->setVisible(false);
}
/*��ʾ���п������Ķ���*/
void Robot::XianShi()
{
	if(m_sprite)
	m_sprite->setVisible(true);
	if(m_Chuyin)
	m_Chuyin->setVisible(true);
	if(m_Jiase)
	m_Jiase->setVisible(true);
	if(m_Myname)
	m_Myname->setVisible(true);
	//if(m_Chupai)
	//m_Chupai->setVisible(true);
}

