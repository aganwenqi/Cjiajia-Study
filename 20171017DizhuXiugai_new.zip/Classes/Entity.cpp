#include "Entity.h"
USING_NS_CC;
Entity::Entity()
{
	m_sprite=NULL;
}
Entity::~Entity()
{
}
Sprite* Entity::getSprite()
{
	return this->m_sprite;
}
void Entity::setSprite(Sprite* sprite)
{
	this->m_sprite=sprite;
	this->addChild(m_sprite);
}