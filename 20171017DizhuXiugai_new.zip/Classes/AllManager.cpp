#include "AllManager.h"
#include "TakePokers.h"
#include "RobotOneD.h"
#include "RobotTwoD.h"
#include "Route.h"
#include "Robot.h"
#include "Newcards.h"

#include "RobotOne.h"
#include "RobotTwo.h"
#include "Player.h"
#include"MiddleMan.h"
#include "List.h"
#include "InterFace.h"
#include "pDataManager.h"
#include "SimpleAudioEngine.h"
#include "MusicManager.h"
#include "Alltool.h"
#include "MsgManager.h"
#include "NetPokerMsg.h"
#include "List.h"

USING_NS_CC;
AllManager::AllManager()
{
	m_fuwuyuan=MiddleMan::getInstance();
	m_Player=Player::getInstance();
	m_RobotOne=RobotOne::getInstance();
    m_RobotTwo=RobotTwo::getInstance();

	m_Newcards=NULL;
    m_TakePokers=NULL;
    m_RobotOneD=NULL;
    m_RobotTwoD=NULL;
	m_InterFace=NULL;
	m_Tuoguan=false;

}
AllManager::~AllManager()
{
	NOTIFY->removeAllObservers(this);
}

bool AllManager::init()
{
	Size visibleSize=Director::getInstance()->getVisibleSize();
	Sprite* sprite=NULL;
    sprite=Sprite::create("Take.png");                                 
	
	sprite->setPosition(Point(visibleSize.width/2,visibleSize.height/2));
	this->addChild(sprite);

	/*������Ч*/
	//ParticleSystemQuad* particle = ParticleSystemQuad::create("slowLight.plist");
	//addChild(particle,55);

	/*�����ƹ�����*/
	m_TakePokers=TakePokers::create();
	this->addChild(m_TakePokers,PlayManagerLayer,PlayManagerLayer);
	m_TakePokers->setPosition(Point(visibleSize.width/2,240));

	/*���ǹ�����*/
    m_Newcards=Newcards::create();
    m_Newcards->setPosition(Point(visibleSize.width/2,15.0f));
	 this->addChild(m_Newcards,PokerRootLayer);

	/*�˻�one������*/
	m_RobotOneD=RobotOneD::create();
	this->addChild(m_RobotOneD,PlayManagerLayer);
	m_RobotOneD->setPosition(Point(700,400));

	/*�˻�Two������*/
	m_RobotTwoD=RobotTwoD::create();
	this->addChild(m_RobotTwoD,PlayManagerLayer);
	m_RobotTwoD->setPosition(Point(300,400));

	/*������*/
	auto label=Label::create("","Arial",70);
	label->enableShadow(Color4B::BLUE, Size(0, 0)); //��Ӱ
	label->setPosition(500,550);
	label->setColor(Color3B::YELLOW);
	this->addChild(label,60,60);

	NOTIFY->addObserver(this,callfuncO_selector(AllManager::CreateFraction),"fraction",NULL);
	NOTIFY->addObserver(this,callfuncO_selector(AllManager::NetPoker),"NetPoker",NULL);
	Tuoguan();

	if(!MsgManager::getInstance()->getpattern())
	{
		/*�������*/
    m_fuwuyuan->setHaveDz(false);
	}
	/*���������ֻ��Ҫ���������������*/
	NextBoard();
	return true;
}
/*�����йܰ�ť*/
void AllManager::Tuoguan()
{
	auto tuiBtn = Button::create();
    tuiBtn->loadTextureNormal("sprite/tuoan.png");
	this->addChild(tuiBtn,33);
	tuiBtn->setAnchorPoint(Point(1,0));
	tuiBtn->setPosition(Point(990,100));
	tuiBtn->addTouchEventListener(this,toucheventselector(AllManager::TuoguanFunc));

	auto sprite=Sprite::create("sprite/tuoguan.png");
	sprite->setAnchorPoint(Point(1,1));
	sprite->setPositionX(865);
	this->addChild(sprite,2,22);
}
/*�йܰ�ť�ص�*/
void AllManager::TuoguanFunc(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
		MusicManager::PlayEffectMusic("music/Button.mp3");
		auto sprite=getChildByTag(22);
		if(m_Tuoguan)
		{
			m_Tuoguan=false;
			auto m_MoveBy=MoveBy::create(0.3f,Point(0,-150));
			sprite->runAction(m_MoveBy);
			m_Newcards->setTuoguan(false);
		}
		else
		{
			m_Tuoguan=true;
			auto m_MoveBy=MoveBy::create(0.3f,Point(0,150));
			sprite->runAction(m_MoveBy);
			m_Newcards->setTuoguan(true);
			if(m_InterFace->getWho()==1)
            m_Newcards->Playupdate(0.0f);
		}
	}
}
/*������ˢ��*/
void AllManager::CreateFraction(Ref* pData)
{
	auto label=(Label*)getChildByTag(60);
	label->setString(Value((int)pData).asString());
}
/*����һ�ֳ�ʼ����һ��*/
void AllManager::NextBoard()
{
	this->scheduleOnce(schedule_selector(AllManager::CreateThread),0);
	/*�����̷߳���*/
	//std::thread xiancheng=std::thread(&AllManager::CreateThread,this);
	//xiancheng.detach();
	//CreateThread(1);
	srand((unsigned)time(NULL));
	MusicManager::PlayEffectMusic("music/Special_Dispatch.mp3");
	Size visibleSize=Director::getInstance()->getVisibleSize();

	auto m_sprite=Sprite::create("sprite/TexiaoSprite/Kaishida.png");
	this->addChild(m_sprite,998);
	m_sprite->setPosition(Point(visibleSize.width/2,visibleSize.height/2));
	m_sprite->setScale(0);
    
	auto m_sprite1=Sprite::create("sprite/TexiaoSprite/Kaishida1.png");
	m_sprite1->setPosition(Point(visibleSize.width/2,visibleSize.height/2));
	this->addChild(m_sprite1,999);
	m_sprite1->setVisible(false);

	auto func=CallFunc::create([=](){
	MusicManager::PlayEffectMusic("music/Button.mp3");
	m_sprite1->setVisible(true);
	});

	auto func1=CallFunc::create([=](){
		this->removeChild(m_sprite1);
	});
	auto func2=CallFunc::create([=](){
		this->removeChild(m_sprite);
		pDataManager::getInstance()->setZuzhi(false);
		NextBoard1();
	});

	auto Big=ScaleTo::create(1.0f,1);
	auto Wu=MoveBy::create(1.5f,Point(0,0));
	auto ZaiBig=ScaleBy::create(1.0f,2);
	auto VeryBig=ScaleBy::create(0.5f,3);
    auto actions=Sequence::create(Big,func,Wu,func1,ZaiBig,VeryBig,func2,NULL);
    m_sprite->runAction(actions);

	MusicManager::StopBackgroundMusic();
}
/*����һ�ֳ�ʼ����һ�ָ���*/
void AllManager::NextBoard1()
{
	float ah=Alltool::getSrand();
	if(ah<0.5f)
    MusicManager::PlayBackgroundMusic("music/MusicEx_Exciting.mp3",true);
	else
    MusicManager::PlayBackgroundMusic("music/MusicEx_Normal.mp3",true);

    MusicManager::PlayEffectMusic("music/Kaitouyin.mp3");

	m_RobotOneD->XianShi();
	m_RobotTwoD->XianShi();
	m_Newcards->XianShi();
	auto label=(Label*)getChildByTag(TuoguanTag);
	label->setString("2");
	label->setVisible(true);
	m_InterFace->FuncTionWho();
}
/*�̳߳�ʼ������*/
void AllManager::CreateThread(float dt)
{
	if(MsgManager::getInstance()->getpattern())
	runGameNet();
	else
	runGame();

	Init();
	CreateData();
	Jiaojie();
	auto label=(Label*)getChildByTag(TuoguanTag);
	label->setVisible(false);
}
/*��ʼ���й�*/
void AllManager::CreateData()
{
	if(m_Tuoguan)
	{
		auto sprite=getChildByTag(22);
		m_Tuoguan=false;
		auto m_MoveBy=MoveBy::create(0.3f,Point(0,-150));
		sprite->runAction(m_MoveBy);
		m_Newcards->setTuoguan(false);
	}
}
/*��ʼ��Dos����*/
void AllManager::runGame()
{

	/*��ʼ��*/
	m_fuwuyuan->Initial();
	/*ϴ��*/
	m_fuwuyuan->Wash();
	/*���õ���*/
	m_fuwuyuan->dizhu();
	/*����Ա����*/
	m_fuwuyuan->fapai();

	//m_fuwuyuan->Begin();//��ʼ��Ϸ
}
/*�����ʼ��Dos����*/
void AllManager::runGameNet()
{
	/*��ʼ��*/
	m_fuwuyuan->Initial();
	/*���õ���*/
	m_fuwuyuan->Netdizhu();

	m_fuwuyuan->Netfapai();

	//m_fuwuyuan->Begin();//��ʼ��Ϸ
}
/*��ʼ����������*/
void AllManager::Init()
{
	 int a[21]={0};
	/*������1*/
	 Turn(m_RobotOne->getHead(),a);
     m_RobotOneD->NewPokers(a);
	 if(m_RobotOne->getRole())   
	 {
	 m_RobotOneD->setRole(true);
	 m_RobotOneD->CreateJiaoseSprite(DizhuBiaoshi); 
	 }
	 else
	 {
     m_RobotOneD->setRole(false);
     m_RobotOneD->CreateJiaoseSprite(NongmingBiaoshi);
	 }

	/*������2*/
	 Turn(m_RobotTwo->getHead(),a);
	 m_RobotTwoD->NewPokers(a);
	 if(m_RobotTwo->getRole())
	 {
	 m_RobotTwoD->setRole(true);
	 m_RobotTwoD->CreateJiaoseSprite(DizhuBiaoshi);
	 }
	 else
	 {
     m_RobotTwoD->setRole(false);
	 m_RobotTwoD->CreateJiaoseSprite(NongmingBiaoshi);
	 }

	/*����*/
	 Turn(m_Player->getHead(),a);
	 m_Newcards->init(a);
	 if(m_Player->getRole())
	 {
	 m_Newcards->setRole(true);
	 m_Newcards->CreateJiaoseSprite(DizhuBiaoshi);
	 }
	 else
	 {
     m_Newcards->setRole(false);
	 m_Newcards->CreateJiaoseSprite(NongmingBiaoshi);
	 }
	 if(MsgManager::getInstance()->getpattern())
	 {
	 m_Newcards->m_Myname->setString(m_Player->getplayname());
	 m_RobotOneD->m_Myname->setString(m_RobotOne->getplayname());
	 m_RobotTwoD->m_Myname->setString(m_RobotTwo->getplayname());
	 }
	 m_RobotOneD->YinCang();
	 m_RobotTwoD->YinCang();
	 m_Newcards->YinCang();
	 m_TakePokers->Reduction();
}
void AllManager::Jiaojie()
{
	do{
	CC_BREAK_IF(m_InterFace);
		/*���Ա���ù�������*/
	m_InterFace=InterFace::create();
	m_Newcards->m_InterFace=m_InterFace;
	m_Newcards->setDosJiaose(Player::getInstance());

	m_RobotOneD->m_InterFace=m_InterFace;
	m_RobotOneD->setDosJiaose(RobotOne::getInstance());

	m_RobotTwoD->m_InterFace=m_InterFace;
	m_RobotTwoD->setDosJiaose(RobotTwo::getInstance());

	/*��3����ɫ�Ļص������Խ������*/
	m_InterFace->setPlay(m_Newcards->Function());
	m_InterFace->setRotboOne(m_RobotOneD->Function());
	m_InterFace->setRotboTwo(m_RobotTwoD->Function());
	m_InterFace->setTake(m_TakePokers->Function());
	}while(0);
	//m_TakePokers->Reduction();

	if(m_Newcards->getRole())
    m_InterFace->setWho(1);

	if(m_RobotOneD->getRole())
    m_InterFace->setWho(2);

	if(m_RobotTwoD->getRole())
    m_InterFace->setWho(3);

	//m_InterFace->setWho(1);
}
/*��ȡ�˻��˿��Ƶ�����id*/
void AllManager::Turn(std::vector<Poker*> head,int *a)
{
	int i;
	for(i=0;i<head.size();i++)
		a[i]=head.at(i)->getID();

	a[i]=0;
}
void AllManager::NetPoker(Ref* pData)
{
	NetPokerMsg *mp=(NetPokerMsg*)pData;
	const char* name=mp->WhoPokerName.c_str();
	Moves m_Moves=mp->m_Moves;
	int a[21],i=0;
	MsgManager *msg=MsgManager::getInstance();
	for(i=0;mp->poker[i]!=0;i++)
		a[i]=msg->getPoker(mp->poker[i])->m_poker.getNumber();
	a[i]=0;

	if(m_RobotOne->getplayname().compare(name)==0)//���˳�����
		m_RobotOneD->NetRobotupdate(a,m_Moves);
	else
		m_RobotTwoD->NetRobotupdate(a,m_Moves);

}