#ifndef _Alltool_H_
#define _Alltool_H_
class Alltool
{
public:
	static float getSrand();
};
#endif