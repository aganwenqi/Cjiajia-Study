#include "AllManager.h"
#include "SceneManager.h"
#include "MiddleMan.h"
#include "PokerScene.h"
#include "Route.h"
#include "pDataManager.h"
#include "SimpleAudioEngine.h"
#include "MusicManager.h"
#include "MsgManager.h"
USING_NS_CC;
void PokerScene::CreateMainMeun()
{
	Size visibleSize=Director::getInstance()->getVisibleSize();
		/*����UI*/
    auto UI=cocostudio::GUIReader::getInstance()->widgetFromJsonFile("UI/PlayMainUI/PlayMainUI_1.ExportJson");
	this->addChild(UI,PlayMeunLayer);
	UI->setAnchorPoint(Point(1,0));
	UI->setPosition(Point(visibleSize.width-20,20));

	zhucaidan=(Button*)Helper::seekWidgetByName(UI,"zhucaidan");
	chonglai=(Button*)Helper::seekWidgetByName(UI,"chonglai");
	tuichu=(Button*)Helper::seekWidgetByName(UI,"tuichu");
	caidan=(Button*)Helper::seekWidgetByName(UI,"caidan");
	zhucaidan->setVisible(false);
	zhucaidan->setEnabled(false);
	chonglai->setVisible(false);
	chonglai->setEnabled(false);
	tuichu->setVisible(false);
	tuichu->setEnabled(false);

	if(MsgManager::getInstance()->getpattern())
		caidan->setEnabled(false);
	else
        caidan->setEnabled(true);

	zhucaidan->addTouchEventListener(this,toucheventselector(PokerScene::Zhucaidan));
	chonglai->addTouchEventListener(this,toucheventselector(PokerScene::Chonglai));
	tuichu->addTouchEventListener(this,toucheventselector(PokerScene::Tuichu));
	caidan->addTouchEventListener(this,toucheventselector(PokerScene::Caidan));
}
    /*���˵���ť*/
void PokerScene::Zhucaidan(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
		m_AllManager->cleanup();
		MusicManager::StopAllEffectMusic();
		MusicManager::StopBackgroundMusic();
		MusicManager::PlayEffectMusic("music/Button.mp3");
		SceneManager::getInstance()->changeScene(SceneManager::en_ManScene);
	}
}
	/*������ť*/
void PokerScene::Chonglai(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
		MusicManager::PlayEffectMusic("music/Button.mp3");
		if(pDataManager::getInstance()->getZuzhi())
			return;
		pDataManager::getInstance()->setZuzhi(true);

		m_AllManager->cleanup();
		MiddleMan::getInstance()->setHaveDz(false);
		m_AllManager->NextBoard();
		Return();
	}
}
	/*�˳���ť*/
void PokerScene::Tuichu(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
		MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
		Director::getInstance()->end();
	}
}
	/*�˵���ť*/
void PokerScene::Caidan(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
	  MusicManager::PlayEffectMusic("music/Button.mp3");
	  if(!isMeunActive)
	  {
		  isMeunActive=true;
		if(isMeun)
		{
			Return();
			isMeun=false;
		}
		else
		{
			Go();
			isMeun=true;
		}
	  }
	}
}
/*��ť����*/
void PokerScene::Go()
{
	tuichu->setVisible(true);
	tuichu->setEnabled(true);

	CallFunc*callFunc1=CallFunc::create(
		[this](){
	chonglai->setVisible(true);
	chonglai->setEnabled(true);

	CallFunc*callFunc1=CallFunc::create(
		[this](){
	zhucaidan->setVisible(true);
	zhucaidan->setEnabled(true);

	CallFunc*callFunc1=CallFunc::create(
		[this](){
	isMeunActive=false;
	});
	auto m_Move=EaseBounceOut::create(
		MoveTo::create(0.3f, Point(chonglai->getPositionX(),chonglai->getPositionY()+chonglai->getContentSize().height+10))
	);
	Action*actions=Sequence::create(m_Move,callFunc1,NULL);
	zhucaidan->runAction(actions);
	});

	auto m_Move=MoveTo::create(0.2f, Point(tuichu->getPositionX(),tuichu->getPositionY()+tuichu->getContentSize().height+10));
	Action*actions=Sequence::create(m_Move,callFunc1,NULL);
	chonglai->runAction(actions);
	});

	auto m_Move=MoveTo::create(0.1f, Point(caidan->getPositionX()-55,caidan->getPositionY()+caidan->getContentSize().height-10));
	Action*actions=Sequence::create(m_Move,callFunc1,NULL);
	tuichu->runAction(actions);

}
	/*��ť�ع�*/
void PokerScene::Return()
{
	CallFunc*callFunc1=CallFunc::create(
		[this](){
	tuichu->setVisible(false);
	tuichu->setEnabled(false);
	CallFunc*callFunc1=CallFunc::create(
		[this](){
	chonglai->setVisible(false);
	chonglai->setEnabled(false);
	CallFunc*callFunc1=CallFunc::create(
		[this](){
	zhucaidan->setVisible(false);
	zhucaidan->setEnabled(false);
	isMeunActive=false;
	});
	auto m_Move=MoveTo::create(0.15f, Point(caidan->getPosition()));
	Action*actions=Sequence::create(m_Move,callFunc1,NULL);
	zhucaidan->runAction(actions);
	});

	auto m_Move=MoveTo::create(0.1f, Point(caidan->getPosition()));
	Action*actions=Sequence::create(m_Move,callFunc1,NULL);
	chonglai->runAction(actions);
	});

	auto m_Move=MoveTo::create(0.05f, Point(caidan->getPosition()));
	Action*actions=Sequence::create(m_Move,callFunc1,NULL);
	tuichu->runAction(actions);
}
