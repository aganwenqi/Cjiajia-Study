#include "pDataManager.h"
#include "RobotOne.h"
#include "RobotTwo.h"
#include "Player.h"
#include "Route.h"
#include "SimpleAudioEngine.h"
USING_NS_CC;
pDataManager* pDataManager::m_pDataManager=NULL;
pDataManager* pDataManager::getInstance()
{
	if(m_pDataManager==NULL)
	{
		m_pDataManager=new pDataManager();
	}
	return m_pDataManager;
}

/*����ʲô���жϽ�ɫ�ķ����Ӽ�*/
void pDataManager::Fraction(Moves m_Moves)
{
	
	if(m_Moves==_zhadan||m_Moves==_wangzha)
	OutZhadan();
	else
	WhoWin();

	NOTIFY->postNotification("fraction",(Ref*)m_NowFraction);
}
/*����ը���Ĵ���*/
void pDataManager::OutZhadan()
{

	m_NowFraction=m_NowFraction*2;
}
	/*����Ӯ�˵Ĵ���*/
void pDataManager::WhoWin()
{

	m_NowFraction=m_NowFraction+2;

	if(m_Player->getPokerData()=="")
	if(m_Player->getRole())
		Add(m_NowFraction);
	else
		Add(m_NowFraction/2);

	else
	{
		Common* m_Common;
	     if(m_RobotOne->getPokerData()=="")
			 m_Common=m_RobotOne;
    else if(m_RobotTwo->getPokerData()=="")
			 m_Common=m_RobotTwo;
	
		 if(m_Common->getRole()==m_Player->getRole())
			 Add(m_NowFraction/2);
		 else
             Cut(m_NowFraction/2);}

	FileXml();
	m_NowFraction=2;
}
/*�����ݼ�*/
void pDataManager::Cut(int i)
{
	m_WinLose=false;
	if(m_Player->getRole())
	i=i*2;

	m_Fraction=m_Fraction-i;
	m_Lose+=1;
}
	/*�����ݼ�*/
void pDataManager::Add(int i)
{
	m_WinLose=true;
	m_Fraction=m_Fraction+i;
	if(m_Player->getPokerData()=="")
	m_Win+=1;
}
pDataManager::pDataManager()
{
	m_Player=Player::getInstance();
	m_RobotOne=RobotOne::getInstance();
	m_RobotTwo=RobotTwo::getInstance();

    m_NowFraction=2;
	m_Win=0;
	m_Lose=0;
	m_Fraction=0;

	m_Zuzhi=true;
	m_WinLose=false;
	LoadXml();
}
pDataManager::~pDataManager()
{
}
/*�����ļ�*/
void pDataManager::FileXml()
{
	ValueMap fileDataMap;
		ValueMap data;
		data["Fraction"]=m_Fraction;
		data["Win"]=m_Win;
		data["Lose"]=m_Lose;
		fileDataMap["player"]=Value(data);
	std::string m_string=FileUtils::getInstance()->fullPathForFilename("demaxiya/PlayerData.plist");
	FileUtils::getInstance()->writeToFile(fileDataMap,m_string);//д�뱣��xml�ļ�
	/*
	UserDefault::getInstance()->setIntegerForKey("Fraction",m_Fraction);
	UserDefault::getInstance()->setIntegerForKey("Win",m_Win);
	UserDefault::getInstance()->setIntegerForKey("Lose",m_Lose);
	*/
}
/*��ȡ�ļ�*/
void pDataManager::LoadXml()
{
	std::string m_string=FileUtils::getInstance()->fullPathForFilename("demaxiya/PlayerData.plist");
	ValueMap fileDataMap=FileUtils::getInstance()->getValueMapFromFile(m_string);
		Value value=fileDataMap.at("player");
		ValueMap data=value.asValueMap();
	    m_Fraction=data["Fraction"].asInt();
		m_Win=data["Win"].asInt();
		m_Lose=data["Lose"].asInt();
	/*if(UserDefault::getInstance()->getIntegerForKey("Fraction",520)==520)
    UserDefault::getInstance()->setIntegerForKey("Fraction",0);

	if(UserDefault::getInstance()->getIntegerForKey("Win",520)==520)
    UserDefault::getInstance()->setIntegerForKey("Win",0);


	if(UserDefault::getInstance()->getIntegerForKey("Lose",520)==520)
	UserDefault::getInstance()->setIntegerForKey("Lose",0);

	
    m_Fraction=UserDefault::getInstance()->getIntegerForKey("Fraction");
	m_Win=UserDefault::getInstance()->getIntegerForKey("Win");
    m_Lose=UserDefault::getInstance()->getIntegerForKey("Lose");
	*/
}