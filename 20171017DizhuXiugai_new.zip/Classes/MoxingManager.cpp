#include "MoxingManager.h"
#include "SocketDataManager.h"
#include "JsonData.h"
#include "QingBaoA.h"
#include "QingbaoManager.h"
#include "MsgManager.h"
MoxingManager* MoxingManager::m_MoxingManager = NULL;

MoxingManager::MoxingManager()
{
	cSocket=NULL;
}

MoxingManager::~MoxingManager()
{
}

MoxingManager* MoxingManager::getInstance()
{
    if (m_MoxingManager == NULL)
    {
        m_MoxingManager = MoxingManager::create();
        m_MoxingManager->retain();
    }

    return m_MoxingManager;
}

bool MoxingManager::init()
{

    return true;
}

bool MoxingManager::start( const char *ip,int port)
{
	bool quite=connectServer(ip,port);/*����Ƿ�����*/
    if (quite)
    {
        /* �������̣߳��������� */
        std::thread recvThread = std::thread(&MoxingManager::recvData, this);
        recvThread.detach();
		recvThread = std::thread(&MoxingManager::recvJiance, this);
        recvThread.detach();
    }
	return quite;
}

bool MoxingManager::connectServer(const char *ip,int port){
    cSocket.Init();
    cSocket.Create(AF_INET, SOCK_STREAM, 0);

    //const char* ip = "115.28.47.161";
    //const char* ip = "127.1.0.0";
   // int port = 7777;
    bool result = cSocket.Connect(ip, port);

    int retryTimes = 0;
    while (result == false && retryTimes < 3) {

        result = cSocket.Connect(ip, port);
        retryTimes++;

#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
        Sleep(500);
#else
        usleep(500);
#endif

    }
    return result;
}
//lineStr = str.asString().substr(startIndex, endIndex);
void MoxingManager::recvData()
{
    while (true) {
        /* �������� */
        char recvBuf[MAX_LEN] = "";
        int iResult = cSocket.Recv(recvBuf, MAX_LEN, 0);
        if (iResult <= 0) {
            break;
        }
        /* ����Ϣ��ŵ������У��ȴ����� */
        SocketDataManager::getInstance()->pushMsg(recvBuf);
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
        Sleep(20);
#else
        usleep(20);
#endif

    }
}
 void MoxingManager::recvJiance()       /* һֱ������� */
{
	JsonData* data;
	  while (true) {
       /* ���͵�½���� */
    data = JsonData::create("{}");
    data->addValue(G_Ziduan::G_leixing,G_TXType::G_lianjie);
	sendMsg(data->getsJsonStr().c_str());
	log("LJ:%d",QingbaoManager::getInstance()->lianjie);
	if(QingbaoManager::getInstance()->lianjie < 7 && QingbaoManager::getInstance()->lianjie++>=4)
	{
	MsgManager::getInstance()->create();
	}
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
        Sleep(3000);
#else
        usleep(4000);
#endif

    }
}
void MoxingManager::sendMsg(const char* msg)
{
	if(cSocket){
	log(msg);
    cSocket.Send(msg, strlen(msg), 0);
	}
}
