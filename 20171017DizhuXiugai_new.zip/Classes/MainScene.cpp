#include "MainScene.h"
#include "SceneManager.h"
#include "pDataManager.h"
#include "SimpleAudioEngine.h"
#include "MusicManager.h"
#include "MoxingManager.h"
#include "MsgManager.h"
#include "QingBaoA.h"
#include "JsonData.h"
#include "QingbaoManager.h"
#include "NetRoom.h"
#include "FasongManager.h"
USING_NS_CC;
Scene * MainScene::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = MainScene::create();
	QingbaoManager::getInstance()->m_MainScene = layer;
    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

//bool abc=true;
	/*��ʼ����������*/
void MainScene::Initialization()
{
	JsonData* jsonData = NULL;
    jsonData = MsgManager::getInstance()->getmsgMap(G_TXType::G_Denglu);
	if(jsonData)
	{
	yonghu->setText(jsonData->getCStrData(G_Ziduan::G_name));
	}
	else
	{
    yonghu->setText("NoUser");
	}

	/*if(abc)
	{
	const char* ip="192.168.0.100";
    int port=7777;
	MoxingManager::getInstance()->start(ip,port);
	abc=false;
	Sleep(500);
	}*/
}
bool MainScene::init()
{
	Size visible = Director::getInstance()->getVisibleSize();

	/*����UI*/
    auto UI = cocostudio::GUIReader::getInstance()->widgetFromJsonFile("UI/HomeUi/HomeUi_1.ExportJson");
	this->addChild(UI);

	/*ParticleSystemQuad* particle = ParticleSystemQuad::create("slowLight.plist");
	addChild(particle);*/

	ButtonMap.insert(ButtonEnum::_began , (Button*)Helper::seekWidgetByName(UI,"began"));
	ButtonMap.insert(ButtonEnum::_record , (Button*)Helper::seekWidgetByName(UI,"record"));
	ButtonMap.insert(ButtonEnum::_record_1 , (Button*)Helper::seekWidgetByName(UI,"record_1"));
	ButtonMap.insert(ButtonEnum::_introduce , (Button*)Helper::seekWidgetByName(UI,"introduce"));
    ButtonMap.insert(ButtonEnum::_signout , (Button*)Helper::seekWidgetByName(UI,"signout"));
	//ButtonMap.insert(ButtonEnum::_tui , (Button*)Helper::seekWidgetByName(UI,"tui"));
	ButtonMap.insert(ButtonEnum::_wangluo , (Button*)Helper::seekWidgetByName(UI,"wangluo"));
	ButtonMap.insert(ButtonEnum::_denglu , (Button*)Helper::seekWidgetByName(UI,"denglu"));
	ButtonMap.insert(ButtonEnum::_duoren , (Button*)Helper::seekWidgetByName(UI,"duoren"));
	yonghu = (TextField*)Helper::seekWidgetByName(UI,"yonghu");

	ButtonMap.at(_began)->addTouchEventListener(this,toucheventselector(MainScene::Began));
	ButtonMap.at(_record)->addTouchEventListener(this,toucheventselector(MainScene::Record));
	ButtonMap.at(_record_1)->addTouchEventListener(this,toucheventselector(MainScene::NetRecord));
	ButtonMap.at(_introduce)->addTouchEventListener(this,toucheventselector(MainScene::Introduce));
	ButtonMap.at(_signout)->addTouchEventListener(this,toucheventselector(MainScene::Signout));
	//ButtonMap.at(_tui)->addTouchEventListener(this,toucheventselector(MainScene::JieshaoSignout));

	ButtonMap.at(_wangluo)->addTouchEventListener(this,toucheventselector(MainScene::Wangluo));
	ButtonMap.at(_denglu)->addTouchEventListener(this,toucheventselector(MainScene::Denglu));
	ButtonMap.at(_duoren)->addTouchEventListener(this,toucheventselector(MainScene::Duoren));

	/*����UI*/
    UI1 = cocostudio::GUIReader::getInstance()->widgetFromJsonFile("UI/NetData_1/NetData_1.ExportJson");
	this->addChild(UI1);
	UI1->setEnabled(false);
	UserMsgMap.insert("text1",(Text*)Helper::seekWidgetByName(UI1,"text1"));
	UserMsgMap.insert("text2",(Text*)Helper::seekWidgetByName(UI1,"text2"));
	UserMsgMap.insert("text3",(Text*)Helper::seekWidgetByName(UI1,"text3"));
	Button * nettui=(Button*)Helper::seekWidgetByName(UI1,"tui");
	nettui->addTouchEventListener(this,toucheventselector(MainScene::NetSignout));

	MusicManager::PlayBackgroundMusic("music/MusicEx_Welcome.mp3",true);

	Initialization();
	return true;
}
/*�������ӳ���*/
void MainScene::Duoren(Ref* target, TouchEventType type)
{
    if(type==TouchEventType::TOUCH_EVENT_ENDED&&MsgManager::getInstance()->quite)
	{
	MusicManager::PlayEffectMusic("music/Button.mp3");
	SceneManager::getInstance()->changeScene(SceneManager::en_NetRoom);
	FasongManager::getInstance()->getAllRoom();
	}
}
bool MainScene::setQingbao1(const char* qb[])//���ܶ�������
{
	if(qb)
	{
	QingbaoManager::getInstance()->m_NetRoom->setQingbao1(qb);
	}
	return true;
}
void MainScene::setQingbao1(JsonData* jsonData)//��ȡ�������Լ�������
{
	UserMsgMap.at("text1")->setText(jsonData->getCStrData(G_Play::G_Fraction));
	UserMsgMap.at("text2")->setText(jsonData->getCStrData(G_Play::G_Win));
	UserMsgMap.at("text3")->setText(jsonData->getCStrData(G_Play::G_Loser));
}
/*�л���½���ӳ���*/
void MainScene::Denglu(Ref* target, TouchEventType type)
{
    if(type == TouchEventType::TOUCH_EVENT_ENDED)
	{
	MusicManager::PlayEffectMusic("music/Button.mp3");
	SceneManager::getInstance()->changeScene(SceneManager::en_Denglu);
	}
}
/*�л��������ӳ���*/
void MainScene::Wangluo(Ref* target, TouchEventType type)
{
	if(type == TouchEventType::TOUCH_EVENT_ENDED)
	{
	//MusicManager::PlayEffectMusic("music/Button.mp3");
	SceneManager::getInstance()->changeScene(SceneManager::en_wangluo);
	}
}
	/*��ʼ��ť*/
void MainScene::Began(Ref* target, TouchEventType type)
{
	if(type == TouchEventType::TOUCH_EVENT_ENDED)
	{
	MusicManager::PlayEffectMusic("music/Button.mp3");
	SceneManager::getInstance()->changeScene(SceneManager::en_PokerScene);
	}
}
/*�鿴����ս����ť*/
void MainScene::NetRecord(Ref* target, TouchEventType type)
{
	if(type == TouchEventType::TOUCH_EVENT_ENDED&&MsgManager::getInstance()->quite)
	{
		FasongManager::getInstance()->getUserMsg();
		MusicManager::PlayBackgroundMusic("music/Zhanji.mp3",true);
		MusicManager::PlayEffectMusic("music/Button.mp3");

		ButtonMap.at(_began)->setEnabled(false);
	    ButtonMap.at(_record)->setEnabled(false);
		ButtonMap.at(_record_1)->setEnabled(false);
	    ButtonMap.at(_introduce)->setEnabled(false);
        ButtonMap.at(_signout)->setEnabled(false);

		UI1->setEnabled(true);
	}

}
/*�����˳���ť*/
void MainScene::NetSignout(Ref* target, TouchEventType type)
{
	    UI1->setEnabled(false);
	    ButtonMap.at(_began)->setEnabled(true);
	    ButtonMap.at(_record)->setEnabled(true);
		ButtonMap.at(_record_1)->setEnabled(true);
	    ButtonMap.at(_introduce)->setEnabled(true);
        ButtonMap.at(_signout)->setEnabled(true);
		MusicManager::PlayBackgroundMusic("music/MusicEx_Welcome.mp3",true);
}
	/*�鿴ս����ť*/
void MainScene::Record(Ref* target, TouchEventType type)
{
	if(type == TouchEventType::TOUCH_EVENT_ENDED)
	{
		Size visible = Director::getInstance()->getVisibleSize();
		MusicManager::PlayBackgroundMusic("music/Zhanji.mp3",true);
		MusicManager::PlayEffectMusic("music/Button.mp3");
		ButtonMap.at(_began)->setEnabled(false);
	    ButtonMap.at(_record)->setEnabled(false);
		ButtonMap.at(_record_1)->setEnabled(false);
	    ButtonMap.at(_introduce)->setEnabled(false);
        ButtonMap.at(_signout)->setEnabled(false);

        auto sprite=Sprite::create("sprite/fraction.png");
		sprite->setPosition(Point(visible.width/2,visible.height/2));
		this->addChild(sprite,21,21);

		auto tuiBtn = Button::create();
        tuiBtn->loadTextureNormal("sprite/tui.png");
		sprite->addChild(tuiBtn,3);
		tuiBtn->setAnchorPoint(Point(1,0));
		tuiBtn->setPosition(Point(sprite->getContentSize().width,0));
		tuiBtn->addTouchEventListener(this,toucheventselector(MainScene::FractionBt));

		auto labelOne=Label::create("","Arial",40);
		auto labelTwo=Label::create("","Arial",40);
		auto labelThree=Label::create("","Arial",40);
		sprite->addChild(labelOne);
		sprite->addChild(labelTwo);
		sprite->addChild(labelThree);
		labelOne->setAnchorPoint(Point(0,0));
		labelTwo->setAnchorPoint(Point(0,0));
		labelThree->setAnchorPoint(Point(0,0));

		labelOne->setPosition(Point(100,sprite->getContentSize().height-100));
		labelTwo->setPosition(Point(100,labelOne->getPositionY()-100));
		labelThree->setPosition(Point(100,labelTwo->getPositionY()-100));

		pDataManager* m_pDataManager=pDataManager::getInstance();
		std::string m_string=StringUtils::format("The total score: %d",m_pDataManager->getFraction());
		labelOne->setString(m_string);

		m_string=StringUtils::format("Winning times: %d",m_pDataManager->getWin());
		labelTwo->setString(m_string);

		m_string=StringUtils::format("Transport times: %d",m_pDataManager->getLose());
		labelThree->setString(m_string);
	}
}
/*ս���˳���ť*/
void MainScene::FractionBt(Ref* target, TouchEventType type)
{
	if(type == TouchEventType::TOUCH_EVENT_ENDED)
	{
		MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
		MusicManager::PlayBackgroundMusic("music/MusicEx_Welcome.mp3",true);
		ButtonMap.at(_began)->setEnabled(true);
	    ButtonMap.at(_record)->setEnabled(true);
		ButtonMap.at(_record_1)->setEnabled(true);
	    ButtonMap.at(_introduce)->setEnabled(true);
        ButtonMap.at(_signout)->setEnabled(true);

		this->removeChild(getChildByTag(21));
	}
}
	/*��ؽ��ܰ�ť*/
void MainScene::Introduce(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
		Size visible = Director::getInstance()->getVisibleSize();
		MusicManager::PlayEffectMusic("music/Button.mp3");

		ButtonMap.at(_began)->setEnabled(false);
	    ButtonMap.at(_record)->setEnabled(false);
	    ButtonMap.at(_introduce)->setEnabled(false);
        ButtonMap.at(_signout)->setEnabled(false);

		auto tupian = Sprite::create("sprite/jianjie.png");
		tupian->setPosition(Point(visible.width/2,visible.height/2));
		this->addChild(tupian,1,99);

		auto tuiBtn = Button::create();
        tuiBtn->loadTextureNormal("sprite/tui.png");
		tupian->addChild(tuiBtn,4);
		tuiBtn->setAnchorPoint(Point(1,0));
		tuiBtn->setPosition(Point(tupian->getContentSize().width-95,55));
		tuiBtn->addTouchEventListener(this,toucheventselector(MainScene::JieshaoSignout));
	
	}
}
	/*�˳���ť*/
void MainScene::Signout(Ref* target, TouchEventType type)
{
	if(type == TouchEventType::TOUCH_EVENT_ENDED)
	{
		MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
		Director::getInstance()->end();
	}
}
/*�����˳���ť*/
void MainScene::JieshaoSignout(Ref* target, TouchEventType type)
{
	if(type == TouchEventType::TOUCH_EVENT_ENDED)
	{
		MusicManager::PlayEffectMusic("music/ButtoOk.mp3");

		ButtonMap.at(_began)->setEnabled(true);
	    ButtonMap.at(_record)->setEnabled(true);
	    ButtonMap.at(_introduce)->setEnabled(true);
        ButtonMap.at(_signout)->setEnabled(true);
		/*ͼƬ*/
		this->removeChild(getChildByTag(99));
	}
}