#include "Music.h"
#include "Frame.h"
#include "SimpleAudioEngine.h"
#include "Common.h"
#include "Player.h"
Music::Music()
{
	m_InterFace=NULL;
	m_Role=false;
	Yizhang=false;
	Liangzhang=false;
}
Music::~Music()
{
}
void Music::setDosJiaose(Common* m_Dos)
{
	m_DosJise=m_Dos;
	Yizhang=false;
	Liangzhang=false;
	Frame::getInstance()->setFivePoker(false);
}
void Music::PlayMusic(Moves m_Moves)
{
	do{
	if(m_Moves==_NULL)
		break;
	if(m_Role)
	{
	BoyMusic(m_Moves);	
	ManYouGood(m_Moves);
	}
	else
	{
	GirlMusic(m_Moves);
	GirlYouGood(m_Moves);
	}
	Wang(m_Moves);
	}while(0);
}
/*������������*/
void Music::Wang(Moves m_Moves)
{
	int MyPokerNum=m_DosJise->getPokerNum();
    if(MyPokerNum==1&&!Yizhang)
	{
		Yizhang=true;
		if(m_Role)
		CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_baojing1.mp3");
		else
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_baojing1.mp3");
	}
	else if(MyPokerNum==2&&!Liangzhang)
	{
		Liangzhang=true;
        if(m_Role)
		CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_baojing2.mp3");
		else
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_baojing2.mp3");
	}
     
	if(MyPokerNum<=4&&Player::getInstance()->getRole()!=m_DosJise->getRole())
    if(!Frame::getInstance()->getFivePoker())
	{
		Frame::getInstance()->setFivePoker(true);
		CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("music/MusicEx_Normal2.mp3",true);
	}
}
void Music::BoyMusic(Moves m_Moves)
{
	do{
	char m_Poker=Frame::getInstance()->getpoker().at(0);
	float a;
	for(int i=0;i<8;i++)
		a=RAND_0_9();

	if(m_Moves==_buyao)
	{
		if(a<0.3f)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_buyao1.mp3");
		else if(a>=0.3f&&a<0.5f)
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_buyao2.mp3");
		else if(a>=0.5f&&a<0.7f)
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_buyao3.mp3");
		else
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_buyao4.mp3");
		break;
	}

	if(a<0.1f)
	{
		for(int i=0;i<2;i++)
		a=RAND_0_9();
			if(a<0.4f)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_dani2.mp3");
		else if(a>=0.4f&&a<0.7f)
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_dani2.mp3");
		else 
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_dani3.mp3");
		break;
	}

	if(m_Moves==_dan)
	{
		if(m_Poker=='W')
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(StringUtils::format("music/Man_%c.mp3",'S').c_str());
		else
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(StringUtils::format("music/Man_%c.mp3",m_Poker).c_str());
	}
	else if(m_Moves==_duizi)
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(StringUtils::format("music/Man_dui%c.mp3",m_Poker).c_str());

	else if(m_Moves==_santiao)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(StringUtils::format("music/Man_tuple%c.mp3",m_Poker).c_str());

	else if(m_Moves==_sandaiyi)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_sandaiyi.mp3");

	else if(m_Moves==_sandaidui)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_sandaiyidui.mp3");

	else if(m_Moves==_shunzi)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_shunzi.mp3");

	else if(m_Moves==_liandui)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_liandui.mp3");

	else if(m_Moves==_feiji||m_Moves==_feijidai1||m_Moves==_feijidai2)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_feiji.mp3");

	else if(m_Moves==_zhadan)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_zhadan.mp3");

	else if(m_Moves==_sidai1)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Baojing.mp3");

	else if(m_Moves==_sidai2)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_sidaier.mp3");

	else if(m_Moves==_wangzha)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Man_wangzha.mp3");
	}while(0);
}
void Music::GirlMusic(Moves m_Moves)
{
	do{
		std::mutex m_mutex;
	char m_Poker=Frame::getInstance()->getpoker().at(0);
	float a;
	for(int i=0;i<8;i++)
		a=RAND_0_9();

	if(m_Moves==_buyao)
	{
		if(a<0.3f)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_buyao1.mp3");
		else if(a>=0.3f&&a<0.5f)
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_buyao2.mp3");
		else if(a>=0.5f&&a<0.7f)
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_buyao3.mp3");
		else
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_buyao4.mp3");
		break;

	}

	if(a<0.1)
	{
		for(int i=0;i<2;i++)
		a=RAND_0_9();
	    a*=10;
			if(a<4)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_dani2.mp3");
		else if(a>=4&&a<7)
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_dani2.mp3");
		else 
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_dani3.mp3");
		break;
	}

	if(m_Moves==_dan)
	{
		if(m_Poker=='W')
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(StringUtils::format("music/Woman_%c.mp3",'S').c_str());
		else
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(StringUtils::format("music/Woman_%c.mp3",m_Poker).c_str());
	}

	else if(m_Moves==_duizi)
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(StringUtils::format("music/Woman_dui%c.mp3",m_Poker).c_str());

	else if(m_Moves==_santiao)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(StringUtils::format("music/Woman_tuple%c.mp3",m_Poker).c_str());

	else if(m_Moves==_sandaiyi)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_sandaiyi.mp3");

	else if(m_Moves==_sandaidui)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_sandaiyidui.mp3");

	else if(m_Moves==_shunzi)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_shunzi.mp3");

	else if(m_Moves==_liandui)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_liandui.mp3");

	else if(m_Moves==_feiji||m_Moves==_feijidai1||m_Moves==_feijidai2)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_feiji.mp3");

	else if(m_Moves==_zhadan)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_zhadan.mp3");

	else if(m_Moves==_sidai1)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Baojing.mp3");

	else if(m_Moves==_sidai2)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_sidaier.mp3");

	else if(m_Moves==_wangzha)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/Woman_wangzha.mp3");
	}while(0);
}
void Music:: ManYouGood(Moves m_Moves)
{
	if(m_Moves==_shunzi||m_Moves==_liandui||m_Moves==_feijidai2||m_Moves==_zhadan||m_Moves==_feiji)
{
	float a;
	for(int i=0;i<5;i++)
		a=RAND_0_9();
	if(a<0.2f)
	{
    for(int i=0;i<2;i++)
		a=RAND_0_9();
	if(a<0.5f)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/ManHeZuo.mp3");
	else
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/ManTaihao.mp3");
	}
}
}
void Music:: GirlYouGood(Moves m_Moves)
{
	if(m_Moves==_shunzi||m_Moves==_liandui||m_Moves==_feijidai2||m_Moves==_zhadan||m_Moves==_feiji)
{
    float a;
	for(int i=0;i<5;i++)
		a=RAND_0_9();
	if(a<0.2f)
	{
    for(int i=0;i<2;i++)
		a=RAND_0_9();
	if(a<0.5f)
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/WomanHeZuo.mp3");
	else
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("music/WomanTaihao.mp3");
	}
}
}