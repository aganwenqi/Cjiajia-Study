#include "Newcards.h"
#include "PlayingCards.h"
#include "Route.h"
#include "Player.h"
#include "InterFace.h"
#include "pDataManager.h"
#include "SimpleAudioEngine.h"
#include "MusicManager.h"
#include "MsgManager.h"
#include "FasongManager.h"
/*����*/
USING_NS_CC;
void Newcards::WePlaying(Moves m_Moves)
{
	std::mutex m_mutex;
	m_mutex.lock();
	if(m_Moves==_NULL)
	PlayMusic(_buyao);
	else
    PlayMusic(m_Moves);
		if(m_Moves==_end)
		{
			NOTIFY->postNotification("text",(Ref*)1);
		}
		else
		{
			m_InterFace->setWho(2);
	        m_InterFace->FuncTionWho();
		}
	Homing();
	this->GirlStop();
	FunctionFalse();
	m_mutex.unlock();
}
/*���ܶ����㷨*/
void Newcards::ZhiNengSuanfa()
{
	int a[21];
	int j=0;
	Moves m_Moves=_NULL;
	do{
	for(auto i:PlayingCardsVT)
	{
		a[j++]=i->getSize();
	}
	a[j]=0;

	/*����*/
	m_Moves=m_InterFace->PlayCards(a,RenjiChupai);
	Homing();
	Result(m_Moves,false);
	WePlaying(m_Moves);
	}while(0);
}
void Newcards::ZhiNeng(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
	MusicManager::PlayEffectMusic("music/Button.mp3");
	ZhiNengSuanfa();
	}
}
void Newcards::BuYao(Ref* target, TouchEventType type)
{
	
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
		MusicManager::PlayEffectMusic("music/Button.mp3");
		int a[1]={100};
		/*����*/
	    Moves m_Moves=m_InterFace->PlayCards(a,Youplay);
		 if(m_Moves==_first)
			return;
		 if(MsgManager::getInstance()->getpattern())
		 {
			 a[0]=0;
	     FasongManager::getInstance()->PlayCards(a,m_Moves,m_Myname->getString().c_str());
		 }
		 WePlaying(m_Moves);
	}
	
}
void Newcards::ChuPai(Ref* target, TouchEventType type)
{
	
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
		MusicManager::PlayEffectMusic("music/Button.mp3");
		do{
		std::mutex m_mutex;
		Moves m_Moves=Playing();
		CC_BREAK_IF(m_Moves==_NULL);
		Result(m_Moves,true);
		WePlaying(m_Moves);
		}while(0);
	}
	
}
Moves Newcards::Playing()
{
	int b[21]={0},j=0;
	Moves m_Moves=_NULL;
	for(auto i:PlayingCardsVT)
	{
		if(i->getState())
		{
		b[j++]=i->getSize();
		}
	}

	/*����*/
	m_Moves=m_InterFace->PlayCards(b,Youplay);
	return m_Moves;
}
std::function<void(void)> Newcards::Function()
{
	 std::function<void(void)> p=[=](){
	 if(pDataManager::getInstance()->getZuzhi())
			return;

	 this->scheduleOnce(schedule_selector(Newcards::Playupdate),0.5f);
	 };
	 return p;
}
/*��ʼ����*/
void Newcards::Playupdate(float dt)
{
	if(m_Tuoguan)
	ZhiNengSuanfa();
	else
	FunctionTrue(1);
}

void Newcards::PlayPokers()
{
	Vector<PlayingCards*> PlayingCardsVTWantToDelete;
	for(auto i:PlayingCardsVT)
	{
		/*��Ҫ�����ƴ浽��ɾ�б�*/
		if(i->getState())
         PlayingCardsVTWantToDelete.pushBack(i);
	}


    /* ��ʽ���ƣ�ɾ�ƣ� */
    for (auto i : PlayingCardsVTWantToDelete) 
	{
        i->removeFromParent();
        PlayingCardsVT.eraseObject(i);
    }
	RowOfCards();
}
/*�ƹ�λ*/
void Newcards::Homing()
{
	for(auto i:PlayingCardsVT)
		{
			if(i->getState())
			{
			i->setPositionY(i->getPositionY()-20);
		    i->setState(false);
			}
		}
}
/*����*/
void Newcards::RowOfCards()
{
	int size=PlayingCardsVT.size();
	if(size==0)return;

    int TotalWidth=0;
	for(int i=1;i<=size-1;i++)
	{
		TotalWidth+=25;
	}
	TotalWidth+=105;
	TotalWidth=0-TotalWidth/2;
	for(auto i:PlayingCardsVT)
	{
		i->setPositionX(TotalWidth);
		i->setVisible(true);
		TotalWidth+=25;
	}
}
