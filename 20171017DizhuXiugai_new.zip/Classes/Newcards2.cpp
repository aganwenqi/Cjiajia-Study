#include "Newcards.h"
#include "PlayingCards.h"
#include "Route.h"
#include "Player.h"
#include "InterFace.h"
#include "FasongManager.h"
#include "MsgManager.h"
void Newcards::GirlRun()
{
	RotateBy*rotateBy=RotateBy::create(0.4f,0,30);
	RotateBy*rotateBy1=RotateBy::create(0.4f,0,-30);
	auto* actions=Sequence::create(rotateBy,rotateBy1,NULL);
	/*�������ö���*/
    auto repeat=RepeatForever::create(actions);
	m_Chuyin->runAction(repeat);
	m_Chupai->setVisible(true);
}
void Newcards::GirlStop()
{
	m_Chuyin->stopAllActions();
	/*���û�����Ƕ�*/
	m_Chuyin->setRotationY(0);
	m_Chupai->setVisible(false);
}
void Newcards::FunctionTrue(int i)
{
	m_ZhiNeng->setVisible(true);	
	m_ZhiNeng->setEnabled(true);

	m_BuYao->setVisible(true);
	m_BuYao->setEnabled(true);

	m_ChuPai->setVisible(true);
	m_ChuPai->setEnabled(true);
	if(i)
	GirlRun();
}
/*���ذ�ť*/
void Newcards::FunctionFalse()
{
	m_ZhiNeng->setVisible(false);	
	m_ZhiNeng->setEnabled(false);

	m_BuYao->setVisible(false);
	m_BuYao->setEnabled(false);

	m_ChuPai->setVisible(false);
	m_ChuPai->setEnabled(false);
}
/*���ƽ��*/
void Newcards::Result(Moves m_Moves,bool quite)
{
	int a[21],j=0;
	a[0]=0;
	do{
	CC_BREAK_IF(m_Moves==_NULL);
		/*ת��*/
	if(!quite)
	Result(Player::getInstance()->Jiepoker);
	for(auto i:PlayingCardsVT)
	{
		if(i->getState())
		a[j++]=i->getID();
	}
	a[j]=0;
	m_InterFace->RobotSetTake(a,m_Moves);
	PlayPokers();
	}while(0);
	 if(MsgManager::getInstance()->getpattern())
	 {
	FasongManager::getInstance()->PlayCards(a,m_Moves,m_Myname->getString().c_str());
	 }
}
/*�˿��Ƶ�ת��*/
void Newcards::Result(int* a)
{
	for(int i=0;a[i]!=0;i++)
	{
		log("%d",a[i]);
	}

	for(int s=0;a[s]!=0;s++)
	{
	for(auto i:PlayingCardsVT)
	{
		if(i->getState()!=true)
		{
		if(a[s]==i->getSize())
		{
			i->setState(true);
			break;
		}
		}
	}
	}
}
/*�������п��ü��Ķ���*/
void Newcards::YinCang()
{
	FunctionFalse();
	m_Chuyin->setVisible(false);
	m_Chupai->setVisible(false);
    m_Jiase->setVisible(false);
	m_Myname->setVisible(false);
	for(auto i:PlayingCardsVT)
	{
		i->setVisible(false);
	}
}
/*��ʾ���п������Ķ���*/
void Newcards::XianShi()
{
	//FunctionTrue(0);
	m_Chuyin->setVisible(true);
	//m_Chupai->setVisible(true);
    m_Jiase->setVisible(true);
	m_Myname->setVisible(true);
	for(auto i:PlayingCardsVT)
	{
		i->setVisible(true);
	}
}