#include "LianwangScene.h"
#include "SceneManager.h"
#include "MusicManager.h"
#include "MoxingManager.h"
#include "FasongManager.h"
#include "MsgManager.h"
USING_NS_CC_EXT;
USING_NS_CC;
LianwangScene::LianwangScene()
{
	lbl=true;
	idandduankou=true;
	ljwc=true;
}
LianwangScene::~LianwangScene()
{
}
Scene* LianwangScene::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = LianwangScene::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}
bool LianwangScene::init()
{
  if(!Layer::init())
   {return false;}
     // MusicManager::PlayEffectMusic("music/Button.mp3");
     //����UI
     auto UI=cocostudio::GUIReader::getInstance()->widgetFromJsonFile("UI/Fuwuqi/Fuwuqi_1.ExportJson");//widgetFromJsonFile����UI�ļ���������
     this->addChild(UI);
	 //��ȡ�ؼ�����
   
     lianjie=(Button*)Helper::seekWidgetByName(UI,"lianjie");
	 tui=(Button*)Helper::seekWidgetByName(UI,"tui");
	
	/*/*������id�Ͷ˿�*/
 
	 xszt=(TextField*)Helper::seekWidgetByName(UI,"text3");
      //���Ӱ�ť���Ӽ���
	 xszt->setText("NotConnected");
	 
     tui->addTouchEventListener(this,toucheventselector(LianwangScene::menuCloseCallback));
	 lianjie->addTouchEventListener(this,toucheventselector(LianwangScene::Lianjiefuwuqi));
	 Shurukuang();
   //����������ִ�еĺ���
    return true;
}
void LianwangScene::Shurukuang()
{
	id = EditBox::create(Size(300,40),
        Scale9Sprite::create("sprite/1.0.png"),
        Scale9Sprite::create("sprite/1.0.png"));
	 //�����ı����λ��
    id->setPosition(Point(500,445));
	id->setFontColor(ccc3(255,0,0));
	id->setMaxLength(20);
	id->setPlaceHolder("Please input IP");
	id->setInputMode(EditBox::InputMode::EMAIL_ADDRESS);
    //�����ı��򵽲���
    addChild(id);
    
	duankou= EditBox::create(Size(300,40),
        Scale9Sprite::create("sprite/1.0.png"),
        Scale9Sprite::create("sprite/1.0.png"));
	duankou->setPosition(Point(500,385));
	duankou->setFontColor(ccc3(255,0,0));
	duankou->setMaxLength(10);
	duankou->setPlaceHolder("Please input PORT");
	duankou->setInputMode(EditBox::InputMode::NUMERIC);
    //�����ı��򵽲���
    addChild(duankou);
	setXML(2);
}
void LianwangScene::menuCloseCallback(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED&&ljwc)
	{
	MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
	SceneManager::getInstance()->changeScene(SceneManager::en_ManScene);
	}
}
void LianwangScene::Lianjiefuwuqi(Ref* target, TouchEventType type)
{

	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
		if(MsgManager::getInstance()->lianjie)
	{
		lianjie->setTitleText("OK");
		Shezhixianshi("successfully");
		return;
	}
	MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
	if(lbl)
	{
		xszt->setText("Connection");
		/* �������̣߳��������� */
		std::thread recvThread = std::thread(&LianwangScene::xiancheng, this);
		recvThread.detach();
	}
    }

}
void LianwangScene::xiancheng()
{
	
	lbl=false;
	ljwc=false;
	//MoxingManager* mm=MoxingManager::getInstance();
	const char* ip=id->getText();
	int port=Value(duankou->getText()).asInt();
	//const char* ip="192.168.1.107";
    //int port=7777;
	if(MoxingManager::getInstance()->start(ip,port))
	 {
		 Shezhixianshi("successfully");
		 lianjie->setTitleText("OK");
		 setXML(1);
		 MsgManager::getInstance()->lianjie=true;
	 }
	else
	{
		 Shezhixianshi("NotConnected");
		 lianjie->setTitleText("No");
		 MsgManager::getInstance()->lianjie=false;
	}
	ljwc=true;
	lbl=true;
}
/*������ʾ*/
void LianwangScene::Shezhixianshi(const char* a)
{
	this->xszt->setText(a);
}
void LianwangScene::setXML(int xml)//1��ʾ�浵��2��ʾȡ��
{
	if(xml==1)
	{
	ValueMap fileDataMap;
		ValueMap data;
		data["id"]=id->getText();
		data["password"]=duankou->getText();
		fileDataMap["Land"]=Value(data);
	std::string m_string=FileUtils::getInstance()->fullPathForFilename("demaxiya/Connect.plist");
	FileUtils::getInstance()->writeToFile(fileDataMap,m_string);//д�뱣��xml�ļ�
	}
	else if(xml==2)
	{
		std::string m_string=FileUtils::getInstance()->fullPathForFilename("demaxiya/Connect.plist");
		ValueMap fileDataMap=FileUtils::getInstance()->getValueMapFromFile(m_string);
		  if(fileDataMap.size()==0)
		 {
			 setXML(1);
		 }
		  else
		  {
			Value value=fileDataMap.at("Land");
			ValueMap data=value.asValueMap();
			id->setText(data["id"].asString().c_str());
			duankou->setText(data["password"].asString().c_str());
		  }
	}
}