#include "ServerLever.h"
#include "SceneManager.h"
#include "MusicManager.h"
Scene * ServerLever::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = ServerLever::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool ServerLever::init()
{	
   if(!Layer::init())
	return false;

    MusicManager::PlayBackgroundMusic("music/Fade.mp3",true);
	PlayAnimation();
    return true;
}
void ServerLever::PlayAnimation()
{
	 Size size=Director::getInstance()->getVisibleSize();

	auto sprite = Sprite::create("sprite/lever/keyi.jpg");
	sprite->setPosition(Point(size.width/2,size.height/2));
	this->addChild(sprite);


	 	MenuItemImage *close=MenuItemImage::create(
		"sprite/anniu.png",
		"sprite/anniu1.png",
		this,
		menu_selector(ServerLever::menuCloseCallback)
		);

	auto menu = Menu::create(close, NULL);
	menu->setPosition(Point(size.width/1.5f,size.height/5));
	this->addChild(menu);

    sprite = Sprite::create("sprite/lever/ServerLever.png");
	sprite->setPosition(Point(size.width/3,size.height/2));
	this->addChild(sprite);

	auto label=Label::create("Seriver is leave","Arial",60);
	label->enableShadow(Color4B::BLUE, Size(0, 0)); //��Ӱ
	label->setColor(Color3B::RED);
	label->setPosition(Point(770,400));
	sprite->addChild(label);



}
void ServerLever::menuCloseCallback(Ref* pData)
{
	SceneManager::getInstance()->changeScene(SceneManager::en_ManScene);
}
