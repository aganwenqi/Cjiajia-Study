#include "SocketDataManager.h"
#include "JsonData.h"
#include "QingbaoManager.h"
#include "QingBaoA.h"
SocketDataManager* SocketDataManager::m_SocketDataManager = NULL;

SocketDataManager::SocketDataManager()
{
	qbj=QingbaoManager::getInstance();
}

SocketDataManager::~SocketDataManager()
{
}

SocketDataManager* SocketDataManager::getInstance()
{
    if (m_SocketDataManager == NULL)
    {
        m_SocketDataManager = SocketDataManager::create();
        m_SocketDataManager->retain();
    }

    return m_SocketDataManager;
}

bool SocketDataManager::init()
{
    /* ����update���� */
    Director::getInstance()->getScheduler()->schedule(
        schedule_selector(SocketDataManager::update),
        this, 0.108f, false);

	/*Director::getInstance()->getScheduler()->schedule(
        schedule_selector(SocketDataManager::myupdate),
        this, 0.108f, false);*/
    return true;
}

void SocketDataManager::update(float dt)
{
    m_mutex.lock();

    for (auto value : m_msgList)
    {
		//int s=value.asString().size();
        /* �ɷ���Ϣ */
		log(value.asString().c_str());
        JsonData* jsonData = JsonData::create(value.asString().c_str());
		qbj->JieshouXiaoxin(jsonData);
    }

    m_msgList.clear();

    m_mutex.unlock();
}
/*
void SocketDataManager::myupdate(float dt)  // Ԥ�������ݵ�������
{
	 m_mutex.lock();
	 int sh=0;
     for (auto value : m_YCLmsgList)
    {

		sh=value.asString().size();
		if(sh==G_Length)
		m_msgList.push_back(value);
		else if(sh>G_Length)
		{
			int endIndex=G_Length;
			std::string lineStr;
			while(endIndex>0)
		  {
			lineStr=value.asString().substr(0,endIndex);
			m_msgList.push_back(Value(lineStr));
			value=Value(value.asString().substr(endIndex+1,sh));

			if(value.asString().size()<=G_Length)
			{
			 m_msgList.push_back(value);
			 endIndex=0;
			}
		  }
		}
    }
	m_YCLmsgList.clear();
    m_mutex.unlock();
}*/
void SocketDataManager::pushMsg(const char* msg)
{
    m_mutex.lock();

    m_msgList.push_back(Value(msg));

    m_mutex.unlock();
}
