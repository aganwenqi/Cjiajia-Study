#include "FasongManager.h"
#include "Enum.h"
#include "Route.h"
#include "MoxingManager.h"
#include "JsonData.h"
#include "json\writer.h"
#include "MoxingManager.h"
#include "QingBaoA.h"
#include "RobotOne.h"
#include "RobotTwo.h"
USING_NS_CC;
FasongManager* FasongManager::m_FasongManager=NULL;
FasongManager::FasongManager()
{
}
FasongManager::~FasongManager()
{
}
FasongManager* FasongManager::getInstance()
{
	if (m_FasongManager == NULL)
    {
        m_FasongManager = new FasongManager();
    }

    return m_FasongManager;
}

void FasongManager::Zhuce(String& id,String& mm)
{
	 /* ���ͳ�ע������ */
    JsonData* data = JsonData::create("{}");
    data->addValue(G_Ziduan::G_leixing,G_TXType::G_Zhuce);
	data->addValue(G_Ziduan::G_id,id.getCString());
	data->addValue(G_Ziduan::G_mm,mm.getCString());
    MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}
void FasongManager::Xiugai(String& id,String& mm)
{
     /* ���ͳ��޸����� */
    JsonData* data = JsonData::create("{}");
    data->addValue(G_Ziduan::G_leixing,G_TXType::G_Xiugai);
	data->addValue(G_Ziduan::G_id,id.getCString());
	data->addValue(G_Ziduan::G_mm,mm.getCString());
    MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}
void FasongManager::UserMsg(int g)//1��ʾ����û���������
{
    JsonData* data = JsonData::create("{}");
	if(g==1)
	{
    data->addValue(G_Ziduan::G_leixing,G_TXType::G_UserMsg1);
	}
    MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}
bool  FasongManager::Denglu(String& id,String& mm)
{
	Denglu(id.getCString(),mm.getCString());
	return true;
}
bool FasongManager::Denglu(const char* id, const char* mm)
{
	 /* ���͵�½���� */
    JsonData* data = JsonData::create("{}");
    data->addValue(G_Ziduan::G_leixing,G_TXType::G_Denglu);
	data->addValue(G_Ziduan::G_id,id);
	data->addValue(G_Ziduan::G_mm,mm);
    MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
	return true;
}
void FasongManager::getUserMsg()//��ȡ�û���Ϣ
{
	 /* ���ͻ�ȡ�û���Ϣ���� */
    JsonData* data = JsonData::create("{}");
    data->addValue(G_Ziduan::G_leixing,G_TXType::G_GetMsg);
    MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}
void FasongManager::getAllRoom()//��ȡ���еķ���
{
	 /* ��ȡ���з����� */
    JsonData* data = JsonData::create("{}");
	data->addValue(G_Ziduan::G_leixing,G_TXType::G_getAllRoom);
	MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}
void FasongManager::NewRoom()//����
{
	 /* ���ʹ������� */
    JsonData* data = JsonData::create("{}");
	data->addValue(G_Ziduan::G_leixing,G_TXType::G_NewRoom);
	MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}
void FasongManager::TuiRoom(const char * yn)//�˷�
{
	 /* �˷����� */
    JsonData* data = JsonData::create("{}");
	data->addValue(G_Ziduan::G_leixing,G_TXType::G_TuiRoom);
	data->addValue(G_Ziduan::G_roomnumble,yn);
	MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}
void FasongManager::ComeRoom(std::string str)//����ѡ������
{
		 /* �������� */
    JsonData* data = JsonData::create("{}");
	data->addValue(G_Ziduan::G_leixing,G_TXType::G_ComeRoom);
	data->addValue(G_Ziduan::G_roomnumble,str.c_str());
	MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}
void FasongManager::Zhunbei(bool state,const char *yn)//׼����ť���¼�
{
		 /* ׼������ */
    JsonData* data = JsonData::create("{}");
	data->addValue(G_Ziduan::G_leixing,G_TXType::G_zhunbei);
	data->addValue(G_Ziduan::G_roomnumble,yn);
	data->addValue(G_Play::G_playstate,Value(state).asInt());
	MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}
void FasongManager::Kaishi(const char *yn)//��ʼ
{
		 /* ׼������ */
    JsonData* data = JsonData::create("{}");
	data->addValue(G_Ziduan::G_leixing,G_TXType::G_Began);
	data->addValue(G_Ziduan::G_roomnumble,yn);
	MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}
void FasongManager::PlayCards(int* poker,Moves m_Moves,const char* name)//����
{
	JsonData* data = JsonData::create("{}");
	data->addValue(G_Ziduan::G_leixing,G_TXType::G_PlayCards);
	data->addValue(G_Ziduan::G_CardsType,Value(m_Moves).asInt());
	data->addValue(G_Play::G_playname,RobotOne::getInstance()->getplayname().c_str());
	data->addValue(G_Play::G_Twoname,RobotTwo::getInstance()->getplayname().c_str());
	data->addValue(G_Play::G_WhoPlayPoker,name);
	for(int i=0;poker[i]!=0;i++)
	{
	data->addValue(G_Play::G_Poker,i,poker[i]);
	}
	if(poker[0]==0)
	data->addValue(G_Play::G_Poker,0,0);

	//log(data->getsJsonStr().c_str());
	MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}
void FasongManager::Closer()//�رջ��˳���Ϸ
{
    JsonData* data = JsonData::create("{}");
	data->addValue(G_Ziduan::G_leixing,G_TXType::G_Closer);
	MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}
void FasongManager::lotoff()//ע��
{
	JsonData* data = JsonData::create("{}");
	data->addValue(G_Ziduan::G_leixing,G_TXType::G_lotoff);
	MoxingManager::getInstance()->sendMsg(data->getsJsonStr().c_str());
}