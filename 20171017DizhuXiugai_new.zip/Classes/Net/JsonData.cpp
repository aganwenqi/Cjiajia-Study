#include "JsonData.h"
#include "writer.h"
#include "reader.h"
JsonData::JsonData()
{
}

JsonData::~JsonData()
{
}

JsonData* JsonData::create( const char* data )
{
	JsonData* layer = new JsonData();

	if(layer && layer->init(data)) {
		layer->autorelease();
	}
	else {
		CC_SAFE_DELETE(layer);
	}

	return layer;
}

bool JsonData::init( const char* data )
{
    Json::Reader reader;

    if (!reader.parse(data, root, false))
    {
        return false;
    }

	return true;
}
Json::Value JsonData::getRoot()
{
	return root;
}
Json::Value* JsonData::getTrueRoot()
{
	return &root;
}
const char* JsonData::getCStrData( const char* key )
{
    if (isHasKey(key) == false)
    {
        return "";
    }
    return root[key].asCString();
}
String JsonData::getStrData( const char* key )
{
    if (isHasKey(key) == false)
    {
        return "";
    }
    return root[key].asString();
}

int JsonData::getIntData( const char* key )
{
    if(isHasKey(key) == false)
    {
        return 0;
    }
    return root[key].asInt();
}
int JsonData::getIntData(const char* key,const int i)
{
	 if(isHasKey(key) == false)
    {
        return 0;
    }
    return root[key][i].asInt();
}
bool JsonData::getBoolData( const char* key )
{
    if(isHasKey(key) == false)
    {
        return false;
    }
    return root[key].asBool();
}

float JsonData::getDoubleData( const char* key )
{
    if(isHasKey(key) == false)
    {
        return 0;
    }
    return root[key].asDouble();
}

bool JsonData::isHasKey( const char* key )
{
    if (root.isMember(key))
    {
        return true;
    }

    return false;
}

std::string JsonData::getsJsonStr()
{
    Json::FastWriter writer;
    std::string json_file = writer.write(root);

    return json_file;
}
const char* JsonData::getShuzuData(const char* key,int i)
{
	if(isHasKey(key) == false||root[key].size()<=i)
    {
        return "";
    }
   return root[key][i].asCString();
}
const char* JsonData::getShuzuData(const char* key,const char* msg)
{
	if(isHasKey(key) == false)
    {
        return "";
    }
   return root[key][msg].asCString();
}
const char* JsonData::getShuzuData(const char* key,int i,const char* msg)
{
	if(isHasKey(key) == false)
    {
        return "";
    }
   return root[key][i][msg].asCString();
}
const bool JsonData::getBoolShuzuData(const char* key,int i,const char* msg)
{
	if(isHasKey(key) == false)
    {
        return false;
    }
   return root[key][i][msg].asBool();
}
const int JsonData::getIntShuzuData(const char* key,int i,const char* msg)
{
	if(isHasKey(key) == false)
    {
        return 0;
    }
   return root[key][i][msg].asInt();
}
void JsonData::addValue(const char* key, int value)
{
    root[key] = value;
}

void JsonData::addValue(const char* key, const char* value)
{
    root[key] = value;
}
void JsonData::addValue(const char* key, int i,int value)
{
	root[key][i] = value;
}