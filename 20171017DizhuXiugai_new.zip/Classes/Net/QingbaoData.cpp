#include "QingbaoData.h"
#include "JsonData.h"
#include "QingBaoA.h"
#include "DengluScene.h"
#include "MsgManager.h"
#include "NetRoom.h"
#include "NetRoom1.h"
#include "MainScene.h"
#include "SceneManager.h"
#include "NetPokerMsg.h"
#include "Route.h"
QingbaoData::QingbaoData()
{
	netMsg=new NetPokerMsg();
}
QingbaoData::~QingbaoData()
{
}
void QingbaoData::ZhuceXiugai(JsonData* jsonData)
{
	 if(m_DengluScene)
	  m_DengluScene->setQingbao(jsonData);
}
void QingbaoData::DengluQB(JsonData* jsonData)
{
	const char* yn;
	yn=jsonData->getCStrData(G_Ziduan::G_yn);
	if(yn==std::string(G_TXType::G_Chenggong))//�ɹ�
	{
		MsgManager::getInstance()->deleteJsonData(G_TXType::G_Denglu);//ɾ����Ϣ���鱨
		MsgManager::getInstance()->setmsgMap(G_TXType::G_Denglu,jsonData);//������Ϣ���鱨
		MsgManager::getInstance()->quite=true;
	}
	 if(m_DengluScene)
	  m_DengluScene->setQingbao(yn);
}
void QingbaoData::lotoff(JsonData* jsonData)
{
	const char* yn;
	yn=jsonData->getCStrData(G_Ziduan::G_yn);
	if(yn==std::string(G_TXType::G_Chenggong))//�ɹ�
	{
	    m_DengluScene->setQingbao();
	}
}
void QingbaoData::GetUserMsg(JsonData* jsonData)
{
	const char* yn;
	yn=jsonData->getCStrData(G_Ziduan::G_yn);
	if(yn==std::string(G_TXType::G_Chenggong))//�ɹ�
	{
		m_MainScene->setQingbao1(jsonData);
	}
}
void QingbaoData::getAllRoom(JsonData* jsonData)
{
	const char* yn;
	yn=jsonData->getCStrData(G_Ziduan::G_yn);
	if(yn==std::string(G_TXType::G_Chenggong))//�ɹ�
	{
		int max=jsonData->getRoot()[G_Ziduan::G_AllRoom].size();
		const char *data[50];
		int i;
		for(i=0;i<max;i++)
		{
		yn=jsonData->getShuzuData(G_Ziduan::G_AllRoom,i);
		data[i]=yn;
		}
		data[i]=NULL;
		if(m_NetRoom!=NULL)
		m_NetRoom->setQingbao1(data);
		m_MainScene=NULL;
	}
}
void QingbaoData::NewRoom(JsonData* jsonData)/*��������*/
{
	const char* yn;
	yn=jsonData->getCStrData(G_Ziduan::G_yn);
	if(yn==std::string(G_TXType::G_Chenggong))//�ɹ�
	{
		m_NetRoom->setQingbao(jsonData);
		m_NetRoom=NULL;
	}
}
void QingbaoData::getRoomMsg(JsonData* jsonData)/*��ȡ���������鱨,���뷿��*/
{
	const char* yn;
	yn=jsonData->getCStrData(G_Ziduan::G_yn);
	if(yn==std::string(G_TXType::G_Chenggong)&&!MsgManager::getInstance()->getpattern())//�ɹ�
	{

		SceneManager::getInstance()->changeScene(SceneManager::en_NetRoom1);
		m_NetRoom1->setQingbao(jsonData);
	}
}
void QingbaoData::TuiRoom(JsonData* jsonData)
{
	const char* yn;
	yn=jsonData->getCStrData(G_Ziduan::G_yn);
	if(yn==std::string(G_TXType::G_Chenggong))//�ɹ�
	{
		MsgManager::getInstance()->setpattern(false);
		m_NetRoom1->setQingbao(true,yn);
		m_NetRoom1=NULL;
	}
}
void QingbaoData::Zhunbei(JsonData* jsonData)
{
	const char* yn;
	yn=jsonData->getCStrData(G_Ziduan::G_yn);
	if(yn==std::string(G_TXType::G_Chenggong)&&!MsgManager::getInstance()->getpattern())//�ɹ�
	{
		m_NetRoom1->setQingbao(jsonData);
	}
}
void QingbaoData::Began(JsonData* jsonData)//��ʼ
{
	const char* yn;
	yn=jsonData->getCStrData(G_Ziduan::G_yn);
	if(yn==std::string(G_TXType::G_Chenggong))//�ɹ�
	{
		Json::Value root=jsonData->getRoot();
		MsgManager *msg=MsgManager::getInstance();
		int i,max=root[G_Play::G_Poker].size();
		for(i=0;i<max;i++)
		{
		msg->myPoker[i]=jsonData->getIntData(G_Play::G_Poker,i);
		}
		msg->myPoker[i]=0;

		int j=1;
		max=root[G_Ziduan::G_RoomMsg][j][G_Play::G_Poker].size();
		msg->onename=root[G_Ziduan::G_RoomMsg][j][G_Play::G_playname].asCString();
		for(i=0;i<max;i++)
		{
		msg->onePoker[i]=root[G_Ziduan::G_RoomMsg][j][G_Play::G_Poker][i].asInt();
		}
		msg->onePoker[i]=0;

		j=0;
		max=root[G_Ziduan::G_RoomMsg][j][G_Play::G_Poker].size();
		msg->twoname=root[G_Ziduan::G_RoomMsg][j][G_Play::G_playname].asCString();
		for(i=0;i<max;i++)
		{
		msg->twoPoker[i]=root[G_Ziduan::G_RoomMsg][j][G_Play::G_Poker][i].asInt();
		}
		msg->twoPoker[i]=0;

	
		msg->setpattern(true);
		msg->setplayerState(jsonData->getBoolData(G_Play::G_playstate));
		MsgManager::getInstance()->deleteJsonData(G_TXType::G_Began);//ɾ����Ϣ���鱨
		MsgManager::getInstance()->setmsgMap(G_TXType::G_Began,jsonData);//������Ϣ���鱨
		SceneManager::getInstance()->changeScene(SceneManager::en_PokerScene);
		m_NetRoom1=NULL;
	}

}
void QingbaoData::Play_Cards(JsonData* jsonData)
{
	const char* yn;int i;
	yn=jsonData->getCStrData(G_Ziduan::G_yn);
	if(yn==std::string(G_TXType::G_Chenggong))//�ɹ�
	{
		Json::Value root=jsonData->getRoot();
		netMsg->NextPlayName=jsonData->getCStrData(G_Play::G_playname);
		netMsg->m_Moves=Moves(jsonData->getIntData(G_Ziduan::G_CardsType));
		netMsg->WhoPokerName=jsonData->getCStrData(G_Play::G_WhoPlayPoker);
		netMsg->poker[0]=0;
		if(netMsg->m_Moves!=_buyao)
		for(i=0;i<root[G_Play::G_Poker].size();i++)
		{
			netMsg->poker[i]=root[G_Play::G_Poker][i].asInt();
			netMsg->poker[i+1]=0;
		}
		NOTIFY->postNotification("NetPoker",netMsg);/*�ܹ���������*/
	}
}
void QingbaoData::lever(JsonData* jsonData)
{
	MsgManager::getInstance()->create();
	SceneManager::getInstance()->changeScene(SceneManager::en_ServerLever);
}