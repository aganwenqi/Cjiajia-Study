#include "NetRoom.h"
#include "SceneManager.h"
#include "MusicManager.h"
#include "QingbaoManager.h"
#include "MsgManager.h"
#include "FasongManager.h"
#include "QingBaoA.h"
#include "JsonData.h"
USING_NS_CC;
Scene* NetRoom::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = NetRoom::create();
	QingbaoManager::getInstance()->m_NetRoom=layer;
    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}
NetRoom::NetRoom()
{
	m_chuangfang=false;
}
	/*��ʼ����������*/
void NetRoom::Initialization()
{
	
}
bool NetRoom::init()
{
	Initialization();
	Size visible=Director::getInstance()->getVisibleSize();
	/*����UI*/
    auto UI=cocostudio::GUIReader::getInstance()->widgetFromJsonFile("UI/Room_1/Room_1_1.ExportJson");
	this->addChild(UI);

	//ParticleSystemQuad* particle = ParticleSystemQuad::create("slowLight.plist");
	//addChild(particle);

	tui=(Button*)Helper::seekWidgetByName(UI,"tui");
	newroom=(Button*)Helper::seekWidgetByName(UI,"newroom");
	refresh=(Button*)Helper::seekWidgetByName(UI,"refresh");
	newroom->addTouchEventListener(this,toucheventselector(NetRoom::NewRoom));
	tui->addTouchEventListener(this,toucheventselector(NetRoom::Tuichu));
	refresh->addTouchEventListener(this,toucheventselector(NetRoom::Refresh));
	Button* anniu;
	std::string str;
	for(int i=1;i<10;i++)
	{
		str=StringUtils::format("room%d",i);
		anniu=(Button*)Helper::seekWidgetByName(UI,str.c_str());
		ButtonMap.pushBack(anniu);
	}
	return true;
}
/*�˳���ť*/
void NetRoom::Tuichu(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
		MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
		SceneManager::getInstance()->changeScene(SceneManager::en_ManScene);
	}
}
/*��������*/
void NetRoom::NewRoom(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED&&MsgManager::getInstance()->fanghao.empty())
	{
		if(!m_chuangfang)
		FasongManager::getInstance()->NewRoom();
	}

}
/*ˢ�·���*/
void NetRoom::Refresh(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
		for(auto i:ButtonMap)
	{
		i->setTitleText("");
	}
		FasongManager::getInstance()->getAllRoom();
	}
}
bool NetRoom::setQingbao(JsonData* jsonData)
{
	   
		MsgManager::getInstance()->setmsgMap("NetRoom",jsonData);
		MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
	    SceneManager::getInstance()->changeScene(SceneManager::en_NetRoom1);
		m_chuangfang=true;
		return true;
}
bool NetRoom::setQingbao1(const char** qb)
{
	for(auto i:ButtonMap)
	{
		i->setTitleText("");
	}
	Button* bt=NULL;
	for(int i=0;qb[i]!=NULL;i++)
	{
		bt=ButtonMap.at(i);
		if(bt){
		bt->setTitleText(qb[i]);
		bt->addTouchEventListener(this,toucheventselector(NetRoom::ComeRoom));
		}
	}
	return true;
}
/*���뷿��*/
void NetRoom::ComeRoom(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
		std::string str=static_cast<Button*>(target)->getTitleText();
		if(!str.empty())
		{
			FasongManager::getInstance()->ComeRoom(str);
		}
	}
}
