#ifndef _NetRoom1_H_
#define _NetRoom1_H_
#include "cocos2d.h"
#include "editor-support/cocostudio/CCSGUIReader.h"
#include "extensions/cocos-ext.h"
#include "ui/CocosGUI.h"
using namespace cocos2d::ui;
using namespace cocostudio;


class JsonData;
class NetRoom1:public cocos2d::Layer
{
public:
	NetRoom1();
	static cocos2d::Scene* createScene();

	virtual bool init();
	CREATE_FUNC(NetRoom1);

	void Tuichu(cocos2d::Ref* target, TouchEventType type);

	void Zhunbei(cocos2d::Ref* target, TouchEventType type);
	void Kaishi(cocos2d::Ref* target, TouchEventType type);
	/*��ʼ����������*/
	void Initialization();
	bool setQingbao(bool yn,const char* qb);
	bool setQingbao(JsonData* jsonData);
private:
	void CreateData();//���ݳ�ʼ��
	Button* tui;

	Button* zhunbei;
	Button* kaishi;
	TextField* fanghao;
	bool zhunbeia;//��׼��
	/*���*/
	bool zhunBJ;
	bool beganBJ;
	cocos2d::Map<std::string,TextField*> textMap;
	cocos2d::Map<std::string,cocos2d::Sprite*> spriteMap;
};
#endif
