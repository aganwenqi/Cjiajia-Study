#include "NetPokerMsg.h"
NetPokerMsg::NetPokerMsg()
{
	NextPlayName="";
	WhoPokerName="";
	m_Moves=_NULL;
}
NetPokerMsg::~NetPokerMsg()
{
}