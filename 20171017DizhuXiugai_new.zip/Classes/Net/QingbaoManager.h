#ifndef _QingbaoManager_H_
#define _QingbaoManager_H_
#include "QingbaoData.h"
class QingbaoManager:public QingbaoData
{
public:
	QingbaoManager();
	~QingbaoManager();
	static QingbaoManager* getInstance();

	void JieshouXiaoxin(JsonData* jsonData);
	void lianjieJiancha(const char* leixing);//���Ӽ��
	int lianjie;//���Ӽ���


private:
	static QingbaoManager* m_QingbaoManager;

	/*�ƿظ����鱨*/
public:
};
#endif