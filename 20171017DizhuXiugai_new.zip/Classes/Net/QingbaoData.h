#ifndef _QingbaoData_H_
#define _QingbaoData_H_
#include "Define.h"
#include "Enum.h"
class JsonData;
class DengluScene;
class NetRoom;
class NetRoom1;
class MainScene;
class NetPokerMsg;
class QingbaoData:public Ref
{
public:
	QingbaoData();
	~QingbaoData();

	void ZhuceXiugai(JsonData* jsonData);
	void DengluQB(JsonData* jsonData);
	void lotoff(JsonData* jsonData);
	void GetUserMsg(JsonData* jsonData);
	void getAllRoom(JsonData* jsonData);
	void NewRoom(JsonData* jsonData);
	void getRoomMsg(JsonData* jsonData);
	void TuiRoom(JsonData* jsonData);
	void Zhunbei(JsonData* jsonData);
	void Began(JsonData* jsonData);
	void Play_Cards(JsonData* jsonData);
	void lever(JsonData* jsonData);//����������
	DengluScene* m_DengluScene;
	NetRoom* m_NetRoom;
	NetRoom1* m_NetRoom1;
	MainScene* m_MainScene;

protected:
	/*���������ƴ��ݵ���Ϣ*/
	NetPokerMsg *netMsg;
};
#endif