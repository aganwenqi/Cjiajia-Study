#ifndef _NetRoom_H_
#define _NetRoom_H_
#include "cocos2d.h"
#include "editor-support/cocostudio/CCSGUIReader.h"
#include "extensions/cocos-ext.h"
#include "ui/CocosGUI.h"
using namespace cocos2d::ui;
using namespace cocostudio;

class JsonData;
class NetRoom:public cocos2d::Layer
{
public:
	NetRoom();
	static cocos2d::Scene* createScene();

	virtual bool init();
	CREATE_FUNC(NetRoom);

	/*��ʼ����������*/
	void Initialization();
	/*�˳���ť*/
	void Tuichu(cocos2d::Ref* target, TouchEventType type);
	/*��������*/
	void NewRoom(cocos2d::Ref* target, TouchEventType type);
	/*ˢ�·���*/
	void Refresh(cocos2d::Ref* target, TouchEventType type);
	/*���뷿��*/
	void ComeRoom(Ref* target, TouchEventType type);

	bool setQingbao(JsonData* jsonData);
	bool setQingbao1(const char** qb);
private:
	Button* tui;

	Button* newroom;

	Button* refresh;//ˢ�°�ť
	cocos2d::Vector<Button*> ButtonMap;

	bool m_chuangfang;//��Ǵ����Ƿ�ɹ�
};
#endif
