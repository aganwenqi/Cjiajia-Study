#include "MsgManager.h"
#include "JsonData.h"
#include "QingBaoA.h"
#include "List.h"
MsgManager * MsgManager::m_MsgManager = NULL;
MsgManager::MsgManager()
{
	create();
}
MsgManager::~MsgManager()
{
}
/*��ʼ����������*/
void MsgManager::create()
{
	quite = false;
	lianjie = false;
	pattern = false;
	playerState = false;
	fanghao = "";
	comefang = "";
	msgMap.clear();
}
MsgManager* MsgManager::getInstance()
{
		if (m_MsgManager == NULL)
    {
        m_MsgManager = new MsgManager();
    }

    return m_MsgManager;
}
void MsgManager::setmsgMap(const char* leixing,JsonData* jsonData)
{
	msgMap.insert(leixing,jsonData);
}
JsonData * MsgManager::getmsgMap(std::string leixing)
{
	return msgMap.at(leixing);
}
void MsgManager::deleteJsonData(const char* yn)
{
	msgMap.erase(yn);
}
void MsgManager::setPoker(int key,List* poker)
{
	PokerMap.insert(key,poker);
}
List * MsgManager::getPoker(int key)
{
	return PokerMap.at(key);
}

