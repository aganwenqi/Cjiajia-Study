
#ifndef JsonDataUtil_H
#define JsonDataUtil_H

#include "cocos2d.h"
#include "value.h"
USING_NS_CC;

class JsonData : public Ref
{
public:
    JsonData();
    ~JsonData();

    static JsonData* create(const char* data);
    bool init(const char* data);
	Json::Value getRoot();
	Json::Value* getTrueRoot();
    const char* getCStrData(const char* key);
	String getStrData( const char* key );
    int getIntData(const char* key);
	int getIntData(const char* key,const int i);
    float getDoubleData(const char* key);
    bool getBoolData(const char* key);
    bool isHasKey(const char* key);
	const char* getShuzuData(const char* key,int i);
	const char* getShuzuData(const char* key,const char* msg);
	const char* getShuzuData(const char* key,int i,const char* msg);
	const bool getBoolShuzuData(const char* key,int i,const char* msg);
	const int getIntShuzuData(const char* key,int i,const char* msg);

    /* �����ֶε�Json */
    void addValue(const char* key, int value);
    void addValue(const char* key, const char* value);
	void addValue(const char* key, int i,int value);

    /* ��ȡJson��ʽ���ַ��� */
    std::string getsJsonStr();
private:
    Json::Value root;
};

#endif