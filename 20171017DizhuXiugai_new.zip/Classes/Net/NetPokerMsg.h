#ifndef _NetPokerMsg_H_
#define _NetPokerMsg_H_
#include "cocos2d.h"
#include "Enum.h"

class NetPokerMsg:public cocos2d::Ref
{
public:
	NetPokerMsg();
	~NetPokerMsg();
	std::string NextPlayName;
	std::string WhoPokerName;
	Moves m_Moves;
	int poker[21];
protected:

};
#endif