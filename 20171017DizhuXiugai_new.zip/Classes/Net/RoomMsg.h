#ifndef _RoomMsg_H_
#define _RoomMsg_H_
#include "cocos2d.h"
#include "Define.h"
#include "Enum.h"
USING_NS_CC;
class RoomMsg:public Ref
{
public:
	RoomMsg();
    ~RoomMsg();
	PRIVATE(bool,playstate,playstate);//��Ұ��ݽ�ɫ
	PRIVATE(std::string,playname,playname);//�������
	int myPoker[21];//�˿���
};
#endif