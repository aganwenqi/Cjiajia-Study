#include "DengluScene.h"
#include "SceneManager.h"
#include "MusicManager.h"
#include "MoxingManager.h"
#include "FasongManager.h"
#include "QingbaoManager.h"
#include "QingBaoA.h"
#include "MsgManager.h"
#include "Enum.h"
#include "JsonData.h"
USING_NS_CC_EXT;
USING_NS_CC;
DengluScene::DengluScene()
{
	lbl=true;
	ljwc=true;
}
DengluScene::~DengluScene()
{
}
Scene* DengluScene::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = DengluScene::create();

	QingbaoManager::getInstance()->m_DengluScene=layer;//���
    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}
bool DengluScene::init()
{
  if(!Layer::init())
   {return false;}

	 //����UI
     DengLuUI = cocostudio::GUIReader::getInstance()->widgetFromJsonFile("UI/denglu/Fuwuqi_1.ExportJson");//widgetFromJsonFile����UI�ļ���������
     this->addChild(DengLuUI,0);
	 //��ȡ�ؼ�����
     Button* anniu = NULL;

     anniu=(Button*)Helper::seekWidgetByName(DengLuUI,"denglu");
	 anniu->addTouchEventListener(this,toucheventselector(DengluScene::Denglufuwuqi));
	 buttonMap.insert(ButtonEnum::_denglu,anniu);

	 anniu=(Button*)Helper::seekWidgetByName(DengLuUI,"xiugai");
	 anniu->addTouchEventListener(this,toucheventselector(DengluScene::Denglufuwuqi));
	 buttonMap.insert(ButtonEnum::_xiugai,anniu);

	 anniu=(Button*)Helper::seekWidgetByName(DengLuUI,"tui");
	 anniu->addTouchEventListener(this,toucheventselector(DengluScene::menuCloseCallback));
	 buttonMap.insert(ButtonEnum::_tui,anniu);

	 anniu=(Button*)Helper::seekWidgetByName(DengLuUI,"quxiao_0");//ע��1
	 anniu->addTouchEventListener(this,toucheventselector(DengluScene::Denglufuwuqi));
	 buttonMap.insert(ButtonEnum::_zhuce1,anniu);

	 anniu=(Button*)Helper::seekWidgetByName(DengLuUI,"lf");//ע��
	 anniu->addTouchEventListener(this,toucheventselector(DengluScene::Denglufuwuqi));
	 buttonMap.insert(ButtonEnum::_lotoff,anniu);
	
 
	 TextField* xszt=(TextField*)Helper::seekWidgetByName(DengLuUI,"text3");
      //���Ӱ�ť���Ӽ���
	 xszt->setText("Not logged in");
    // xszt->setMaxLengthEnabled(true); 
	// xszt->setMaxLength(10); 
	 textfieldMap.insert("text3",xszt);
	 
	 RegisterUI();
	 AlterUI();
	 InsertBox();
    return true;
}
void DengluScene::RegisterUI()
{
	//����UI
     ZhuCeUI = cocostudio::GUIReader::getInstance()->widgetFromJsonFile("UI/ZhuCeUI/Fuwuqi_1.ExportJson");//widgetFromJsonFile����UI�ļ���������
     this->addChild(ZhuCeUI,1);

	 Button* anniu = NULL;
     anniu = (Button*)Helper::seekWidgetByName(ZhuCeUI,"zhuce");
	 anniu->addTouchEventListener(this,toucheventselector(DengluScene::Denglufuwuqi));
	 buttonMap.insert(ButtonEnum::_zhuce2,anniu);

	 anniu = (Button*)Helper::seekWidgetByName(ZhuCeUI,"tui");
	 anniu->addTouchEventListener(this,toucheventselector(DengluScene::menuCloseCallback));
	 buttonMap.insert(ButtonEnum::_tui1,anniu);

	 TextField* xszt = (TextField*)Helper::seekWidgetByName(ZhuCeUI,"text");
	 xszt->setText("Not logged in");
    // xszt->setMaxLengthEnabled(true); 
	// xszt->setMaxLength(10); 
	 textfieldMap.insert("text",xszt);

	 ZhuCeUI->setEnabled(false);
}
void DengluScene::AlterUI()
{
	//����UI
     XiuGaiUI = cocostudio::GUIReader::getInstance()->widgetFromJsonFile("UI/XiuGaiUI/Fuwuqi_1.ExportJson");//widgetFromJsonFile����UI�ļ���������
     this->addChild(XiuGaiUI,2);

	 Button* anniu=NULL;
     anniu = (Button*)Helper::seekWidgetByName(XiuGaiUI,"zhuce");
	 anniu->addTouchEventListener(this,toucheventselector(DengluScene::Denglufuwuqi));
	 buttonMap.insert(ButtonEnum::_xiugai1,anniu);

	 anniu = (Button*)Helper::seekWidgetByName(XiuGaiUI,"tui");
	 anniu->addTouchEventListener(this,toucheventselector(DengluScene::menuCloseCallback));
	 buttonMap.insert(ButtonEnum::_tui2,anniu);

	 TextField* xszt = (TextField*)Helper::seekWidgetByName(XiuGaiUI,"text");
	 xszt->setText("Not logged in");
    // xszt->setMaxLengthEnabled(true); 
	// xszt->setMaxLength(10); 
	 textfieldMap.insert("text0",xszt);

	 XiuGaiUI->setEnabled(false);
}
void DengluScene::InsertBox()
{
	id = EditBox::create(Size(300,40),
        Scale9Sprite::create("sprite/1.0.png"),
        Scale9Sprite::create("sprite/1.0.png"));
	 //�����ı����λ��
    id->setPosition(Point(500,445));
	id->setFontColor(ccc3(70,70,70));
	id->setPlaceHolder("Please input user");
    //�����ı��򵽲���
    addChild(id,55);
    
	password=EditBox::create(Size(300,40),
        Scale9Sprite::create("sprite/1.0.png"),
        Scale9Sprite::create("sprite/1.0.png"));
	password->setPosition(Point(500,385));
	password->setFontColor(ccc3(70,70,70));
	password->setPlaceHolder("Please input Password");
	password->setReturnType(EditBox::KeyboardReturnType::SEARCH);
    //�����ı��򵽲���
    addChild(password,56);
	setXML(2);
}
void DengluScene::menuCloseCallback(Ref* target, TouchEventType type)
{
	if(type == TouchEventType::TOUCH_EVENT_ENDED&&ljwc)
	{
		MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
		Button* anniu = static_cast<Button*>(target);
		if(anniu == buttonMap.at(_tui))
		{
			SceneManager::getInstance()->changeScene(SceneManager::en_ManScene);
			QingbaoManager::getInstance()->m_DengluScene=NULL;
		}
	else if(anniu == buttonMap.at(_tui1))
	{
		DengLuUI->setTouchEnabled(true);
		ZhuCeUI->setEnabled(false);
	}
	else if(anniu == buttonMap.at(_tui2))
	{
		DengLuUI->setTouchEnabled(true);
		XiuGaiUI->setEnabled(false);
	}
	}
}
void DengluScene::Denglufuwuqi(Ref* target, TouchEventType type)
{
	if(type == TouchEventType::TOUCH_EVENT_ENDED)
{
		MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
		Button* anniu=static_cast<Button*>(target);
		if(anniu == buttonMap.at(_denglu) && !MsgManager::getInstance()->quite)
		{
			if(lbl)
			 {
				 ljwc = false;
				 textfieldMap.at("text3")->setText("Landing...");
				 /* �������̣߳��������� */
				 std::thread recvThread = std::thread(&DengluScene::ThisTread, this);
				 recvThread.detach();
				 lbl=false;
			 }
		}
		else if(anniu == buttonMap.at(_zhuce1))
		{
			DengLuUI->setTouchEnabled(false);
			ZhuCeUI->setEnabled(true);
		}
		else if(anniu == buttonMap.at(_xiugai) && MsgManager::getInstance()->quite)
		{
			DengLuUI->setTouchEnabled(false);
			XiuGaiUI->setEnabled(true);
			FasongManager::getInstance()->UserMsg(1);
		}
		else if(anniu == buttonMap.at(_zhuce2))
		{
			textfieldMap.at("text")->setText("Landing...");
			String ip = id->getText();
			String mmk = password->getText();
			FasongManager::getInstance()->Zhuce(ip,mmk);
		}
		else if(anniu == buttonMap.at(_xiugai1))
		{
			textfieldMap.at("text")->setText("Landing...");
			String ip = id->getText();
			String mmk = password->getText();
			FasongManager::getInstance()->Xiugai(ip,mmk);
		}
		else if(anniu == buttonMap.at(_lotoff))
		{
			FasongManager::getInstance()->lotoff();//ע��
		}
   }

}
void DengluScene::ThisTread()
{
	String ip = id->getText();
	String mmk = password->getText();
	ljwc = FasongManager::getInstance()->Denglu(ip,mmk);
}
bool DengluScene::setQingbao(const char* qb)
{
	std::mutex m_mutex;
	m_mutex.lock();
	bool quite = false;
	if(qb == std::string(G_TXType::G_Chenggong))//�ɹ�
	{
	     textfieldMap.at("text3")->setText("successfully");
		 buttonMap.at(_denglu)->setTitleText("OK");
		 setXML(1);
		 quite = true;
	}
	else if(qb == std::string(G_TXType::G_Shibai))
	{
		 lbl = true;
		 textfieldMap.at("text3")->setText("Not connected");
	}

    m_mutex.unlock();
	return quite;
}
bool DengluScene::setQingbao()//ע��
{
	textfieldMap.at("text3")->setText("log off successfully");
	buttonMap.at(_denglu)->setTitleText("NO");
	MsgManager::getInstance()->quite = false;
	ljwc = true;
	lbl = true;
	return true;
}
bool DengluScene::setQingbao(JsonData* jsonData)
{
	 const char* yn;
	 yn = jsonData->getCStrData(G_Ziduan::G_leixing);
	 /*ע����޸�*/
	if(yn == std::string(G_TXType::G_Zhuce))
	{
		yn = jsonData->getCStrData(G_Ziduan::G_yn);
		if(yn == std::string(G_TXType::G_Chenggong))//�ɹ�
		{
			textfieldMap.at("text")->setText("OK");
		}else
		{
			textfieldMap.at("text")->setText("NO");
		}
	}
	else if(yn == std::string(G_TXType::G_Xiugai))
	{
		yn=jsonData->getCStrData(G_Ziduan::G_yn);
		if(yn == std::string(G_TXType::G_Chenggong))//�ɹ�
		{
			JsonData* jsonData1=NULL;
			jsonData1 = MsgManager::getInstance()->getmsgMap(G_TXType::G_Denglu);
			if(jsonData1 != NULL)
				jsonData1->addValue(G_Ziduan::G_name,jsonData->getCStrData(G_Ziduan::G_name));
			textfieldMap.at("text0")->setText("OK");
		setXML(1);
		}else
        textfieldMap.at("text0")->setText("NO");
	}
	else if(yn == std::string(G_TXType::G_UserMsg1))
	{
		yn = jsonData->getCStrData(G_Ziduan::G_yn);
		if(yn == std::string(G_TXType::G_Chenggong))//�ɹ�
		{
			 id->setText(jsonData->getCStrData(G_Ziduan::G_name));
	         password->setText(jsonData->getCStrData(G_Ziduan::G_mm));
		}
	}
	return true;
}
void DengluScene::setXML(int xml)//1��ʾ�浵��2��ʾȡ��
{
	if(xml == 1)
	{
		ValueMap fileDataMap;
			ValueMap data;
			data["id"]=id->getText();
			data["password"]=password->getText();
			fileDataMap["Land"]=Value(data);
		std::string m_string=FileUtils::getInstance()->fullPathForFilename("demaxiya/Denglu.plist");
		FileUtils::getInstance()->writeToFile(fileDataMap,m_string);//д�뱣��xml�ļ�
	}
	else if(xml==2)
	{
		std::string m_string = FileUtils::getInstance()->fullPathForFilename("demaxiya/Denglu.plist");
		ValueMap fileDataMap = FileUtils::getInstance()->getValueMapFromFile(m_string);
		  if(fileDataMap.size() == 0)
		 {
			 setXML(1);
		 }
		  else
		  {
			Value value = fileDataMap.at("Land");
			ValueMap data = value.asValueMap();
			id->setText(data["id"].asString().c_str());
			password->setText(data["password"].asString().c_str());
		  }
	}
}