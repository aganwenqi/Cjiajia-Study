#include "RoomMsg.h"
RoomMsg::RoomMsg()
{
}
RoomMsg::~RoomMsg()
{
}
