#include "NetRoom1.h"
#include "SceneManager.h"
#include "MusicManager.h"
#include "QingbaoManager.h"
#include "MsgManager.h"
#include "FasongManager.h"
#include "QingBaoA.h"
#include "JsonData.h"
USING_NS_CC;
Scene * NetRoom1::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = NetRoom1::create();
	QingbaoManager::getInstance()->m_NetRoom1=layer;
    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}
NetRoom1::NetRoom1()
{
	zhunbeia=true;
    zhunBJ=true;
	beganBJ=true;
}
/*��ʼ����������*/
void NetRoom1::Initialization()
{
	const char* yn;
	int jiaose;
	JsonData* jsonData=NULL;
	jsonData=MsgManager::getInstance()->getmsgMap("NetRoom");
	if(jsonData)
	{
		yn=jsonData->getCStrData(G_Ziduan::G_roomnumble);
		MsgManager::getInstance()->fanghao=std::string(yn);
		fanghao->setText(yn);
		textMap.at("text1")->setText(jsonData->getCStrData(G_Play::G_playname));
		zhunbei->setEnabled(false);
		MsgManager::getInstance()->deleteJsonData("NetRoom");
	}else
	kaishi->setEnabled(false);
}
bool NetRoom1::init()
{
	Size visible=Director::getInstance()->getVisibleSize();

	/*����UI*/
    auto UI=cocostudio::GUIReader::getInstance()->widgetFromJsonFile("UI/Room_2/Room_1_1.ExportJson");
	this->addChild(UI);

	TextField* text;
	Sprite* zhunbei1;
	std::string str;
	tui=(Button*)Helper::seekWidgetByName(UI,"tui");
	zhunbei=(Button*)Helper::seekWidgetByName(UI,"zhunbei");
	kaishi=(Button*)Helper::seekWidgetByName(UI,"kaishi");
	fanghao=(TextField*)Helper::seekWidgetByName(UI,"fanghao");

	text=(TextField*)Helper::seekWidgetByName(UI,"text1");
	textMap.insert("text1",text);

	text=(TextField*)Helper::seekWidgetByName(UI,"text2");
	zhunbei1=(Sprite*)Helper::seekWidgetByName(UI,"zhunbei2");
	textMap.insert("text2",text);
	spriteMap.insert("zhunbei2",zhunbei1);
	zhunbei1->setVisible(false);

	text=(TextField*)Helper::seekWidgetByName(UI,"text3");
	zhunbei1=(Sprite*)Helper::seekWidgetByName(UI,"zhunbei3");
	textMap.insert("text3",text);
	spriteMap.insert("zhunbei3",zhunbei1);
	zhunbei1->setVisible(false);

	tui->addTouchEventListener(this,toucheventselector(NetRoom1::Tuichu));
	zhunbei->addTouchEventListener(this,toucheventselector(NetRoom1::Zhunbei));
	kaishi->addTouchEventListener(this,toucheventselector(NetRoom1::Kaishi));
	Initialization();
	return true;
}
/*�˳���ť*/
void NetRoom1::Tuichu(Ref* target, TouchEventType type)
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
	MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
	FasongManager::getInstance()->TuiRoom(fanghao->getStringValue().c_str());
	}
}
void NetRoom1::Zhunbei(Ref* target, TouchEventType type)//׼��
{
	if(type==TouchEventType::TOUCH_EVENT_ENDED&&zhunBJ)
	{
		FasongManager::getInstance()->Zhunbei(zhunbeia,fanghao->getStringValue().c_str());
		zhunBJ=false;
		if(zhunbeia)
	    zhunbeia=false;
		else
        zhunbeia=true;
	MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
	}
}
void NetRoom1::Kaishi(Ref* target, TouchEventType type)
{
		if(type==TouchEventType::TOUCH_EVENT_ENDED)
	{
		/*beganBJ=false;
		if(beganBJ)
	    beganBJ=false;
		else
        beganBJ=true;*/
	FasongManager::getInstance()->Kaishi(fanghao->getStringValue().c_str());
	MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
	}
}
bool NetRoom1::setQingbao(bool yn,const char* qb)//�˷�
{
	MsgManager::getInstance()->fanghao="";
	SceneManager::getInstance()->changeScene(SceneManager::en_NetRoom);
	FasongManager::getInstance()->getAllRoom();
	return true;
}
bool NetRoom1::setQingbao(JsonData* jsonData)
{
	    //Initialization();
	    CreateData();
	    zhunBJ=true;
	    int swap;
	    const char* yn;
		int max=jsonData->getRoot()[G_Ziduan::G_RoomMsg].size();
		int j=2;
		std::string str;
		const char* myname=MsgManager::getInstance()->getmsgMap(G_TXType::G_Denglu)->getCStrData(G_Ziduan::G_name);
		for(int i=0;i<max;i++)
	{
		swap=jsonData->getIntShuzuData(G_Ziduan::G_RoomMsg,i,G_Play::G_playstate);
		yn=jsonData->getShuzuData(G_Ziduan::G_RoomMsg,i,G_Play::G_playname);
		if(swap==2)
		{
			textMap.at("text1")->setText(yn);
			//log(myname);
			//log(yn);
			if(strcmp(myname,yn)==0)
			{
				log("you are ");
			    zhunbei->setEnabled(false);
				zhunbei->setVisible(false);
            	kaishi->setEnabled(true);
				kaishi->setVisible(true);
			}
		}
		else
		{
        str=StringUtils::format("text%d",j);
		textMap.at(str)->setText(yn);
		str=StringUtils::format("zhunbei%d",j++);
		spriteMap.at(str)->setVisible(swap);
		 if(swap==1&&strcmp(myname,yn)==0)
		 zhunbei->setTitleText("OK");
		 else if(swap==0&&strcmp(myname,yn)==0)
		 zhunbei->setTitleText("NO");
		}
	}
		fanghao->setText(jsonData->getCStrData(G_Ziduan::G_roomnumble));
		MsgManager::getInstance()->comefang=jsonData->getCStrData(G_Ziduan::G_roomnumble);
		return true;
}
void NetRoom1::CreateData()//���ݳ�ʼ��
{
	textMap.at("text1")->setText("");
	textMap.at("text2")->setText("");
	textMap.at("text3")->setText("");
	spriteMap.at("zhunbei2")->setVisible(false);
	spriteMap.at("zhunbei3")->setVisible(false);
}