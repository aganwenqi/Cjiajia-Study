#include "PokerScene.h"
#include "Route.h"
#include "AllManager.h"
#include "MiddleMan.h"
#include "pDataManager.h"
#include "Define.h"
#include "SimpleAudioEngine.h"
#include "MusicManager.h"
#include "MsgManager.h"
#include "FasongManager.h"
USING_NS_CC;
PokerScene::PokerScene()
{
	m_AllManager=NULL;
	isMeun=false;
	isMeunActive=false;
	srand((unsigned)time(NULL));

}
PokerScene::~PokerScene()
{
	NOTIFY->removeAllObservers(this);
}
Scene* PokerScene::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = PokerScene::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}
bool PokerScene::init()
{
  if(!Layer::init())
   return false;

    Size visibleSize=Director::getInstance()->getVisibleSize();

    m_AllManager=AllManager::create();
	this->addChild(m_AllManager,AllManagerLayer);
	m_AllManager->setSwallowsTouches(false);

	NOTIFY->addObserver(
		this,
		callfuncO_selector(PokerScene::CreateEnd),
		"text",
		NULL);
	
	/*�˵�*/
	CreateMainMeun();

    return true;
}
/*�����ƺ󵯳���ȷ������*/
void PokerScene::CreateEnd(Ref* pData)
{

	MusicManager::StopBackgroundMusic();
	i = (int)pData;
	if(!MsgManager::getInstance()->getpattern())
	{
		MiddleMan::getInstance()->WhoHaveDz(i);
		MiddleMan::getInstance()->setHaveDz(true);
	}
    this->scheduleOnce(schedule_selector(PokerScene::MyUpdata),2.0f);
}
void PokerScene::MyUpdata(float dt)
{
	Size visibleSize=Director::getInstance()->getVisibleSize();
	if(pDataManager::getInstance()->getWinLose())
	MusicManager::PlayEffectMusic("music/MusicEx_Win.mp3");
	else
	MusicManager::PlayEffectMusic("music/MusicEx_Lose.mp3");

    auto sprite=Sprite::create(StringUtils::format("sprite/Win%d.png",i));

	sprite->setPosition(Point(visibleSize.width/2,visibleSize.height/2));

	this->addChild(sprite,ButtonLayer,ButtonBeijingTag);
	MenuItemImage *close=MenuItemImage::create(
		"sprite/anniu.png",
		"sprite/anniu1.png",
		this,
		menu_selector(PokerScene::ButtonFunc)
		);

	menu = Menu::create(close, NULL);
	menu->setPosition(Point(visibleSize.width/2,visibleSize.height/5));
	this->addChild(menu,ButtonLayer,ButtonTag);
	menu->setSwallowsTouches(true);
	menu->setEnabled(true);
	menu->setVisible(true);
}
void PokerScene::ButtonFunc(Ref* pData)
{
	MusicManager::PlayEffectMusic("music/ButtoOk.mp3");
	this->removeChild(menu);
	menu=NULL;

	auto Button=getChildByTag(ButtonTag);
	if(Button)
	this->removeChild(Button);

    Button=getChildByTag(ButtonBeijingTag);
	if(Button)
	this->removeChild(Button);


	if(MsgManager::getInstance()->getpattern())
	{
		MsgManager::getInstance()->setpattern(false);
		FasongManager::getInstance()->ComeRoom(MsgManager::getInstance()->comefang);
	}
	else
	m_AllManager->NextBoard();
}
