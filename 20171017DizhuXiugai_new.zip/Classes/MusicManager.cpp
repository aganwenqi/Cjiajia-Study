#include "MusicManager.h"
void MusicManager::PlayBackgroundMusic(const char *str,bool state)
{
    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic(str,state);
}
void MusicManager::PlayEffectMusic(const char *str)
{
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(str);
}
void MusicManager::StopBackgroundMusic()
{
    CocosDenshion::SimpleAudioEngine::getInstance()->stopBackgroundMusic();
}
void MusicManager::StopAllEffectMusic()
{
	CocosDenshion::SimpleAudioEngine::getInstance()->stopAllEffects();
}